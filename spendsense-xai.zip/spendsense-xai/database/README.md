# Database guide (SQLite or MySQL / MariaDB)

SpendSense-XAI stores everything in one database. It works with two engines:

| Engine | When to use | Setup |
|---|---|---|
| **MySQL / MariaDB** (XAMPP) — **default** | Everything is saved where phpMyAdmin can see it | Start MySQL in XAMPP. The app creates database `spendsense-xai`, tables and demo data itself. |
| **SQLite** | No MySQL available | Set `DATABASE_URL=sqlite:///./spendsense.db` in `backend/.env` |

**"Nothing is stored in my database" — why it happened and how it is prevented:** the
app used to fall back to a SQLite *file* whenever `backend/.env` was missing (and even
`.env.example` pointed at SQLite), so phpMyAdmin stayed empty. Now `backend/.env`
ships pointing at MySQL; if `DATABASE_URL` is set and MySQL is down the app **stops
with an error** instead of silently saving elsewhere. Check with `python check_db.py`
or `http://127.0.0.1:8000/health` (`"dialect": "mysql"`).

## Why did phpMyAdmin say `#1064 ... near 'SQLite format 3'`?

`backend/spendsense.db` is a **binary SQLite file**. phpMyAdmin's *Import* tab only
understands **SQL text**. Never import the `.db` file. Use `database/spendsense_mysql.sql` instead.

## Option A — one command (recommended)

1. XAMPP Control Panel → **Start** MySQL.
2. In a terminal, in the `backend` folder (virtual env active):
   ```
   python setup_mysql.py --db spendsense-xai
   ```
   It creates the database, writes `backend/.env`, creates all tables and loads demo accounts.
3. `uvicorn app.main:app --reload` — done. Check with `python check_db.py`.

## Option B — import through phpMyAdmin

1. XAMPP → Start MySQL (and Apache) → open <http://localhost/phpmyadmin>.
2. **New** → name `spendsense-xai` (any name works) → collation `utf8mb4_general_ci` → Create.
3. Open that database → **Import** → choose `database/spendsense_mysql.sql` → **Go**.
   You should see 11 tables. (`spendsense_schema_only.sql` = same tables, no demo data.)
4. Create `backend/.env` containing (use *your* database name):
   ```
   DATABASE_URL=mysql+pymysql://root:@127.0.0.1:3306/spendsense-xai
   ```
   (root with an empty password is XAMPP's default. With a password: `root:yourpassword@`.)
5. `uvicorn app.main:app --reload`. Log in with `demo@spendsense.app` / `demo1234`.

## Tables

| Table | What it stores |
|---|---|
| `users` | Accounts, income, age tier, language, theme, font settings, currency |
| `expenses` | Every expense (amount, category, merchant, note, `source` = manual / scan / quick / csv) |
| `goals`, `goal_contributions` | Savings goals and every deposit / withdrawal |
| `budgets` | Monthly limits per category (or overall) |
| `triggers`, `interventions` | Mined spending triggers and the nudges tried (with outcomes) |
| `families`, `family_members`, `family_challenges`, `family_kudos` | Family space, roles, challenges, kudos |

## Troubleshooting

| Message | Fix |
|---|---|
| `Can't connect to MySQL server` | MySQL is not started in XAMPP, or port differs (`:3307`) |
| `Access denied for user 'root'` | Put your password in the URL: `root:password@` |
| `Unknown database` | Create it first (Option A does this for you) |
| `/health` shows `"ok": false` | Run `python check_db.py --repair` |

To use SQLite instead, set `DATABASE_URL=sqlite:///./spendsense.db` in `backend/.env`.
