# SpendSense-XAI

**Context-aware, explainable expense tracker with adaptive behavioral intervention.**

Not just "log an expense and see a pie chart" — SpendSense-XAI mines *your own*
spending history for the **context** behind your habits (time of day, day type,
payment method), explains *why* it thinks a pattern exists with counted
evidence and a confidence score, suggests a personalized nudge, A/B-tests
which nudge actually works for you, and measures the real before/after
result. It's a closed loop:

```
Detect → Explain → Intervene → Measure → Learn → Adapt
```

![Architecture](docs/architecture.svg)

### Documentation map

| I want to... | Open |
|---|---|
| Understand **what every feature does and how it works** (for staff / reviewers) | [`docs/FEATURES.md`](docs/FEATURES.md) - or in the app: sidebar -> **Feature guide** |
| Set up **MySQL / MariaDB / phpMyAdmin** (and fix the `#1064 SQLite format 3` import error) | [`database/README.md`](database/README.md) |
| Run the app | [Run it in VS Code](#run-it-in-vs-code) |
| See what is novel | [`NOVELTY.md`](NOVELTY.md) |


---

## What makes this different from a normal expense tracker

| # | Feature | Where it lives |
|---|---|---|
| 1 | **Spending Trigger Confidence Engine** — mines context→category patterns with recency-decayed statistical confidence, not a guess | `backend/app/services/trigger_engine.py` |
| 2 | **Explainable AI (XAI) layer** — every claim traces back to counted evidence, never a bare assertion | `backend/app/services/xai_engine.py` |
| 3 | **Intervention A/B testing** — alternates between two nudge archetypes (Habit / Delay / Limit / Friction) per category and tracks which wins | `backend/app/services/intervention_engine.py` |
| 4 | **Effectiveness measurement** — compares real spend before vs. after a nudge, auto-decides keep/stop | `intervention_engine.measure_effectiveness` |
| 5 | **Human feedback loop** — a 👎 immediately retires a nudge that isn't working for you | `intervention_engine.submit_feedback` |
| 6 | **Self-comparison baseline** — you're only ever compared to your own trailing 3-month average, never to other people | `report_generator.self_comparison` |
| 7 | **What-changed detector** — month-over-month deltas per category, with a plain-language reason pulled from your active triggers | `report_generator.what_changed` |
| 8 | **Goal-conflict detector** — computes the monthly savings rate your goal needs vs. your actual rate, flags the gap | `report_generator.goal_conflicts` |
| 9 | **Pattern expiration** — habits that stop recurring automatically fade out instead of haunting your dashboard forever | `trigger_engine.persist_triggers` |
| 10 | **Counterfactual simulator** — "what if I ordered food out 2x fewer per week" → projected monthly/annual savings, computed from *your* average transaction size | `backend/app/services/counterfactual.py` |
| 11 | **In-app help chatbot** — rule-based FAQ assistant answering "how do I…" questions about the app itself, no external API calls, no data leaves the app | `backend/app/services/help_bot.py` |
| 12 | **4 switchable themes** — Night, Daylight, Deep Ocean, and a bright/rounded "Playground" mode for younger users | `frontend/src/ThemeContext.jsx` |
| 13 | **12-language interface, everywhere** — English, Hindi, Tamil, Telugu, Bengali, Marathi, Gujarati, Kannada, Malayalam, Punjabi, Spanish, French. Every screen (all four age-mode variants, onboarding, modals, scanner, help-bot, and the backend-generated explanations/insights) switches at once; dates and numbers follow the language | `frontend/src/i18n.js`, `frontend/src/locales/*.json`, `backend/app/i18n.py` |
| 14 | **Multi-currency display** — 6 currencies with proper symbol/formatting (display only, no live FX conversion) | `frontend/src/currency.js` |
| 15 | **Guided onboarding tour + age-aware signup** — a 5-step first-run walkthrough (with wording tailored to kid/teen/adult), and a registration flow that asks date of birth, income, and savings, showing a guardian-consent checkbox for users under 13 | `frontend/src/components/OnboardingTour.jsx`, `frontend/src/pages/Register.jsx` |
| 16 | **Four genuinely different age-tiered experiences, on every page** — not just the Dashboard. Playground (kid) gets a "Pattern Detective" framing on Insights, "Missions" on Interventions with confetti celebrations, an emoji-grid on Expenses, and a "My Money Story" narrative Report. Guided (teen) gets a Weekly Challenge, streak tooltips, and milestone call-outs on Goals. Full (adult) gets the complete detailed view everywhere. Comfort (senior) gets larger text, higher contrast, single-column layouts, and plain-language summaries replacing raw percentages, on every single page. | `frontend/src/pages/*.jsx`, `frontend/src/components/*Dashboard.jsx` |
| 17 | **Age-milestone transition prompts** — the app tracks date of birth and offers (never forces) a one-time switch: teen→Full at 18, and adult→Comfort at 60, each with a short "what's new" guide | `backend/app/routers/auth.py` (`/auth/transition-to-adult`, `/auth/transition-to-senior`), `frontend/src/components/AdultTransitionModal.jsx`, `SeniorTransitionModal.jsx` |
| 18 | **Motivation engine** — a real logging streak computed from expense timestamps, 7 badges earned from actual usage (not fake placeholders), and an encouragement message built from your real habit score and spending change | `backend/app/services/motivation.py`, `frontend/src/components/MotivationCard.jsx` |
| 19 | **Canvas particle effects** — an animated, theme-matched particle field on login/register and every dashboard header, plus a celebratory confetti burst the first time you earn a new badge | `frontend/src/components/ParticleField.jsx`, `frontend/src/components/ConfettiBurst.jsx` |
| 20 | **Mode-aware help chatbot with 30 topics** — expanded FAQ coverage (streaks, badges, XAMPP setup, the 18th-birthday flow, privacy, and more), word-level matching that handles natural phrasing and plurals, and kid-friendly phrasing automatically swapped in for Playground-mode users | `backend/app/services/help_bot.py` |
| 21 | **XP & Level progression system** — every point of XP traces back to something real (habit score, logging streak, badges earned, expenses logged), rolled into 10 named levels from "Money Rookie" to "Legendary Saver," shown as a progress bar styled differently per age tier | `backend/app/services/motivation.py` (`compute_xp`, `compute_level`), `frontend/src/components/LevelProgress.jsx` |
| 22 | **"Coiny" the money buddy** — a kid-mode SVG mascot whose facial expression (happy / neutral / encouraging) is driven entirely by the user's real habit score and streak, never random or purely decorative | `frontend/src/components/MoneyBuddy.jsx` |
| 23 | **Teen quest chain** — up to two monthly quests generated from the user's actual top spending triggers, each showing a real projected saving via the counterfactual engine, with checkable completion tracked locally | `frontend/src/components/TeenDashboard.jsx` (`QuestChain`) |
| 24 | **Adult Pro Insights** — daily spending velocity, a projected month-end total, and pace-vs-baseline, computed live from the monthly report and the current date, no extra API calls or invented numbers | `frontend/src/components/ProInsights.jsx` |
| 25 | **Translation tooling** — text-as-key catalogs (`locales/<lang>.json`), `npm run i18n:extract` / `npm run i18n:check` (placeholder + coverage check, pseudo-locale for hunting untranslated text), Noto Sans web fonts for every script | `frontend/scripts/`, `frontend/index.html` |
| 26 | **Real currency conversion, not just a symbol swap** — every amount is recorded in the currency you signed up with (`base_currency`, fixed) and converted using a live exchange rate whenever you view it in a different display currency. Rates come from a free live API refreshed every 6 hours, with a dated, documented fallback table for offline use, and a visible "live" vs "offline" indicator plus a manual refresh button in Settings. Verified with real cross-currency math (100 EUR → 85.60 GBP, matching real-world rates). | `backend/app/services/fx_rates.py`, `frontend/src/useMoney.js`, `frontend/src/CurrencyRatesContext.jsx` |
| 27 | **9-currency support including AED** — INR (with correct Indian lakh/crore digit grouping via the `en-IN` locale), USD, EUR, GBP, JPY, AUD, CAD, SGD, and AED (the top currency for Indian diaspora/remittance use cases) | `frontend/src/currency.js` |
| 28 | **Design decisions grounded in published research, not guesses** — the kid/teen gamification mechanics and the senior Comfort theme's font size, contrast, and layout choices are each traced to a specific cited study or standard (WCAG 2.2, a 2023 JMIR systematic review on older-adult app design, and peer-reviewed papers on gamified financial literacy apps for young people) | [`RESEARCH.md`](RESEARCH.md) |
| 29 | **Bill scanner (camera + photo upload + paste)** — point the live camera at a bill, drop/paste/pick a photo, or paste e-receipt text. OCR (tesseract.js, bundled in `frontend/public/tesseract`) runs **on your device, fully offline** — the image never leaves the browser. A parser then extracts merchant, total (ignoring subtotal/tax/change/savings), date & time, payment method, line items, tax and category, with per-field confidence; hard-to-read fields are highlighted amber on a review screen and **nothing is saved until you confirm**. Includes a laser-scan animation, duplicate-bill guard and currency-mismatch warning. Scanned expenses get a 📷 badge and unlock the new **Receipt Ninja** badge. | `frontend/src/components/ReceiptScanner.jsx`, `backend/app/services/receipt_parser.py`, `POST /expenses/parse-receipt` |
| 30 | **Magic quick-add (type or speak)** — "450 swiggy dinner upi yesterday" → amount, merchant, category, payment method and date parsed instantly; mic button uses the browser's speech recognition in your UI language. | `frontend/src/components/QuickAdd.jsx`, `receipt_parser.parse_quick_text`, `POST /expenses/quick-parse` |
| 31 | **Safe-to-Spend Today** — a daily allowance computed from your income (or own baseline), what your goals need this month, and what you've already spent, with an animated ring and plain-language status. | `backend/app/services/pulse.py`, `frontend/src/components/SafeToSpend.jsx` |
| 32 | **Subscription Radar** — finds recurring charges (weekly → yearly) in your own history, shows next due date, monthly/annual cost, **price-creep** alerts, and the counted evidence behind each detection. | `backend/app/services/recurring.py`, `frontend/src/components/SubscriptionRadar.jsx` |
| 33 | **Spending heatmap calendar** — GitHub-style day-by-day grid with quantile-based intensity (one huge purchase can't wash out the rest), no-spend-day count and your priciest weekday. | `pulse.heatmap`, `frontend/src/components/SpendHeatmap.jsx` |
| 34 | **Motion system** — page transitions, staggered card entrances, count-up numbers, tilt-and-glare stat cards, sliding nav indicator, shimmer skeletons, animated rings/progress bars, scroll-reveal, ripple/shine buttons. All of it switches off automatically for users with "reduce motion" enabled. | `frontend/src/theme.css`, `frontend/src/hooks/useMotion.js` |
| 35 | **Font size & font style (Settings → Text & reading)** — size slider (75–175%) with S/M/L/XL/XXL presets, 8 font styles (incl. dyslexia-friendly Lexend and low-vision Atkinson Hyperlegible), relaxed line spacing, live preview. Saved to your account and applied on every device at login. | `frontend/src/ThemeContext.jsx`, `frontend/src/pages/Settings.jsx`, `users.font_*` |
| 36 | **Sharper bill scanner** — shadow removal, automatic straightening, crop to the printed area and two OCR passes (clean black-and-white + grayscale). The server repairs OCR digit mix-ups (`2B0.00`→`280.00`), picks the most self-consistent pass, cross-checks line items/subtotal/tax against the total, votes on the date across passes, learns your merchants/categories, and offers one-tap alternative totals when unsure. On a synthetic 24-image test set the correct total rose from 42% to 96% (see *Scanner accuracy* below). | `frontend/src/scanner/imageProc.js`, `backend/app/services/receipt_parser.py` |
| 37 | **Spending Persona** — a friendly type (Night Owl Nibbler, Weekend Warrior, Steady Planner…) from your last 90 days, with the numbers that earned it and a constructive tip. | `backend/app/services/persona.py`, `PersonaCard.jsx` |
| 38 | **Unusual-spend guard** — flags a purchase far above *your own* norm for that category (robust median/MAD statistics, needs 5+ comparable purchases). Warns in the scanner and Magic add, and lists recent ones on the dashboard. | `backend/app/services/anomaly.py`, `UnusualSpends.jsx` |
| 39 | **CSV export** of all your expenses (spreadsheet-formula-safe). | `GET /expenses/export.csv`, Settings → Your data |
| 40 | **Visual effects** — drifting aurora background, cursor spotlight on cards, rotating gradient borders on hero cards, shimmering headings, button ripples, confetti when a scan is saved. All disabled for "reduce motion", and adjustable in Settings → Visual effects (Full / Subtle / Off). | `Aurora.jsx`, `hooks/useGlobalFx.js`, `theme.css` |
| 41 | **14-day cash-flow forecast** — projects your cumulative spend using your own weekday habits plus recurring bills that fall due (🧾 markers), draws it as an animated line, and tells you whether you'll finish the month on track, tight or over budget. | `backend/app/services/lab.py` (`cashflow_forecast`), `InsightLab.jsx` |
| 42 | **Spare-change jar** — "if every purchase were rounded up to the next ₹5/10/50/100, how much would I have quietly saved?" with a filling-jar animation, weekly bars and a yearly projection. | `lab.roundup_savings`, `InsightLab.jsx` |
| 43 | **Safe-to-Spend week chart** — last 7 days of spending as bars against today's allowance line, so overspending days stand out in red. | `SafeToSpend.jsx` |
| F1 | **Family space — one app for the whole household.** Create a family, share an invite code (or add a child profile yourself), and every member sees their own spending side by side. Roles (owner / parent / member / child), per-member privacy (everything · totals only · rank only), and a "switch to child profile" for parents | `backend/app/routers/family.py`, `frontend/src/pages/Family.jsx` |
| F2 | **Healthy-habit leaderboard** — a podium and full ranking that reward good habits (logging days, streaks, no-spend days, beating your own usual pace, goal progress) so nobody "wins" by spending more or less than others | `backend/app/services/family.py` |
| F3 | **Who spends what** — per-member totals and category split for the last 7 days or this month, respecting each member's privacy setting | `GET /family` |
| F4 | **Family challenges & kudos** — no-spend-day, spending-cap and "everyone logs" challenges with progress bars, awards (Streak Master, Zen Saver, Most Improved, Goal Getter, Receipt Ranger, Chief Cheerleader) and cheers you can send each other | `POST /family/challenges`, `POST /family/kudos` |
| T1 | **Everyday tracker essentials** — fund your savings goals (Add money / Take out, one-tap amounts, "Fill it up!", per-goal history, edit & delete with confetti when you reach 100%); edit any expense, pick its category and date when adding, search and filter by category or date range with a running total. Amounts you type are converted from your display currency to the stored currency automatically | `backend/app/routers/goals.py`, `backend/app/routers/expenses.py`, `frontend/src/pages/Goals.jsx`, `frontend/src/pages/Expenses.jsx` |
| T2 | **Monthly budgets with early warnings** — one overall limit and/or per-category limits, progress bars, "on pace to go over" projection, a dashboard card, and a warning right after you log an expense that pushes a budget past 80% / 100% | `backend/app/routers/budgets.py`, `frontend/src/pages/Budgets.jsx`, `BudgetsCard.jsx` |
| T3 | **Bring your data in, take it with you, delete it** — CSV import (flexible headers, date/amount formats and duplicate skipping), CSV export, change password, and permanent account deletion | `POST /expenses/import-csv`, `POST /auth/change-password`, `POST /auth/delete-account`, Settings |

Every one of these is implemented as real, working logic — not a mock. See
[`NOVELTY.md`](NOVELTY.md) for a closer look at what's distinctive about the
approach, and an honest note on what "patent-worthy" would actually require.

---

## Using the app — a friendly walkthrough

**1. First time here?** Register with your name, email, and password. Age,
currency, language, income, and savings are all optional but make the app
more useful right away — the app remembers your currency and language
choice for next time. If you enter an age under 13, you'll see a checkbox
confirming a parent or guardian is okay with the account — please have an
adult help set things up.

**2. You'll get a short welcome tour** the first time you log in, pointing
out the Dashboard, Expenses, Triggers, Interventions, and Report pages.
You can skip it any time and it won't show again.

**3. Log a few expenses** on the Expenses page — the app guesses the
category automatically from what you type.

**4. Discover your patterns** on the Triggers & XAI page — click "Refresh
triggers" (needs at least ~3 similar expenses in a shared context, e.g.
several late-night orders) and click a trigger card to see the evidence
behind it.

**5. Get a nudge** — from a trigger's explanation, click "Suggest an
intervention." It'll show up on the Interventions page where you can
measure whether it's working and give a thumbs up/down.

**6. Check your Monthly Report** for the big picture: how this month
compares to your own past months, what changed and why, and whether your
savings goals are on pace.

**Stuck at any point?** Click the 💬 chat bubble in the bottom-right corner
— it's a built-in, rule-based helper that can answer "how do I…" questions
about any part of the app, instantly and without needing internet access
beyond your own backend.

**Want a different look or language?** Open Settings (⚙ in the sidebar) to
switch between four themes (including a bright, big-button "Playground"
theme), twelve languages, and nine currencies, and to update your income or
savings at any time.

---

## Tech stack

- **Backend:** Python, FastAPI, SQLAlchemy, SQLite (swap to PostgreSQL by
  changing one env var), JWT auth (`python-jose`), bcrypt password hashing
- **Frontend:** React 19 + Vite, React Router, Recharts, Axios
- **Security:** hashed passwords, signed JWT tokens, CORS allowlist,
  in-memory rate limiting, security response headers, parameterized queries
  via the ORM (no raw SQL)

---

## Project structure

```
spendsense-xai/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app, CORS, rate limiting
│   │   ├── models.py            # SQLAlchemy tables
│   │   ├── schemas.py           # Pydantic request/response models
│   │   ├── security.py          # JWT + bcrypt
│   │   ├── deps.py              # current-user auth dependency
│   │   ├── routers/             # auth, expenses, goals, insights, interventions, reports
│   │   └── services/            # the "brain": categorizer, trigger_engine,
│   │                             #   xai_engine, intervention_engine,
│   │                             #   counterfactual, report_generator
│   ├── seed_data.py             # generates a realistic demo user
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── pages/                # Login, Register, Dashboard, Expenses,
│   │   │                          #   Insights, Interventions, Goals, Report
│   │   ├── components/           # Sidebar, ConfidenceRing (signature gauge)
│   │   ├── api.js                # axios client with auth interceptor
│   │   └── AuthContext.jsx
│   └── .env.example
└── docs/
    └── architecture.svg
```

---

## Run it in VS Code

> **Shortcut (Windows):** double-click `start-backend.bat`, then `start-frontend.bat`. **macOS/Linux:** `./start.sh`. Open <http://localhost:5173>.

You need **two terminals** (backend + frontend) — open them via
`Terminal → New Terminal` in VS Code, or use the integrated terminal split view.

### 1. Backend

```bash
cd backend
python -m venv venv

# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

**Data is stored in MySQL / MariaDB (XAMPP) by default.** Start MySQL in the XAMPP
Control Panel, then start the backend: it creates the `spendsense-xai` database,
all tables and the demo accounts by itself, and every expense / goal / budget you
add is saved there (visible in phpMyAdmin). The console prints
`[SpendSense] database: mysql -> ...` so you always know where data goes. If MySQL
is not running and `backend/.env` has no `DATABASE_URL`, the app falls back to a
SQLite file with a loud warning; if `DATABASE_URL` is set it never falls back.
Details: [`database/README.md`](database/README.md).

The API is now live at `http://127.0.0.1:8000`, with interactive docs at
`http://127.0.0.1:8000/docs`.

Four demo accounts are ready to use (all share the password `demo1234`):

| Account | Platform mode | What it shows |
|---|---|---|
| `demo@spendsense.app` | Full (adult) | The complete detailed dashboard |
| `teen@spendsense.app` | Guided (teen) | Logs in with the 18th-birthday transition prompt already showing |
| `kid@spendsense.app` | Playground | Animated piggy bank, star rating, a savings goal already in progress |
| `senior@spendsense.app` | Comfort | Larger text, higher contrast, simplified single-column layout |

**The fastest way to see all four** is Settings → Platform mode: pick any mode and watch the *entire app* change instantly on your own logged-in account.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```


Open `http://localhost:5173` in your browser.

### 3. First run checklist

1. Log in (demo account) or register a new one.
2. Go to **Expenses** and add a few, or rely on the seeded demo data.
3. Go to **Triggers & XAI** and click **Refresh triggers** — this runs the
   mining pipeline over your history.
4. Click a trigger to see its evidence-backed explanation, then
   **"Suggest an intervention"**.
5. Go to **Interventions** to see the A/B-assigned nudge, click
   **Measure result** to compare before/after spend.
6. Check **Monthly Report** for the self-comparison, what-changed, and
   goal-conflict views.

---

## Configuration

Copy `backend/.env.example` to `backend/.env` and set a real `SECRET_KEY`
before deploying anywhere beyond localhost:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

Copy `frontend/.env.example` to `frontend/.env` if your backend isn't on
`http://127.0.0.1:8000`.

To switch from SQLite to PostgreSQL, set `DATABASE_URL` in `backend/.env`:

```
DATABASE_URL=postgresql://user:password@localhost:5432/spendsense
```

(Requires `psycopg2-binary` — add it to `requirements.txt` if you go this
route.)

---

## Using XAMPP / MySQL (phpMyAdmin) instead of SQLite

Full guide: [`database/README.md`](database/README.md). Short version:

```bash
# 1. XAMPP Control Panel -> Start MySQL
cd backend
python setup_mysql.py --db spendsense-xai     # creates DB + tables + demo data, writes .env
uvicorn app.main:app --reload
```

Prefer phpMyAdmin? Create an empty database, open **Import**, and choose
`database/spendsense_mysql.sql` (tables + demo data) - then set
`DATABASE_URL=mysql+pymysql://root:@127.0.0.1:3306/<your-db>` in `backend/.env`.

> **Never import `backend/spendsense.db` into phpMyAdmin.** It is a binary SQLite
> file, which produces `#1064 ... near 'SQLite format 3'`. Use the `.sql` file.

Verified on MariaDB 10.11 (what XAMPP ships): the whole test suite passes against it
(`TEST_DATABASE_URL=mysql+pymysql://root:@127.0.0.1/scratch pytest`), and missing columns
are added automatically on start-up for SQLite, MySQL/MariaDB and Postgres.

---

## Security notes

- Passwords are hashed with bcrypt and never logged or returned by the API.
- Auth uses short-lived, signed JWTs (default 2 hours) — no session state
  stored server-side beyond the token's own signature.
- CORS is locked to an explicit origin allowlist (`ALLOWED_ORIGINS`), not `*`.
- A simple in-memory sliding-window rate limiter protects every endpoint
  from brute-force/abuse (swap for Redis-backed limiting if you scale to
  multiple backend instances).
- All database access goes through SQLAlchemy's ORM with bound parameters —
  no string-built SQL, so no SQL injection surface.
- `X-Content-Type-Options` and `X-Frame-Options` headers are set on every
  response.
- The in-app help chatbot is a local, rule-based FAQ matcher — it never
  calls an external AI service and no message content leaves your machine.

### A note on younger users

The signup form asks for age so the app can offer a simpler, friendlier
"Playground" theme automatically. If an entered age is under 13, the form
requires a checkbox confirming a parent or guardian is aware of and okay
with the account before it will submit — the account itself isn't gated
further than that in this demo project. If you're deploying this for real
family or classroom use, a parent/guardian should still create and manage
the account, and you may want to add stronger verification depending on
your jurisdiction's requirements for handling data from children (e.g.
COPPA in the US).

For a real production deployment you'd also want: HTTPS termination,
refresh-token rotation, structured audit logging, and a managed Postgres
instance instead of SQLite.

---

## A note on "patent-worthy"

I'm not a lawyer, and whether anything here is actually patentable depends on
a formal prior-art search and a patent examiner's judgment — not something
either of us can determine from a chat. What I *can* say: the specific
combination here (context-fingerprinted trigger mining with recency decay →
evidence-grounded explanation → A/B-tested intervention → measured outcome →
feedback-adjusted retraining, applied specifically to personal expense
tracking) is not something you'll find bundled together in mainstream
consumer finance apps, which is what makes it a strong, defensible project to
build on, present, or take to a patent attorney if you want to pursue that
seriously.


---

## Bill scanner — notes

* **First run:** `cd frontend && npm install` (adds `tesseract.js`). The OCR engine and English model are already copied into `frontend/public/tesseract/` (~15 MB), so scanning works with no internet.
* **Camera needs a secure context** — it works on `http://localhost` and on https. On a phone over plain LAN http, the app falls back to the phone's native camera/photo picker automatically.
* **Best results:** flat bill, good light, fill the frame. If OCR struggles, use the *Paste text* tab.
* **Existing databases** are upgraded automatically on startup (new `expenses.source` column). `python seed_data.py` also adds demo subscriptions so the radar has something to show.
* **Tests:** `cd backend && pip install pytest && python -m pytest tests -q` (21 tests: parser on restaurant / supermarket / US-style / noisy receipts, OCR digit repair, date voting, duplicates, quick-add phrases, forecast & jar endpoints).
* **Languages:** add new UI text in English with `t("…")`, then run `npm run i18n:extract` and `npm run i18n:check` to see which catalogs need the new strings. Demo family: log in as demo@spendsense.app and open **Family** (invite code `DEMO42`).


---

## Database reliability (what changed)

* A relative SQLite path is now anchored to `backend/`, so starting `uvicorn` from any folder always uses the same `spendsense.db` (before, a different folder silently created an empty one).
* Missing columns are added automatically on startup for SQLite, MySQL **and** Postgres.
* An empty database is auto-seeded with the demo accounts (disable with `AUTO_SEED=0`); demo accounts' history is shifted forward so "this month" is never empty. Real accounts are never touched.
* The request limiter no longer counts browser pre-flight (OPTIONS) calls and allows 600 requests/minute per IP (30 login/register attempts per minute). Tune with `RATE_LIMIT` / `AUTH_RATE_LIMIT` in `backend/.env`.
* `GET /health` and Settings → *Your data* show database status; `python check_db.py [--repair]` diagnoses and repairs from the terminal.

## Scanner accuracy

`cd frontend && npm install` first. Benchmark method: 8 receipt layouts × 3 conditions (clean / tilted+shadow+blur / low-res photo on a dark table) = 24 images with known answers, OCR'd with the same bundled engine. Old pipeline vs new: correct total 10/24 → 23/24, correct date 17/24 → 24/24, merchant 19/24 → 24/24, and all three fields correct on 23/24 images (10/24 before). These are synthetic images and the parser was tuned on them, so treat the numbers as a relative comparison, not a promise for every real-world photo — the review screen still highlights uncertain fields and nothing is saved without confirmation.

## What was removed (and why)

* **Age-mode preview banner** on the Dashboard — it was a demo shortcut; the real switch lives in Settings → Platform mode.
* **Database table counts** in Settings and on the public `/health` endpoint — developer detail that also exposed how much data the server holds.
