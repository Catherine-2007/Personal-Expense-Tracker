import { useEffect, useState } from "react";
import ConfettiBurst from "../components/ConfettiBurst";
import api from "../api";
import ParticleHeader from "../components/ParticleHeader";
import PiggyBank from "../components/PiggyBank";
import { useAuth } from "../AuthContext";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { useLanguage } from "../LanguageContext";
import { useFeedback } from "../FeedbackContext";
import Icon from "../components/Icon";

import { formatDate, t } from "../i18n";

export default function Goals() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const currency = user?.currency || "INR";
  const { money, toBase, toDisplay } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isTeen = mode === "teen";
  const isSenior = mode === "senior";
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ title: "", target_amount: "", saved_amount: "0", deadline: "" });
  const [submitting, setSubmitting] = useState(false);
  const [celebrate, setCelebrate] = useState(false);
  const [open, setOpen] = useState({});          // goal id -> "add" | "take" | "edit" | "history"
  const [draft, setDraft] = useState({});        // goal id -> { amount, note, title, target, deadline }
  const [history, setHistory] = useState({});
  const [busyId, setBusyId] = useState(null);
  const [errors, setErrors] = useState({});
  const { confirm, notify } = useFeedback();

  async function load() {
    setLoading(true);
    const { data } = await api.get("/goals");
    setGoals(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.title || !form.target_amount || !form.deadline) return;
    setSubmitting(true);
    try {
      await api.post("/goals", {
        title: form.title,
        target_amount: toBase(form.target_amount),
        saved_amount: toBase(form.saved_amount) || 0,
        deadline: new Date(form.deadline).toISOString(),
      });
      setForm({ title: "", target_amount: "", saved_amount: "0", deadline: "" });
      await load();
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id) {
    if (!(await confirm({ message: t("Delete this goal? This can't be undone."), danger: true }))) return;
    await api.delete(`/goals/${id}`);
    setGoals((prev) => prev.filter((g) => g.id !== id));
    notify(t("Goal deleted"));
  }

  const setD = (id, patch) => setDraft((d) => ({ ...d, [id]: { ...(d[id] || {}), ...patch } }));
  const toggle = (id, what, g) => {
    setErrors((e) => ({ ...e, [id]: null }));
    setOpen((o) => ({ ...o, [id]: o[id] === what ? null : what }));
    if (what === "edit") setD(id, { title: g.title, target: String(toDisplay(g.target_amount)), deadline: String(g.deadline).slice(0, 10) });
    if (what === "history") api.get(`/goals/${id}/history`).then((r) => setHistory((h) => ({ ...h, [id]: r.data }))).catch(() => {});
  };

  async function applyMoney(g, sign, preset) {
    const raw = preset ?? Number(draft[g.id]?.amount);
    if (!raw || raw <= 0) { setErrors((e) => ({ ...e, [g.id]: t("Enter an amount greater than zero.") })); return; }
    setBusyId(g.id); setErrors((e) => ({ ...e, [g.id]: null }));
    try {
      const { data } = await api.post(`/goals/${g.id}/contribute`, { amount: sign * toBase(raw), note: draft[g.id]?.note || "" });
      setGoals((prev) => prev.map((x) => (x.id === g.id ? data : x)));
      setD(g.id, { amount: "", note: "" });
      setOpen((o) => ({ ...o, [g.id]: null }));
      if (sign > 0 && g.saved_amount < g.target_amount && data.saved_amount >= data.target_amount) setCelebrate(true);
      window.dispatchEvent(new Event("ss:goals-changed"));
    } catch (err) {
      setErrors((e) => ({ ...e, [g.id]: err?.response?.data?.detail || t("Something went wrong — try again.") }));
    } finally { setBusyId(null); }
  }

  async function saveEdit(g) {
    const d = draft[g.id] || {};
    if (!d.title?.trim() || !(Number(d.target) > 0) || !d.deadline) { setErrors((e) => ({ ...e, [g.id]: t("Please fill in every field.") })); return; }
    setBusyId(g.id);
    try {
      const { data } = await api.patch(`/goals/${g.id}`, { title: d.title.trim(), target_amount: toBase(d.target), deadline: new Date(d.deadline).toISOString() });
      setGoals((prev) => prev.map((x) => (x.id === g.id ? data : x)));
      setOpen((o) => ({ ...o, [g.id]: null }));
    } catch (err) {
      setErrors((e) => ({ ...e, [g.id]: err?.response?.data?.detail || t("Something went wrong — try again.") }));
    } finally { setBusyId(null); }
  }

  function MoneyPanel({ g }) {
    const mode_ = open[g.id];
    if (!mode_) return null;
    const d = draft[g.id] || {};
    const inputStyle = { fontSize: isSenior ? "1.05rem" : undefined };
    if (mode_ === "history") {
      const rows = history[g.id];
      return (
        <div className="goal-panel">
          {!rows ? <small>{t("Loading…")}</small> : rows.length === 0 ? <small>{t("No deposits yet.")}</small> : rows.map((r) => (
            <div key={r.id} className="goal-hist-row">
              <span>{formatDate(r.created_at, { day: "numeric", month: "short", year: "numeric" })}{r.note ? ` · ${r.note}` : ""}</span>
              <b style={{ color: r.amount >= 0 ? "var(--teal)" : "var(--coral)" }}>{r.amount >= 0 ? "+" : "−"}{money(Math.abs(r.amount))}</b>
            </div>
          ))}
        </div>
      );
    }
    if (mode_ === "edit") {
      return (
        <div className="goal-panel">
          <label>{t("Title")}</label>
          <input value={d.title || ""} onChange={(e) => setD(g.id, { title: e.target.value })} style={inputStyle} />
          <label>{t("Target ({currency})", { currency })}</label>
          <input type="number" min="1" value={d.target || ""} onChange={(e) => setD(g.id, { target: e.target.value })} style={inputStyle} />
          <label>{t("Deadline")}</label>
          <input type="date" value={d.deadline || ""} onChange={(e) => setD(g.id, { deadline: e.target.value })} style={inputStyle} />
          <div className="goal-actions">
            <button className="btn-primary" disabled={busyId === g.id} onClick={() => saveEdit(g)}>{t("Save")}</button>
            <button className="btn-ghost" onClick={() => toggle(g.id, "edit", g)}>{t("Cancel")}</button>
          </div>
          {errors[g.id] && <div className="goal-err">{errors[g.id]}</div>}
        </div>
      );
    }
    const sign = mode_ === "add" ? 1 : -1;
    const remaining = Math.max(0, toDisplay(g.target_amount - g.saved_amount));
    const presets = sign > 0 ? [100, 500, 1000, 5000].map((x) => (currency === "JPY" ? x * 10 : x)) : [];
    return (
      <div className="goal-panel">
        <label>{sign > 0 ? t("Amount to add ({currency})", { currency }) : t("Amount to take out ({currency})", { currency })}</label>
        <input type="number" min="0" step="any" autoFocus value={d.amount || ""} onChange={(e) => setD(g.id, { amount: e.target.value })}
          onKeyDown={(e) => e.key === "Enter" && applyMoney(g, sign)} style={inputStyle} />
        {sign > 0 && (
          <div className="goal-chips">
            {presets.map((x) => <button key={x} type="button" className="chip" onClick={() => setD(g.id, { amount: String(x) })}>+{x}</button>)}
            {remaining > 0 && <button type="button" className="chip" onClick={() => setD(g.id, { amount: String(remaining) })}>{t("Fill it up!")}</button>}
          </div>
        )}
        {!isKid && <>
          <label>{t("Note (optional)")}</label>
          <input value={d.note || ""} maxLength={200} onChange={(e) => setD(g.id, { note: e.target.value })} style={inputStyle} />
        </>}
        <div className="goal-actions">
          <button className="btn-primary" disabled={busyId === g.id} onClick={() => applyMoney(g, sign)}>
            {sign > 0 ? (isKid ? t("Feed the piggy! 🐷") : t("Add money")) : t("Take out")}
          </button>
          <button className="btn-ghost" onClick={() => toggle(g.id, mode_, g)}>{t("Cancel")}</button>
        </div>
        {errors[g.id] && <div className="goal-err">{errors[g.id]}</div>}
      </div>
    );
  }

  function GoalActions({ g }) {
    const done = g.saved_amount >= g.target_amount;
    const big = isSenior ? { fontSize: "1rem", padding: "0.55rem 0.9rem" } : { fontSize: "0.78rem", padding: "0.35rem 0.7rem" };
    return (
      <div className="goal-btns" style={{ justifyContent: isKid ? "center" : undefined }}>
        <button className="btn-primary" style={big} onClick={() => toggle(g.id, "add", g)}>{isKid ? t("🪙 Add coins") : t("＋ Add money")}</button>
        {g.saved_amount > 0 && <button className="btn-ghost" style={big} onClick={() => toggle(g.id, "take", g)}>{t("Take out")}</button>}
        {!isKid && <button className="btn-ghost" style={big} onClick={() => toggle(g.id, "edit", g)}>{t("Edit")}</button>}
        {!isKid && <button className="btn-ghost" style={big} onClick={() => toggle(g.id, "history", g)}>{t("History")}</button>}
        {done && <span className="pill pill-teal" style={{ alignSelf: "center" }}>{t("🏁 Goal reached!")}</span>}
      </div>
    );
  }

  return (
    <div>
      {celebrate && <ConfettiBurst onDone={() => setCelebrate(false)} />}
      <ParticleHeader
        mode={user?.platform_mode}
        title={isKid ? t("My Piggy Bank") : t("goals.title")}
        subtitle={
          isKid
            ? t("Tell me what you're saving up for and watch your piggy bank fill up!")
            : t(
            "Goals feed the Goal-Conflict Detector on your monthly report — it flags when your spending pace won't get you there in time."
          )
        }
      />

      <div className="card" style={{ marginBottom: "1.2rem" }}>
        <span className="eyebrow">{isKid ? t("What are you saving for?") : t("New goal")}</span>
        <form onSubmit={handleSubmit} style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr auto", gap: "0.8rem", alignItems: "end", marginTop: "0.6rem" }}>
          <div>
            <label>{isKid ? t("What is it?") : t("Title")}</label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder={isKid ? t("New bike") : t("Buy Laptop")} />
          </div>
          <div>
            <label>{t("Target ({currency})", { currency })}</label>
            <input type="number" min="1" required value={form.target_amount} onChange={(e) => setForm({ ...form, target_amount: e.target.value })} placeholder="60000" />
          </div>
          <div>
            <label>{t("Already saved ({currency})", { currency })}</label>
            <input type="number" min="0" value={form.saved_amount} onChange={(e) => setForm({ ...form, saved_amount: e.target.value })} />
          </div>
          <div>
            <label>{isKid ? t("By when?") : t("Deadline")}</label>
            <input type="date" required value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
          </div>
          <button className="btn-primary" type="submit" disabled={submitting}>{submitting ? t("Saving…") : t("Add goal")}</button>
        </form>
      </div>

      {!loading && !isKid && goals.length > 0 && (() => {
        const saved = goals.reduce((a, g) => a + g.saved_amount, 0);
        const target = goals.reduce((a, g) => a + g.target_amount, 0);
        const reached = goals.filter((g) => g.saved_amount >= g.target_amount).length;
        return (
          <div className="stat-strip">
            <div className="stat"><small>{t("Total saved")}</small><b>{money(saved)}</b></div>
            <div className="stat"><small>{t("Total target")}</small><b>{money(target)}</b></div>
            <div className="stat"><small>{t("Goals reached")}</small><b>{reached} / {goals.length}</b></div>
          </div>
        );
      })()}

      {loading ? (
        <div className="skel-grid">{[0, 1, 2].map((i) => <div key={i} className="skeleton" style={{ height: 150 }} />)}</div>
      ) : (
        <div style={{
          display: isSenior ? "flex" : "grid",
          flexDirection: isSenior ? "column" : undefined,
          gridTemplateColumns: isSenior ? undefined : `repeat(auto-fill, minmax(${isKid ? 220 : 260}px, 1fr))`,
          gap: "1rem", maxWidth: isSenior ? 720 : undefined,
        }}>
          {goals.map((g) => {
            const pct = Math.min(100, (g.saved_amount / g.target_amount) * 100);
            const milestone = pct >= 100 ? t("🏁 Goal reached!") : pct >= 75 ? t("🔥 Almost there!") : pct >= 50 ? t("💪 Halfway there!") : pct >= 25 ? t("🚀 Off to a good start!") : null;
            return (
              <div key={g.id} className="card" style={{ textAlign: isKid ? "center" : "left" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <h3 style={{ margin: 0, fontSize: isSenior ? "1.2rem" : "1rem" }}>{g.title}</h3>
                  <button className="icon-btn danger" title={t("Delete")} aria-label={t("Delete")} onClick={() => handleDelete(g.id)}><Icon name="trash" size={isSenior ? 22 : 17} /></button>
                </div>

                {isKid ? (
                  <PiggyBank pct={pct} label={t("{saved} of {target}", { saved: money(g.saved_amount), target: money(g.target_amount) })} />
                ) : isSenior ? (
                  <>
                    <p style={{ fontSize: "1.05rem", margin: "0.5rem 0" }}>
                      {t("{saved} saved of {target} goal, due {date}", { saved: money(g.saved_amount), target: money(g.target_amount), date: formatDate(g.deadline, { year: "numeric", month: "short", day: "numeric" }) })}
                    </p>
                    <div style={{ height: 16, borderRadius: 8, background: "var(--surface-raised)", overflow: "hidden" }}>
                      <div className="grow-bar" style={{ width: `${pct}%`, height: "100%", background: "var(--teal)" }} />
                    </div>
                    <div style={{ fontSize: "1rem", color: "var(--text-muted)", marginTop: "0.4rem" }}>{t("{pct}% funded", { pct: Math.round(pct) })}</div>
                  </>
                ) : (
                  <>
                    <p style={{ fontSize: "0.8rem" }}>
                      {t("{saved} of {target} · due {date}", { saved: money(g.saved_amount), target: money(g.target_amount), date: formatDate(g.deadline, { year: "numeric", month: "short", day: "numeric" }) })}
                    </p>
                    <div style={{ height: 8, borderRadius: 4, background: "var(--surface-raised)", overflow: "hidden" }}>
                      <div className="grow-bar" style={{ width: `${pct}%`, height: "100%", background: "var(--teal)" }} />
                    </div>
                    <div style={{ fontSize: "0.74rem", color: "var(--text-muted)", marginTop: "0.3rem" }}>
                      {t("{pct}% funded", { pct: Math.round(pct) })}
                      {isTeen && milestone && <span style={{ color: "var(--violet)", marginLeft: "0.4rem" }}>· {milestone}</span>}
                    </div>
                  </>
                )}
                {GoalActions({ g })}
                {MoneyPanel({ g })}
              </div>
            );
          })}
          {goals.length === 0 && <div className="empty-state card" style={{ gridColumn: "1 / -1" }}><Icon name="goals" size={28} /><b>{t("No goals yet — add one above.")}</b></div>}
        </div>
      )}
    </div>
  );
}
