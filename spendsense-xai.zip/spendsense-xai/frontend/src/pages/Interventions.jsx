import { useEffect, useState } from "react";
import api from "../api";
import ParticleHeader from "../components/ParticleHeader";
import ConfettiBurst from "../components/ConfettiBurst";
import { useAuth } from "../AuthContext";
import { useLanguage } from "../LanguageContext";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";

import { N_, t } from "../i18n";

const STATUS_PILL = {
  testing: "pill-amber",
  active: "pill-teal",
  stopped: "pill-coral",
};

const STATUS_LABEL = {
  adult: { testing: N_("testing"), active: N_("active"), stopped: N_("stopped") },
  teen: { testing: N_("In progress"), active: N_("Crushing it! 🔥"), stopped: N_("Retired") },
  kid: { testing: N_("Trying it out! 🧪"), active: N_("It's working! 🎉"), stopped: N_("Trying something else") },
  senior: { testing: N_("Being tried"), active: N_("Working well"), stopped: N_("Stopped") },
};

export default function Interventions() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const currency = user?.currency || "INR";
  const { money } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isSenior = mode === "senior";
  const labels = STATUS_LABEL[mode] || STATUS_LABEL.adult;

  const [interventions, setInterventions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [burst, setBurst] = useState(false);

  async function load() {
    setLoading(true);
    const { data } = await api.get("/interventions");
    setInterventions(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function measure(id) {
    const { data } = await api.post(`/interventions/${id}/measure`);
    setInterventions((prev) => prev.map((i) => (i.id === id ? data : i)));
  }

  async function feedback(id, value) {
    const { data } = await api.post(`/interventions/${id}/feedback`, { feedback: value });
    setInterventions((prev) => prev.map((i) => (i.id === id ? data : i)));
    if (isKid && value === "up") setBurst(true);
  }

  return (
    <div style={{ maxWidth: isSenior ? 720 : undefined }}>
      {burst && <ConfettiBurst onDone={() => setBurst(false)} />}

      <ParticleHeader
        mode={mode}
        title={isKid ? t("My Missions") : isSenior ? t("Suggested Changes") : t("interventions.title")}
        subtitle={
          isKid
            ? t("Little missions to try — tell me if they help!")
            : isSenior
            ? t(
            "Small suggestions based on your spending. Try one, then tell the app if it helped."
          )
            : t(
            "Each nudge is one of two competing approaches (A/B testing), measured against your own before/after spend, and can be corrected with your feedback."
          )
        }
      />

      {loading ? <p>{t("Loading…")}</p> : interventions.length === 0 ? (
        <div className="card">
          <p>
            {isKid
              ? t(
              "No missions yet — go to My Patterns and tap 'Get a fun tip!' on a pattern."
            )
              : t(
              "No interventions yet — go to Triggers & XAI and click \"Suggest an intervention\" on a pattern."
            )}
          </p>
        </div>
      ) : isKid ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))", gap: "1rem" }}>
          {interventions.map((iv) => (
            <div key={iv.id} className="card" style={{ textAlign: "center" }}>
              <div style={{ fontSize: "2rem" }}>🎯</div>
              <span className={`pill ${STATUS_PILL[iv.status]}`} style={{ marginTop: "0.4rem" }}>{t(labels[iv.status])}</span>
              <p style={{ fontSize: "0.88rem", margin: "0.6rem 0" }}>{iv.description}</p>
              <div style={{ display: "flex", justifyContent: "center", gap: "0.5rem", marginBottom: "0.5rem" }}>
                <button className="btn-primary" style={{ fontSize: "0.85rem" }} onClick={() => measure(iv.id)}>{t("Check it!")}</button>
              </div>
              <div style={{ display: "flex", justifyContent: "center", gap: "0.5rem" }}>
                <button
                  style={{ fontSize: "1.3rem", background: iv.user_feedback === "up" ? "var(--teal)" : "var(--surface-raised)", borderRadius: 10, padding: "0.4rem 0.8rem" }}
                  onClick={() => feedback(iv.id, "up")}
                >👍</button>
                <button
                  style={{ fontSize: "1.3rem", background: iv.user_feedback === "down" ? "var(--coral)" : "var(--surface-raised)", borderRadius: 10, padding: "0.4rem 0.8rem" }}
                  onClick={() => feedback(iv.id, "down")}
                >👎</button>
              </div>
            </div>
          ))}
        </div>
      ) : isSenior ? (
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          {interventions.map((iv) => (
            <div key={iv.id} className="card">
              <span className={`pill ${STATUS_PILL[iv.status]}`} style={{ fontSize: "0.85rem" }}>{t(labels[iv.status])}</span>
              <p style={{ fontSize: "1.1rem", margin: "0.6rem 0", lineHeight: 1.5 }}>{iv.description}</p>
              {iv.effectiveness_pct != null && (
                <p style={{ fontSize: "1rem", color: iv.effectiveness_pct < 0 ? "var(--teal)" : "var(--coral)" }}>
                  {iv.effectiveness_pct < 0 ? t("This is helping — your spending went down.") : t("This hasn't reduced spending yet.")}
                </p>
              )}
              <div style={{ display: "flex", gap: "0.6rem", marginTop: "0.6rem" }}>
                <button className="btn-ghost" style={{ fontSize: "1rem" }} onClick={() => measure(iv.id)}>{t("Check result")}</button>
                <button className="btn-ghost" style={{ fontSize: "1rem" }} onClick={() => feedback(iv.id, "up")}>{t("👍 Helped")}</button>
                <button className="btn-ghost" style={{ fontSize: "1rem" }} onClick={() => feedback(iv.id, "down")}>{t("👎 Didn't help")}</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "0.9rem" }}>
          {interventions.map((iv) => (
            <div key={iv.id} className="card" style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: "1rem", alignItems: "center" }}>
              <div>
                <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.5rem" }}>
                  <span className="pill pill-muted">{t(iv.intervention_type)}</span>
                  <span className="pill pill-muted">{t("Variant {v}", { v: iv.variant })}</span>
                  <span className={`pill ${STATUS_PILL[iv.status]}`}>{t(labels[iv.status])}</span>
                </div>
                <p style={{ margin: 0, fontSize: "0.9rem", color: "var(--text-primary)" }}>{iv.description}</p>
                {iv.effectiveness_pct != null && (
                  <div style={{ marginTop: "0.5rem", fontSize: "0.82rem", color: iv.effectiveness_pct < 0 ? "var(--teal)" : "var(--coral)" }}>
                    {t("Effectiveness: {pct}% spend change (avg {from} → {to} per transaction)", { pct: (iv.effectiveness_pct > 0 ? "+" : "") + iv.effectiveness_pct, from: money(iv.baseline_avg), to: money(iv.result_avg) })}
                  </div>
                )}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem", alignItems: "flex-end" }}>
                <button className="btn-ghost" onClick={() => measure(iv.id)}>{t("Measure result")}</button>
                <div style={{ display: "flex", gap: "0.4rem" }}>
                  <button
                    className="btn-ghost"
                    style={{ color: iv.user_feedback === "up" ? "var(--teal)" : undefined, borderColor: iv.user_feedback === "up" ? "var(--teal)" : undefined }}
                    onClick={() => feedback(iv.id, "up")}
                  >👍</button>
                  <button
                    className="btn-ghost"
                    style={{ color: iv.user_feedback === "down" ? "var(--coral)" : undefined, borderColor: iv.user_feedback === "down" ? "var(--coral)" : undefined }}
                    onClick={() => feedback(iv.id, "down")}
                  >👎</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
