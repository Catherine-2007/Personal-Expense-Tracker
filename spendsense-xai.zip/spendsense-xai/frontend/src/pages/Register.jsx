import { useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { useLanguage } from "../LanguageContext";
import { CURRENCIES } from "../currency";
import AuthShell from "../components/AuthShell";

import { N_, t, tn } from "../i18n";

function computeAge(dobStr) {
  if (!dobStr) return null;
  const dob = new Date(dobStr);
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const monthDiff = today.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

function tierFor(age) {
  if (age === null) return "adult";
  if (age < 13) return "kid";
  if (age < 18) return "teen";
  if (age < 60) return "adult";
  return "senior";
}

const TIER_INFO = {
  kid: { label: N_("Playground experience"), blurb: N_("Big buttons, simple words, extra encouragement."), theme: "kid" },
  teen: { label: N_("Guided experience"), blurb: N_("Full features with more explanation along the way."), theme: "night" },
  adult: { label: N_("Full experience"), blurb: N_("Everything unlocked, no simplification."), theme: "night" },
  senior: { label: N_("Comfort experience"), blurb: N_("Larger text, higher contrast, a simpler single-column layout."), theme: "senior" },
};

export default function Register() {
  const { register } = useAuth();
  const { t, lang, setLang, languages } = useLanguage();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [dob, setDob] = useState("");
  const [currency, setCurrency] = useState("INR");
  const [income, setIncome] = useState("");
  const [savings, setSavings] = useState("");
  const [guardianConfirmed, setGuardianConfirmed] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const age = useMemo(() => computeAge(dob), [dob]);
  const tier = tierFor(age);
  const needsGuardian = age !== null && age < 13;

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (needsGuardian && !guardianConfirmed) {
      setError(t("Please confirm a parent or guardian is okay with this before continuing."));
      return;
    }
    setLoading(true);
    try {
      await register({
        name, email, password,
        date_of_birth: dob || null,
        platform_mode: tier,
        monthly_income: Number(income) || 0,
        current_savings: Number(savings) || 0,
        currency, language: lang,
        theme: TIER_INFO[tier].theme,
        guardian_confirmed: guardianConfirmed,
      });
      navigate("/");
    } catch (err) {
      setError(err?.response?.data?.detail || t("Could not create account."));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell>
      <div className="card auth-card">
        <span className="eyebrow">{t("Get started")}</span>
        <h2>{t("register.heading")}</h2>
        <p style={{ fontSize: "0.85rem" }}>{t(
          "Financial figures are only used locally by your own dashboard — never shared or compared to other users."
        )}</p>
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "0.9rem", marginTop: "1rem" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.7rem" }}>
            <div>
              <label>{t("common.name")}</label>
              <input required value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <label>{t("Date of birth")}</label>
              <input type="date" value={dob} max={new Date().toISOString().split("T")[0]} onChange={(e) => setDob(e.target.value)} />
            </div>
          </div>

          {dob !== "" && (
            <div style={{
              display: "flex", alignItems: "center", gap: "0.6rem", fontSize: "0.78rem",
              background: "var(--surface-raised)", padding: "0.6rem 0.8rem", borderRadius: 10,
            }}>
              <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--teal)", flexShrink: 0 }} />
              <span>
                {tn("Age {age} → {mode} — {blurb}", { age, mode: <strong>{t(TIER_INFO[tier].label)}</strong>, blurb: t(TIER_INFO[tier].blurb) })}
              </span>
            </div>
          )}

          <div>
            <label>{t("common.email")}</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label>{t("common.password")} {t("(min 8 characters)")}</label>
            <input type="password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.7rem" }}>
            <div>
              <label>{t("register.currency")}</label>
              <select value={currency} onChange={(e) => setCurrency(e.target.value)}>
                {CURRENCIES.map((c) => <option key={c.code} value={c.code}>{t(c.label)}</option>)}
              </select>
            </div>
            <div>
              <label>{t("register.language")}</label>
              <select value={lang} onChange={(e) => setLang(e.target.value)}>
                {languages.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
              </select>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.7rem" }}>
            <div>
              <label>{t("register.income")}</label>
              <input type="number" min="0" value={income} onChange={(e) => setIncome(e.target.value)} placeholder="45000" />
            </div>
            <div>
              <label>{t("register.savings")}</label>
              <input type="number" min="0" value={savings} onChange={(e) => setSavings(e.target.value)} placeholder="0" />
            </div>
          </div>

          {needsGuardian && (
            <label style={{ display: "flex", alignItems: "flex-start", gap: "0.5rem", fontSize: "0.8rem", background: "var(--surface-raised)", padding: "0.7rem", borderRadius: 10 }}>
              <input
                type="checkbox"
                style={{ width: "auto", marginTop: "0.15rem" }}
                checked={guardianConfirmed}
                onChange={(e) => setGuardianConfirmed(e.target.checked)}
              />
              <span>{t("register.guardian")}</span>
            </label>
          )}

          {error && <div style={{ color: "var(--coral)", fontSize: "0.82rem" }}>{error}</div>}
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? "…" : t("Create account")}
          </button>
        </form>
        <p style={{ marginTop: "1rem", fontSize: "0.82rem" }}>
          {t("register.haveAccount")} <Link to="/login">{t("common.signIn")}</Link>
        </p>
      </div>
    </AuthShell>
  );
}
