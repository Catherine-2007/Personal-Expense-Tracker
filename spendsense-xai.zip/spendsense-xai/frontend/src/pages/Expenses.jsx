import { useEffect, useState } from "react";
import api from "../api";
import ParticleHeader from "../components/ParticleHeader";
import ConfettiBurst from "../components/ConfettiBurst";
import QuickAdd from "../components/QuickAdd";
import { useAuth } from "../AuthContext";
import { useFeedback } from "../FeedbackContext";
import Icon from "../components/Icon";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { useLanguage } from "../LanguageContext";
import { iconFor } from "../categoryIcons";

import { N_, formatDate, formatDateTime, plain, t, tp } from "../i18n";

const CATEGORIES = [N_("Food"), N_("Groceries"), N_("Shopping"), N_("Transport"), N_("Bills"), N_("Entertainment"), N_("Health"), N_("Others")];
const PAYMENT_METHODS = [N_("UPI"), N_("Card"), N_("Cash"), N_("Wallet"), N_("Bank")];
const KID_ENCOURAGEMENTS = [
  N_("Nice tracking! 🌟"), N_("You're doing great! 🎉"), N_("Awesome job logging that! 🚀"),
  N_("Way to go! ⭐"), N_("You're a money tracking star! ✨"),
];

export default function Expenses() {
  const { user } = useAuth();
  const { confirm, notify } = useFeedback();
  const { t } = useLanguage();
  const currency = user?.currency || "INR";
  const { money, toBase, toDisplay } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isTeen = mode === "teen";
  const isSenior = mode === "senior";

  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const todayStr = () => new Date().toISOString().slice(0, 10);
  const blank = () => ({ amount: "", merchant: "", payment_method: "UPI", note: "", category: "", date: todayStr() });
  const [form, setForm] = useState(blank);
  const [filters, setFilters] = useState({ q: "", category: "", range: "all" });
  const [editing, setEditing] = useState(null);     // expense being edited
  const [editErr, setEditErr] = useState("");
  const [formErr, setFormErr] = useState("");
  const [budgetNote, setBudgetNote] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [celebration, setCelebration] = useState(null);
  const [newId, setNewId] = useState(null);

  async function load() {
    setLoading(true);
    const params = {};
    if (filters.q.trim()) params.q = filters.q.trim();
    if (filters.category) params.category = filters.category;
    const now = new Date();
    if (filters.range === "month") params.start = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
    if (filters.range === "30d") params.start = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
    const { data } = await api.get("/expenses", { params });
    setExpenses(data);
    setLoading(false);
  }

  useEffect(() => { const id = setTimeout(load, filters.q ? 250 : 0); return () => clearTimeout(id); }, [filters]); // eslint-disable-line

  // Refresh when a bill is scanned from anywhere in the app.
  useEffect(() => {
    const onAdded = (ev) => { setNewId(ev.detail?.id ?? null); load(); };
    window.addEventListener("ss:expense-added", onAdded);
    return () => window.removeEventListener("ss:expense-added", onAdded);
  }, []);

  function handleQuickSaved(exp) {
    window.dispatchEvent(new CustomEvent("ss:expense-added", { detail: exp, bubbles: false }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!(Number(form.amount) > 0)) { setFormErr(t("Enter an amount greater than zero.")); return; }
    setFormErr("");
    setSubmitting(true);
    try {
      const body = {
        amount: toBase(form.amount),
        merchant: form.merchant,
        payment_method: form.payment_method,
        note: form.note,
      };
      if (form.category) body.category = form.category;
      if (form.date && form.date !== todayStr()) body.timestamp = new Date(form.date + "T12:00:00").toISOString().slice(0, 19);
      const { data: created } = await api.post("/expenses", body);
      setForm(blank());
      checkBudget(created.category);
      await load();
      window.dispatchEvent(new Event("ss:expense-added"));
      if (isKid) {
        setCelebration(t(KID_ENCOURAGEMENTS[Math.floor(Math.random() * KID_ENCOURAGEMENTS.length)]));
      }
    } finally {
      setSubmitting(false);
    }
  }

  async function checkBudget(category) {
    try {
      const { data } = await api.get("/budgets");
      const hit = [data.overall, data.items.find((x) => x.category === category)].filter((x) => x && x.status !== "ok");
      const worst = hit.sort((a, b) => b.pct - a.pct)[0];
      if (!worst) { setBudgetNote(null); return; }
      const name = worst.category === "ALL" ? t("Everything (overall)") : t(worst.category);
      setBudgetNote({ over: worst.status === "over", text: worst.status === "over"
        ? t("⚠️ You're over your {name} budget ({pct}% used).", { name, pct: Math.round(worst.pct) })
        : t("Heads up: you've used {pct}% of your {name} budget.", { name, pct: Math.round(worst.pct) }) });
    } catch { /* budgets are optional */ }
  }

  async function saveEdit() {
    const d = editing;
    if (!(Number(d.amount) > 0)) { setEditErr(t("Enter an amount greater than zero.")); return; }
    try {
      await api.patch(`/expenses/${d.id}`, {
        amount: toBase(d.amount), merchant: d.merchant, category: d.category, payment_method: d.payment_method,
        note: d.note, timestamp: new Date(d.date + "T" + (d.time || "12:00")).toISOString().slice(0, 19),
      });
      setEditing(null); setEditErr("");
      await load();
    } catch (err) {
      setEditErr(err?.response?.data?.detail || t("Something went wrong — try again."));
    }
  }

  function startEdit(e) {
    const dt = new Date(e.timestamp);
    const pad = (n) => String(n).padStart(2, "0");
    setEditErr("");
    setEditing({
      id: e.id, amount: String(toDisplay(e.amount)), merchant: e.merchant || "", category: e.category,
      payment_method: e.payment_method || "UPI", note: e.note || "",
      date: `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`, time: `${pad(dt.getHours())}:${pad(dt.getMinutes())}`,
    });
  }

  async function handleDelete(id) {
    if (!(await confirm({ message: t("Delete this expense?"), danger: true }))) return;
    await api.delete(`/expenses/${id}`);
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    notify(t("Expense deleted"));
  }

  const recentTip = isTeen && expenses.length > 0
    ? tp(expenses.length, "You've logged {n} expense — the more you log, the sharper your patterns get.", "You've logged {n} expenses — the more you log, the sharper your patterns get.")
    : null;

  return (
    <div style={{ maxWidth: isSenior ? 720 : undefined }}>
      {celebration && <ConfettiBurst onDone={() => setCelebration(null)} />}

      <ParticleHeader
        mode={mode}
        action={
          <button className="btn-primary" onClick={() => window.dispatchEvent(new Event("ss:open-scanner"))}
            style={{ marginBottom: "0.2rem", whiteSpace: "nowrap", display: "inline-flex", alignItems: "center", gap: ".45rem" }}>
            <Icon name="scan" size={17} /> {isKid ? t("Snap a receipt") : t("Scan a bill")}
          </button>
        }
        title={isKid ? t("Add Spending") : t("expenses.title")}
        subtitle={
          isKid
            ? t("Tell me what you bought — I'll figure out the category for you!")
            : isSenior
            ? t(
            "Add a purchase below. The app will sort it into a category for you automatically."
          )
            : t(
            "Category is auto-detected from the merchant/note — you can always see and override what the system inferred."
          )
        }
      />

      {celebration && (
        <div className="card" style={{ marginBottom: "1rem", textAlign: "center", background: "linear-gradient(135deg, rgba(255,159,28,0.15), rgba(0,194,168,0.12))" }}>
          <span style={{ fontSize: "1.3rem", fontWeight: 700 }}>{celebration}</span>
        </div>
      )}

      {budgetNote && (
        <div className="card" style={{ marginBottom: "1rem", border: `1px solid ${budgetNote.over ? "var(--coral)" : "var(--amber)"}` }}>
          <span style={{ fontSize: isSenior ? "1.1rem" : "0.9rem" }}>{budgetNote.text}</span>
        </div>
      )}

      {recentTip && (
        <div className="card" style={{ marginBottom: "1rem", border: "1px solid var(--violet)" }}>
          <span className="eyebrow" style={{ color: "var(--violet)" }}>{t("💡 Tip")}</span>
          <p style={{ margin: 0, fontSize: "0.86rem" }}>{recentTip}</p>
        </div>
      )}

      <QuickAdd mode={mode} onSaved={handleQuickSaved}
        onEdit={(d) => setForm({ ...blank(), amount: String(d.amount != null ? toDisplay(d.amount) : ""), merchant: d.merchant || "", payment_method: PAYMENT_METHODS.includes(d.payment_method) ? d.payment_method : "UPI", note: d.note || "", category: d.category || "" })} />

      <div className="card" style={{ marginBottom: "1.2rem" }}>
        <span className="eyebrow">{isKid ? t("What did you buy?") : isSenior ? t("Add a purchase") : t("Log an expense")}</span>
        <form
          onSubmit={handleSubmit}
          style={{
            display: "grid",
            gridTemplateColumns: isSenior ? "1fr" : "1fr 1.4fr 1fr 1.4fr auto",
            gap: isSenior ? "1rem" : "0.8rem",
            alignItems: "end",
            marginTop: "0.6rem",
          }}
        >
          <div>
            <label style={isSenior ? { fontSize: "1rem" } : undefined}>
              {isKid ? t("How much? 💰") : t("Amount ({currency})", { currency })}
            </label>
            <input
              type="number" min="0.01" step="0.01" required value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              placeholder="450"
              style={isSenior ? { fontSize: "1.1rem", padding: "0.9rem" } : undefined}
            />
          </div>
          <div>
            <label style={isSenior ? { fontSize: "1rem" } : undefined}>
              {isKid ? t("Where? 🏪") : t("Merchant")}
            </label>
            <input
              value={form.merchant} onChange={(e) => setForm({ ...form, merchant: e.target.value })}
              placeholder={isKid ? t("Candy shop, toy store...") : t("Swiggy")}
              style={isSenior ? { fontSize: "1.1rem", padding: "0.9rem" } : undefined}
            />
          </div>
          <div>
            <label style={isSenior ? { fontSize: "1rem" } : undefined}>
              {isKid ? t("How did you pay? 💳") : t("Payment")}
            </label>
            <select
              value={form.payment_method} onChange={(e) => setForm({ ...form, payment_method: e.target.value })}
              style={isSenior ? { fontSize: "1.1rem", padding: "0.9rem" } : undefined}
            >
              {PAYMENT_METHODS.map((p) => <option key={p} value={p}>{t(p)}</option>)}
            </select>
          </div>
          <div>
            <label style={isSenior ? { fontSize: "1rem" } : undefined}>
              {isKid ? t("Anything else? (optional)") : t("Note (optional)")}
            </label>
            <input
              value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })}
              placeholder={isKid ? t("for my birthday!") : t("late night order")}
              style={isSenior ? { fontSize: "1.1rem", padding: "0.9rem" } : undefined}
            />
          </div>
          <button
            className="btn-primary" type="submit" disabled={submitting}
            style={isSenior ? { fontSize: "1.1rem", padding: "0.9rem 1.4rem" } : undefined}
          >
            {submitting ? "…" : isKid ? t("Add it! 🎉") : t("Add")}
          </button>
          {!isKid && (
            <div style={{ gridColumn: "1 / -1", display: "flex", gap: "0.8rem", flexWrap: "wrap", alignItems: "end" }}>
              <div style={{ minWidth: 170 }}>
                <label style={isSenior ? { fontSize: "1rem" } : undefined}>{t("Category")}</label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  <option value="">{t("Auto-detect")}</option>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{t(c)}</option>)}
                </select>
              </div>
              <div style={{ minWidth: 170 }}>
                <label style={isSenior ? { fontSize: "1rem" } : undefined}>{t("Date")}</label>
                <input type="date" max={todayStr()} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value || todayStr() })} />
              </div>
              {formErr && <span className="goal-err">{formErr}</span>}
            </div>
          )}
          {isKid && formErr && <div style={{ gridColumn: "1 / -1" }} className="goal-err">{formErr}</div>}
        </form>
      </div>

      <div className="card" style={{ marginBottom: "1rem", padding: "0.8rem 1rem" }}>
        <div style={{ display: "flex", gap: "0.6rem", flexWrap: "wrap", alignItems: "center" }}>
          <div className="search-box" style={{ flex: "1 1 200px", minWidth: 160, maxWidth: "none" }}>
            <Icon name="search" size={16} />
            <input value={filters.q} placeholder={plain(t("🔎 Search merchant or note"))}
              onChange={(e) => setFilters({ ...filters, q: e.target.value })} aria-label={t("Search")} />
          </div>
          <select value={filters.category} onChange={(e) => setFilters({ ...filters, category: e.target.value })} aria-label={t("Category")} style={{ width: "auto" }}>
            <option value="">{t("All categories")}</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{t(c)}</option>)}
          </select>
          <select value={filters.range} onChange={(e) => setFilters({ ...filters, range: e.target.value })} aria-label={t("Date range")} style={{ width: "auto" }}>
            <option value="all">{t("All time")}</option>
            <option value="month">{t("This month")}</option>
            <option value="30d">{t("Last 30 days")}</option>
          </select>
          {(filters.q || filters.category || filters.range !== "all") && (
            <button type="button" className="btn-ghost" onClick={() => setFilters({ q: "", category: "", range: "all" })}>{t("Clear")}</button>
          )}
        </div>
        {!loading && (
          <div style={{ marginTop: "0.5rem", fontSize: isSenior ? "1rem" : "0.8rem", color: "var(--text-muted)" }}>
            {tp(expenses.length, "{n} expense", "{n} expenses")} · {t("Total")}: <b style={{ color: "var(--text-primary)" }}>{money(expenses.reduce((a, e) => a + e.amount, 0))}</b>
          </div>
        )}
      </div>

      <div className="card">
        <span className="eyebrow">
          {isKid ? t("What you've bought") : isSenior ? t("Your recent purchases") : t("Recent transactions")}
        </span>
        {loading ? <div style={{ display: "grid", gap: ".6rem", marginTop: ".8rem" }}>{[0, 1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ height: 44 }} />)}</div> : isSenior ? (
          <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem", marginTop: "0.6rem" }}>
            {expenses.length === 0 && <p style={{ fontSize: "1.05rem" }}>{t("No purchases logged yet — add your first one above.")}</p>}
            {expenses.map((e) => (
              <div key={e.id} style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                padding: "0.9rem 1rem", background: "var(--surface-raised)", borderRadius: 10,
              }}>
                <div>
                  <div style={{ fontSize: "1.1rem", fontWeight: 600 }}>{iconFor(e.category)} {e.merchant || t(e.category)}</div>
                  <div style={{ fontSize: "0.95rem", color: "var(--text-muted)" }}>
                    {formatDate(e.timestamp, { month: "long", day: "numeric" })} · {t(e.category)}
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "0.9rem" }}>
                  <div style={{ fontSize: "1.15rem", fontWeight: 700 }}>{money(e.amount)}</div>
                  <button className="btn-ghost" style={{ fontSize: "0.9rem" }} onClick={() => startEdit(e)}>{t("Edit")}</button>
                  <button className="btn-danger" style={{ fontSize: "0.9rem" }} onClick={() => handleDelete(e.id)}>{t("Remove")}</button>
                </div>
              </div>
            ))}
          </div>
        ) : isKid ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "0.7rem", marginTop: "0.6rem" }}>
            {expenses.length === 0 && <p>{t("Nothing here yet — add your first purchase above!")}</p>}
            {expenses.map((e) => (
              <div key={e.id} className={e.id === newId ? "row-new" : ""} style={{ padding: "0.8rem", background: "var(--surface-raised)", borderRadius: 14, textAlign: "center", animation: "popIn .45s both" }}>
                <div style={{ fontSize: "2rem" }}>{iconFor(e.category)}</div>
                <div style={{ fontWeight: 700, fontSize: "0.95rem", marginTop: "0.2rem" }}>{money(e.amount)}</div>
                <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{e.merchant || t(e.category)}</div>
                <button className="btn-danger" style={{ fontSize: "0.68rem", marginTop: "0.4rem" }} onClick={() => handleDelete(e.id)}>✕</button>
              </div>
            ))}
          </div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "0.6rem", fontSize: "0.85rem" }}>
            <thead>
              <tr style={{ textAlign: "left", color: "var(--text-faint)", fontSize: "0.72rem", textTransform: "uppercase" }}>
                <th style={th}>{t("Date")}</th>
                <th style={th}>{t("Merchant")}</th>
                <th style={th}>{t("Category")}</th>
                <th style={th}>{t("Payment")}</th>
                <th style={{ ...th, textAlign: "right" }}>{t("Amount")}</th>
                <th style={th}></th>
              </tr>
            </thead>
            <tbody>
              {expenses.map((e) => (
                <tr key={e.id} className={e.id === newId ? "row-new" : ""} style={{ borderTop: "1px solid var(--border-soft)" }}>
                  <td style={td}>{formatDateTime(e.timestamp)}</td>
                  <td style={td}>{e.merchant || "—"}{e.source === "scan" && <span className="source-badge" title={t("Created from a scanned bill")}><Icon name="camera" size={11} /> {plain(t("📷 scan"))}</span>}{e.source === "quick" && <span className="source-badge" title={t("Created with Magic add")}><Icon name="spark" size={11} /> {plain(t("✨ magic"))}</span>}</td>
                  <td style={td}><span className="pill pill-muted">{iconFor(e.category)} {t(e.category)}</span></td>
                  <td style={td}>{t(e.payment_method)}</td>
                  <td style={{ ...td, textAlign: "right", fontFamily: "var(--font-mono)" }}>{money(e.amount)}</td>
                  <td style={td}>
                    <button className="btn-ghost" style={{ marginRight: "0.4rem" }} onClick={() => startEdit(e)}>{t("Edit")}</button>
                    <button className="btn-danger" onClick={() => handleDelete(e.id)}>{t("Delete")}</button>
                  </td>
                </tr>
              ))}
              {expenses.length === 0 && (
                <tr><td colSpan={6} style={{ ...td, color: "var(--text-muted)" }}>{t("No expenses yet — add your first one above.")}</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {editing && (
        <div className="modal-backdrop" onClick={() => setEditing(null)} role="dialog" aria-modal="true">
          <div className="card goal-panel" style={{ width: "min(440px, 92vw)", gap: "0.5rem" }} onClick={(ev) => ev.stopPropagation()}>
            <h3 style={{ margin: 0 }}>{t("Edit expense")}</h3>
            <label>{t("Amount ({currency})", { currency })}</label>
            <input type="number" min="0.01" step="0.01" value={editing.amount} onChange={(e) => setEditing({ ...editing, amount: e.target.value })} />
            <label>{t("Merchant")}</label>
            <input value={editing.merchant} onChange={(e) => setEditing({ ...editing, merchant: e.target.value })} />
            <label>{t("Category")}</label>
            <select value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })}>
              {[...new Set([editing.category, ...CATEGORIES])].map((c) => <option key={c} value={c}>{t(c)}</option>)}
            </select>
            <label>{t("Payment")}</label>
            <select value={editing.payment_method} onChange={(e) => setEditing({ ...editing, payment_method: e.target.value })}>
              {[...new Set([editing.payment_method, ...PAYMENT_METHODS])].map((p) => <option key={p} value={p}>{t(p)}</option>)}
            </select>
            <label>{t("Date")}</label>
            <input type="date" max={todayStr()} value={editing.date} onChange={(e) => setEditing({ ...editing, date: e.target.value })} />
            <label>{t("Note (optional)")}</label>
            <input value={editing.note} onChange={(e) => setEditing({ ...editing, note: e.target.value })} />
            {editErr && <div className="goal-err">{editErr}</div>}
            <div className="goal-actions">
              <button className="btn-primary" onClick={saveEdit}>{t("Save")}</button>
              <button className="btn-ghost" onClick={() => setEditing(null)}>{t("Cancel")}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const th = { padding: "0.5rem 0.6rem" };
const td = { padding: "0.6rem" };
