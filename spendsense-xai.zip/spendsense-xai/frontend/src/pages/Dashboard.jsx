import { useEffect, useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";
import { useLanguage } from "../LanguageContext";
import BudgetsCard from "../components/BudgetsCard";
import GetStarted from "../components/GetStarted";
import KidDashboard from "../components/KidDashboard";
import TeenDashboard from "../components/TeenDashboard";
import AdultDashboard from "../components/AdultDashboard";
import SeniorDashboard from "../components/SeniorDashboard";

import { t } from "../i18n";

export { PageHeader, StatCard, tooltipStyle } from "../components/DashboardUI";

export default function Dashboard() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const currency = user?.currency || "INR";
  const mode = user?.platform_mode || "adult";

  const [report, setReport] = useState(null);
  const [triggers, setTriggers] = useState([]);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [r, tr, g] = await Promise.all([
          api.get("/reports/monthly"),
          api.get("/insights/triggers", { params: { active_only: true } }),
          api.get("/goals"),
        ]);
        setReport(r.data);
        setTriggers(tr.data);
        setGoals(g.data);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return (
    <div aria-busy="true" aria-label={t("Loading dashboard…")} style={{ display: "grid", gap: "1rem" }}>
      <div className="skeleton" style={{ height: 40, width: 260, borderRadius: 10 }} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1rem" }}>
        {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ height: 96, borderRadius: 16 }} />)}
      </div>
      <div className="skeleton" style={{ height: 320, borderRadius: 16 }} />
    </div>
  );
  if (!report) return null;

  const props = { report, triggers, goals, currency, userId: user?.id, title: t("dashboard.title") };

  return (
    <div>
      <GetStarted goals={goals} />
      {mode === "kid" && <KidDashboard {...props} />}
      {mode === "teen" && <TeenDashboard {...props} />}
      {mode === "senior" && <SeniorDashboard {...props} />}
      {mode === "adult" && <AdultDashboard {...props} />}
      <BudgetsCard />
    </div>
  );
}
