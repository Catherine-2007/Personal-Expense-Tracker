import { useEffect, useRef, useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";
import { useFeedback } from "../FeedbackContext";
import Icon from "../components/Icon";
import { useTheme, FONT_STYLES, FONT_SIZE_PRESETS } from "../ThemeContext";
import { useLanguage } from "../LanguageContext";
import { useCurrencyRates } from "../CurrencyRatesContext";
import { CURRENCIES } from "../currency";
import ParticleHeader from "../components/ParticleHeader";

import { t, N_, tx, formatDateTime, formatNumber } from "../i18n";

const PLATFORM_MODES = [
  { id: "kid", label: N_("Playground"), blurb: N_("Simple words, big buttons, extra encouragement."), icon: "🧒" },
  { id: "teen", label: N_("Guided"), blurb: N_("Full features with more explanation."), icon: "🧑" },
  { id: "adult", label: N_("Full experience"), blurb: N_("Everything unlocked, no simplification."), icon: "✓" },
  { id: "senior", label: N_("Comfort"), blurb: N_("Larger text, higher contrast, simplified layout."), icon: "🧓" },
];

export default function Settings() {
  const { user, updateProfile, logout } = useAuth();
  const { confirm } = useFeedback();
  const { theme, setTheme, themes, fx, setFx, fontScale, setFontScale, fontStyle, setFontStyle, lineSpacing, setLineSpacing } = useTheme();
  const { lang, setLang, languages, t } = useLanguage();
  const { rates, meta, loading: ratesLoading, refresh: refreshRates } = useCurrencyRates();

  const [income, setIncome] = useState(user?.monthly_income ?? 0);
  const [savings, setSavings] = useState(user?.current_savings ?? 0);
  const [currency, setCurrency] = useState(user?.currency ?? "INR");
  const [platformMode, setPlatformMode] = useState(user?.platform_mode ?? "adult");
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [health, setHealth] = useState(null);
  const [textSaved, setTextSaved] = useState(false);
  const touched = useRef(false);

  // Text & reading preferences save themselves (debounced) once the user changes them.
  useEffect(() => {
    if (!touched.current) return;
    const id = setTimeout(async () => {
      try {
        await updateProfile({ font_scale: fontScale, font_style: fontStyle, line_spacing: lineSpacing });
        setTextSaved(true);
        setTimeout(() => setTextSaved(false), 1800);
      } catch { /* kept locally either way */ }
    }, 600);
    return () => clearTimeout(id);
  }, [fontScale, fontStyle, lineSpacing]); // eslint-disable-line

  // If the user leaves the page before the debounce fires, save right away.
  const latest = useRef({});
  latest.current = { fontScale, fontStyle, lineSpacing };
  useEffect(() => {
    const body = () => JSON.stringify({
      font_scale: latest.current.fontScale, font_style: latest.current.fontStyle, line_spacing: latest.current.lineSpacing,
    });
    // Hard refresh / tab close: keepalive lets the request finish after the page is gone.
    const onHide = () => {
      if (!touched.current) return;
      const base = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8000";
      try {
        fetch(`${base}/auth/me`, {
          method: "PATCH", keepalive: true, body: body(),
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${localStorage.getItem("ss_token")}` },
        });
        // keep the cached profile in step so the next load doesn't re-apply stale values
        const u = JSON.parse(localStorage.getItem("ss_user") || "null");
        if (u) localStorage.setItem("ss_user", JSON.stringify({ ...u, ...JSON.parse(body()) }));
      } catch { /* best effort */ }
    };
    window.addEventListener("pagehide", onHide);
    return () => {
      window.removeEventListener("pagehide", onHide);
      // in-app navigation: save immediately
      if (touched.current) api.patch("/auth/me", JSON.parse(body()))
        .then((r) => localStorage.setItem("ss_user", JSON.stringify(r.data))).catch(() => {});
    };
  }, []);

  useEffect(() => { api.get("/health").then((r) => setHealth(r.data)).catch(() => setHealth({ status: "offline" })); }, []);

  const change = (fn) => (v) => { touched.current = true; fn(v); };
  const defaultStack = theme === "kid" ? '"Baloo 2", sans-serif' : '"Inter", sans-serif';

  async function downloadCsv() {
    const { data } = await api.get("/expenses/export.csv", { responseType: "blob" });
    const url = URL.createObjectURL(data);
    const a = document.createElement("a");
    a.href = url; a.download = "spendsense-expenses.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      await updateProfile({
        monthly_income: Number(income) || 0,
        current_savings: Number(savings) || 0,
        currency,
        language: lang,
        theme,
        platform_mode: platformMode,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  }

  const [importMsg, setImportMsg] = useState(null);
  const [pw, setPw] = useState({ current: "", next: "" });
  const [pwMsg, setPwMsg] = useState(null);
  const [delPw, setDelPw] = useState("");
  const [delMsg, setDelMsg] = useState("");
  async function importCsv(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const { data } = await api.post("/expenses/import-csv", { csv_text: await file.text() });
      setImportMsg({ ok: true, text: t("Imported {added} expenses ({dupes} duplicates and {skipped} unreadable rows skipped).", { added: data.added, dupes: data.duplicates, skipped: data.skipped }) });
      window.dispatchEvent(new Event("ss:expense-added"));
    } catch (err) {
      setImportMsg({ ok: false, text: err?.response?.data?.detail || t("Something went wrong — try again.") });
    }
  }

  async function changePassword(e) {
    e.preventDefault();
    try {
      await api.post("/auth/change-password", { current_password: pw.current, new_password: pw.next });
      setPw({ current: "", next: "" });
      setPwMsg({ ok: true, text: t("Password changed.") });
    } catch (err) {
      const d = err?.response?.data?.detail;
      setPwMsg({ ok: false, text: typeof d === "string" ? d : t("Something went wrong — try again.") });
    }
  }

  async function deleteAccount(e) {
    e.preventDefault();
    if (!(await confirm({ message: t("Delete your account and all your data forever?"), danger: true }))) return;
    try {
      await api.post("/auth/delete-account", { password: delPw });
      logout();
      window.location.href = "/login";
    } catch (err) {
      const d = err?.response?.data?.detail;
      setDelMsg(typeof d === "string" ? d : t("Something went wrong — try again."));
    }
  }

  return (
    <div>
      <ParticleHeader
        mode={user?.platform_mode}
        title={t("settings.title")}
        subtitle={t(
          "Your preferences are saved to your account, so they follow you across devices."
        )}
      />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.2rem" }}>
        <div className="card">
          <span className="eyebrow">{t("Appearance")}</span>
          <h3>{t("Theme")}</h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.6rem" }}>
            {themes.map((th) => (
              <button
                key={th.id}
                onClick={() => setTheme(th.id)}
                className="card"
                style={{
                  textAlign: "left", padding: "0.8rem",
                  borderColor: theme === th.id ? "var(--teal)" : "var(--border-soft)",
                }}
              >
                <span style={{ width: 14, height: 14, borderRadius: "50%", background: th.swatch, display: "inline-block", marginBottom: "0.4rem" }} />
                <div style={{ fontWeight: 600, fontSize: "0.86rem" }}>{t(th.label)}</div>
                <div style={{ fontSize: "0.74rem", color: "var(--text-muted)" }}>{t(th.blurb)}</div>
              </button>
            ))}
          </div>

          <h3 style={{ marginTop: "1.4rem" }}>{t("Visual effects")}</h3>
          <div className="seg" role="group" aria-label={t("Visual effects")}>
            {[["full", t("✨ Full")], ["subtle", t("Subtle")], ["off", t("Off")]].map(([id, label]) => (
              <button key={id} type="button" className={fx === id ? "on" : ""} onClick={() => setFx(id)}>{label}</button>
            ))}
          </div>
          <p style={{ fontSize: "0.72rem", marginTop: "0.4rem" }}>{t(
            "Aurora glow, cursor spotlight and ripples. Pick Off for the calmest, fastest experience."
          )}</p>

          <h3 style={{ marginTop: "1.4rem" }}>{t("Language")}</h3>
          <select value={lang} onChange={(e) => { setLang(e.target.value); updateProfile({ language: e.target.value }).catch(() => {}); }}>
            {languages.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
          </select>
        </div>

        <div className="card">
          <span className="eyebrow">{t("Experience")}</span>
          <h3>{t("Platform mode")}</h3>
          <p style={{ fontSize: "0.78rem" }}>
            {user?.age != null
              ? t("Based on your age ({age}), we suggest a {mode} experience — but you can pick any mode below.", { age: user.age, mode: user.age < 13 ? t("Playground") : user.age < 18 ? t("Guided") : t("Full") })
              : t("Choose how much guidance and simplification you'd like.")}
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            {PLATFORM_MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setPlatformMode(m.id)}
                className="card"
                style={{
                  textAlign: "left", padding: "0.7rem 0.9rem",
                  display: "flex", alignItems: "center", gap: "0.7rem",
                  borderColor: platformMode === m.id ? "var(--teal)" : "var(--border-soft)",
                }}
              >
                <span style={{ fontSize: "1.2rem" }}>{m.icon}</span>
                <span>
                  <div style={{ fontWeight: 600, fontSize: "0.86rem" }}>{t(m.label)}</div>
                  <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{t(m.blurb)}</div>
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: "1.2rem" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span className="eyebrow">{t("Text & reading")}</span>
          {textSaved && <span style={{ color: "var(--teal)", fontSize: "0.78rem", animation: "fadeIn .3s both" }}>{t("✓ Saved to your account")}</span>}
        </div>

        <div className="font-top">
          <div>
            <h3>{t("Font size")} <span className="mono" style={{ color: "var(--teal)", fontSize: "0.85rem" }}>{Math.round(fontScale * 100)}%</span></h3>
            <input
              type="range" min="0.75" max="1.75" step="0.05" value={fontScale}
              onChange={(e) => change(setFontScale)(Number(e.target.value))}
              aria-label={t("Font size")} className="range"
              style={{ padding: 0, border: "none" }}
            />
            <div style={{ display: "flex", gap: "0.4rem", marginTop: "0.6rem", flexWrap: "wrap" }}>
              {FONT_SIZE_PRESETS.map((p) => {
                const on = Math.abs(fontScale - p.value) < 0.02;
                return (
                  <button key={p.label} type="button" onClick={() => change(setFontScale)(p.value)} className="btn-ghost"
                    style={{ padding: "0.35rem 0.8rem", fontWeight: 700, borderColor: on ? "var(--teal)" : undefined, color: on ? "var(--teal)" : undefined }}>
                    {p.label}
                  </button>
                );
              })}
              <button type="button" className="btn-ghost" style={{ padding: "0.35rem 0.8rem" }}
                onClick={() => { touched.current = true; setFontScale(1); setFontStyle("default"); setLineSpacing("normal"); }}>{t("↺ Reset")}</button>
            </div>

            <h3 style={{ marginTop: "1.2rem" }}>{t("Line spacing")}</h3>
            <div style={{ display: "flex", gap: "0.5rem" }}>
              {[["normal", t("Normal")], ["relaxed", t("Relaxed")]].map(([id, label]) => (
                <button key={id} type="button" className="btn-ghost" onClick={() => change(setLineSpacing)(id)}
                  style={{ borderColor: lineSpacing === id ? "var(--teal)" : undefined, color: lineSpacing === id ? "var(--teal)" : undefined }}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="font-preview">
            <span className="eyebrow">{t("Live preview")}</span>
            <div className="font-preview-amount">{formatNumber(12480.5, { style: "currency", currency: "INR" })}</div>
            <div style={{ fontFamily: "var(--font-display)", fontWeight: 600, marginBottom: "0.3rem" }}>{t("Spent less on food this week")}</div>
            <p style={{ margin: 0, fontSize: "0.88rem" }}>{t(
              "Your late-night orders dropped by 18% — keep it up and you'll reach your laptop goal two weeks sooner."
            )}</p>
          </div>
        </div>

        <h3 style={{ marginTop: "1.3rem" }}>{t("Font style")}</h3>
        <div className="font-grid">
          {FONT_STYLES.map((f, i) => (
            <button key={f.id} type="button" onClick={() => change(setFontStyle)(f.id)}
              className={`font-option ${fontStyle === f.id ? "active" : ""}`} aria-pressed={fontStyle === f.id}
              style={{ animationDelay: `${i * 40}ms` }}>
              <span className="font-sample" style={{ fontFamily: f.stack || defaultStack }}>{t("Aa 123")}</span>
              <span className="font-name">{t(f.label)}</span>
              <span className="font-blurb">{t(f.blurb)}</span>
              {fontStyle === f.id && <span className="font-tick">✓</span>}
            </button>
          ))}
        </div>
      </div>

      <div style={{ marginTop: "1.2rem" }}>
        <form onSubmit={handleSave} className="card">
          <span className="eyebrow">{t("Money")}</span>
          <h3>{t("Currency & finances")}</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "0.9rem" }}>
            <div>
              <label>{t("Currency")}</label>
              <select value={currency} onChange={(e) => setCurrency(e.target.value)}>
                {CURRENCIES.map((c) => <option key={c.code} value={c.code}>{t(c.label)}</option>)}
              </select>
              <p style={{ fontSize: "0.74rem", marginTop: "0.3rem" }}>
                {tx("Your entries are recorded in **{currency}** — switching currency here converts every amount you see using a real exchange rate, not just the symbol.", { currency: user?.base_currency || "INR" })}
              </p>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                marginTop: "0.5rem", padding: "0.5rem 0.7rem", background: "var(--surface-raised)", borderRadius: 8,
              }}>
                <span style={{ fontSize: "0.72rem", color: meta?.source === "live" ? "var(--teal)" : "var(--amber)" }}>
                  {ratesLoading ? t("Updating rates…") : meta?.source === "live"
                    ? t("Live rates as of {when}", { when: meta?.fetched_at ? formatDateTime(meta.fetched_at) : t("just now") })
                    : meta?.source === "fallback"
                    ? t("Offline — using rates from {when}", { when: meta?.fallback_dated || t("a recent snapshot") })
                    : t("Rates not loaded yet")}
                </span>
                <button type="button" className="btn-ghost" style={{ fontSize: "0.7rem", padding: "0.3rem 0.6rem" }} onClick={refreshRates} disabled={ratesLoading}>{t("↻ Refresh")}</button>
              </div>
            </div>
            <div>
              <label>{t("register.income")}</label>
              <input type="number" min="0" value={income} onChange={(e) => setIncome(e.target.value)} />
            </div>
            <div>
              <label>{t("register.savings")}</label>
              <input type="number" min="0" value={savings} onChange={(e) => setSavings(e.target.value)} />
            </div>
            <button className="btn-primary" type="submit" disabled={saving}>
              {saving ? t("Saving…") : t("common.save")}
            </button>
            {saved && <div style={{ color: "var(--teal)", fontSize: "0.82rem" }}>{t("✓ Saved")}</div>}
          </div>
        </form>
      </div>

      <div className="card" style={{ marginTop: "1.2rem" }}>
        <span className="eyebrow">{t("Your data")}</span>
        <h3>{t("Export & import")}</h3>
        <div style={{ display: "flex", gap: "0.6rem", flexWrap: "wrap", alignItems: "center" }}>
          <button type="button" className="btn-ghost" onClick={downloadCsv}>{t("⬇ Download all expenses (CSV)")}</button>
          <label className="btn-ghost" style={{ cursor: "pointer", margin: 0 }}>
            {t("⬆ Import expenses from CSV")}
            <input type="file" accept=".csv,text/csv" onChange={importCsv} style={{ display: "none" }} />
          </label>
        </div>
        <p style={{ fontSize: "0.74rem", marginTop: "0.5rem" }}>{t("The first row must name the columns, e.g. Date, Description, Amount. Duplicates are skipped.")}</p>
        {importMsg && <p style={{ fontSize: "0.82rem", color: importMsg.ok ? "var(--teal)" : "var(--coral)" }}>{importMsg.text}</p>}
        {(() => {
          const engine = { sqlite: "SQLite", mysql: "MySQL / MariaDB", postgresql: "PostgreSQL" }[health?.database?.dialect] || health?.database?.dialect;
          const state = !health ? "wait" : health.status === "offline" ? "off" : health.status === "healthy" ? "ok" : "warn";
          return (
            <div className={`db-status ${state}`}>
              <span className="db-ico"><Icon name="database" size={22} /></span>
              <div>
                <b>{!health ? t("Checking database…") : state === "off" ? t("Can't reach the backend. Make sure it is running (uvicorn app.main:app --reload).")
                  : state === "ok" ? t("● Database healthy") : t("● Database needs attention — run: python check_db.py --repair")}</b>
                {engine && <small>{t("Stored in {engine} — every expense, goal, budget and family record lives here.", { engine })}
                  {health.database.dialect === "mysql" ? " " + t("Open phpMyAdmin to browse the tables.") : ""}</small>}
              </div>
            </div>
          );
        })()}
      </div>

      <div className="card" style={{ marginTop: "1.2rem" }}>
        <span className="eyebrow">{t("Account")}</span>
        <h3>{t("Change password")}</h3>
        <form onSubmit={changePassword} style={{ display: "grid", gap: "0.6rem", maxWidth: 360 }}>
          <input type="password" autoComplete="current-password" placeholder={t("Current password")} value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} required />
          <input type="password" autoComplete="new-password" minLength={8} placeholder={t("New password (min 8 characters)")} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} required />
          <button className="btn-primary" type="submit">{t("Change password")}</button>
          {pwMsg && <span style={{ fontSize: "0.82rem", color: pwMsg.ok ? "var(--teal)" : "var(--coral)" }}>{pwMsg.text}</span>}
        </form>
        <h3 style={{ marginTop: "1.4rem", color: "var(--coral)" }}>{t("Delete my account")}</h3>
        <p style={{ fontSize: "0.78rem" }}>{t("This permanently deletes your expenses, goals, budgets and family membership. It can't be undone.")}</p>
        <form onSubmit={deleteAccount} style={{ display: "flex", gap: "0.6rem", flexWrap: "wrap", maxWidth: 480 }}>
          <input type="password" autoComplete="current-password" placeholder={t("Type your password to confirm")} value={delPw} onChange={(e) => setDelPw(e.target.value)} required style={{ flex: "1 1 200px" }} />
          <button className="btn-danger" type="submit">{t("Delete my account")}</button>
        </form>
        {delMsg && <p style={{ fontSize: "0.82rem", color: "var(--coral)" }}>{delMsg}</p>}
      </div>
    </div>
  );
}
