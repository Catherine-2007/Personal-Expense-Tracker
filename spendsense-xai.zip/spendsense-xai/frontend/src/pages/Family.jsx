import { useCallback, useEffect, useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";
import { useFeedback } from "../FeedbackContext";
import { useMoney } from "../useMoney";
import ParticleHeader from "../components/ParticleHeader";
import ConfettiBurst from "../components/ConfettiBurst";
import CountUp from "../components/CountUp";
import Reveal from "../components/Reveal";
import { CATEGORY_COLORS } from "../components/DashboardUI";
import { N_, t, tp, formatDate, formatDateTime } from "../i18n";
import "./family.css";

const ROLE_LABEL = { owner: N_("Owner"), parent: N_("Parent"), member: N_("Member"), child: N_("Child") };
const SHARE_OPTIONS = [
  { id: "full", label: N_("Everything"), hint: N_("Family sees my amounts and categories") },
  { id: "totals", label: N_("Totals only"), hint: N_("Family sees only my total") },
  { id: "rank", label: N_("Rank only"), hint: N_("Family sees only my points and rank") },
];
const AWARD_META = {
  streak: { icon: "🔥", title: N_("Streak Master"), desc: N_("Longest daily logging streak") },
  no_spend: { icon: "🧘", title: N_("Zen Saver"), desc: N_("Most no-spend days") },
  improver: { icon: "📉", title: N_("Most Improved"), desc: N_("Biggest drop against their own usual pace") },
  goals: { icon: "🎯", title: N_("Goal Getter"), desc: N_("Made the most goal progress") },
  scanner: { icon: "🧾", title: N_("Receipt Ranger"), desc: N_("Scanned the most bills") },
  cheer: { icon: "📣", title: N_("Chief Cheerleader"), desc: N_("Sent the most cheers") },
};
const POINT_LABEL = {
  logging: N_("Logging days"), streak: N_("Streak"), no_spend: N_("No-spend days"), pace: N_("Beating own pace"),
  goals: N_("Goals"), kudos: N_("Cheers received"), scans: N_("Bill scans"), challenges: N_("Challenges won"),
};
const CHALLENGE_KINDS = [
  { id: "no_spend_days", icon: "🧘", label: N_("No-spend days"), unit: N_("days") },
  { id: "spend_cap", icon: "🧢", label: N_("Spending cap"), unit: N_("amount") },
  { id: "log_days", icon: "📝", label: N_("Everyone logs"), unit: N_("days") },
];
const PODIUM_ORDER = [1, 0, 2]; // second, first, third (visual order)
const MEDALS = ["🥇", "🥈", "🥉"];

const challengeTitle = (c) =>
  c.title ||
  (c.kind === "no_spend_days"
    ? t("Family no-spend challenge")
    : c.kind === "spend_cap"
    ? c.category ? t("Keep {category} under the cap", { category: t(c.category) }) : t("Family spending cap")
    : t("Everyone logs their spending"));

export default function Family() {
  const { user } = useAuth();
  const { money } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isSenior = mode === "senior";

  const [data, setData] = useState(null);
  const [period, setPeriod] = useState("month");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const [open, setOpen] = useState(null);
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState("board");

  const load = useCallback(async (p = period) => {
    try {
      const r = await api.get("/family", { params: { period: p } });
      setData(r.data);
      setError("");
    } catch (e) {
      setError(e?.response?.data?.detail || t("Couldn't load your family."));
      setData((d) => d || { family: null });
    }
  }, [period]);

  useEffect(() => { load(period); }, [period]); // eslint-disable-line

  const act = async (fn, { celebrate } = {}) => {
    setBusy(true);
    setError("");
    try {
      const r = await fn();
      if (r?.data?.members !== undefined || r?.data?.family !== undefined) setData(r.data);
      else if (r?.data?.access_token === undefined) await load(period);
      if (celebrate) setConfetti(true);
      return r;
    } catch (e) {
      const d = e?.response?.data?.detail;
      setError(typeof d === "string" ? d : t("Something went wrong. Please try again."));
    } finally {
      setBusy(false);
    }
  };

  if (!data) return <div className="card skeleton" style={{ height: 240 }} />;

  if (!data.family) {
    return <NoFamily act={act} busy={busy} error={error} isKid={isKid} />;
  }

  const { family, me, members, totals, awards, challenges, feed } = data;
  const byId = Object.fromEntries(members.map((m) => [m.user_id, m]));
  const top3 = members.slice(0, 3);
  const maxPts = Math.max(...members.map((m) => m.points), 1);
  const maxSpend = Math.max(...members.map((m) => m.total || 0), 1);

  const copyCode = async () => {
    try { await navigator.clipboard.writeText(family.invite_code); } catch { /* ignore */ }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const sendKudos = (uid, emoji) =>
    act(() => api.post("/family/kudos", { to_user_id: uid, emoji }), { celebrate: true });

  return (
    <div className={`fam ${isKid ? "fam-kid" : ""} ${isSenior ? "fam-senior" : ""}`}>
      {confetti && <ConfettiBurst onDone={() => setConfetti(false)} />}
      <ParticleHeader
        title={`${family.emoji} ${family.name}`}
        subtitle={tp(members.length, "{n} member · one app, everyone's money", "{n} members · one app, everyone's money")}
        mode={mode}
        action={
          family.invite_code && (
            <button className="fam-code" onClick={copyCode} title={t("Copy invite code")}>
              <span className="eyebrow" style={{ margin: 0 }}>{t("Invite code")}</span>
              <b className="mono">{family.invite_code}</b>
              <span>{copied ? t("✓ Copied") : "⧉"}</span>
            </button>
          )
        }
      />

      {error && <div className="fam-error" role="alert">{error}</div>}

      <div className="fam-bar">
        <div className="seg" role="group" aria-label={t("Period")}>
          <button className={period === "week" ? "on" : ""} onClick={() => setPeriod("week")}>{t("Last 7 days")}</button>
          <button className={period === "month" ? "on" : ""} onClick={() => setPeriod("month")}>{t("This month")}</button>
        </div>
        <div className="seg" role="group" aria-label={t("Section")}>
          {[["board", t("🏆 Ranking")], ["spend", t("💸 Who spends what")], ["challenges", t("🎯 Challenges")], ["manage", t("⚙ Family")]].map(([id, label]) => (
            <button key={id} className={tab === id ? "on" : ""} onClick={() => setTab(id)}>{label}</button>
          ))}
        </div>
      </div>

      {tab === "board" && (
        <>
          <Reveal>
            <div className="card fam-podium-card">
              <span className="eyebrow">{t("Healthy-habit leaderboard")}</span>
              <p className="fam-note">{t("Points reward good habits — logging, streaks, no-spend days and beating your own usual pace. Nobody wins by spending more or less than anyone else.")}</p>
              <div className="fam-podium">
                {PODIUM_ORDER.map((idx) => {
                  const m = top3[idx];
                  if (!m) return <div key={idx} className="fam-pod empty" />;
                  const h = 38 + (m.points / maxPts) * 62;
                  return (
                    <div key={m.user_id} className={`fam-pod pod-${idx + 1}`}>
                      <div className="fam-pod-avatar" aria-hidden>{m.avatar}</div>
                      <div className="fam-pod-name">{m.name}{m.is_me ? ` ${t("(you)")}` : ""}</div>
                      <div className="fam-pod-title">{m.emoji} {t(m.title)}</div>
                      <div className="fam-pod-block" style={{ "--h": `${h}%`, animationDelay: `${idx * 120}ms` }}>
                        <span className="fam-medal">{MEDALS[idx]}</span>
                        <b className="mono"><CountUp value={m.points} format={(n) => Math.round(n)} /></b>
                        <small>{t("pts")}</small>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Reveal>

          {awards.length > 0 && (
            <div className="fam-awards">
              {awards.map((a, i) => {
                const meta = AWARD_META[a.id];
                const who = byId[a.user_id];
                if (!meta || !who) return null;
                return (
                  <Reveal key={a.id} delay={i * 60}>
                    <div className="card fam-award" title={t(meta.desc)}>
                      <span className="fam-award-icon">{meta.icon}</span>
                      <div>
                        <div className="fam-award-title">{t(meta.title)}</div>
                        <div className="fam-award-who">{who.avatar} {who.name}</div>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          )}

          <div className="card" style={{ marginTop: "1rem" }}>
            <span className="eyebrow">{t("Full ranking")}</span>
            <div className="fam-list">
              {members.map((m, i) => {
                const isOpen = open === m.user_id;
                return (
                  <div key={m.user_id} className={`fam-row ${m.is_me ? "me" : ""}`} style={{ animationDelay: `${i * 60}ms` }}>
                    <button className="fam-row-main" onClick={() => setOpen(isOpen ? null : m.user_id)} aria-expanded={isOpen}>
                      <span className="fam-rank">{m.rank <= 3 ? MEDALS[m.rank - 1] : `#${m.rank}`}</span>
                      <span className="fam-avatar" aria-hidden>{m.avatar}</span>
                      <span className="fam-who">
                        <b>{m.name}{m.is_me ? ` ${t("(you)")}` : ""}</b>
                        <small>
                          {m.emoji} {t(m.title)} · {t(ROLE_LABEL[m.role] || m.role)}
                          {m.age != null ? ` · ${tp(m.age, "{n} yr", "{n} yrs")}` : ""}
                        </small>
                      </span>
                      <span className="fam-streak" title={t("Logging streak")}>🔥 {m.streak}</span>
                      <span className="fam-pts">
                        <span className="fam-pts-bar"><i style={{ width: `${(m.points / maxPts) * 100}%` }} /></span>
                        <b className="mono">{m.points}</b>
                      </span>
                    </button>
                    {isOpen && (
                      <div className="fam-detail">
                        <div className="fam-parts">
                          {Object.entries(m.points_parts).map(([k, v]) => (
                            <div key={k} className="fam-part"><span>{t(POINT_LABEL[k] || k)}</span><b className="mono">+{v}</b></div>
                          ))}
                        </div>
                        <div className="fam-facts">
                          {m.visible === "rank" ? (
                            <span className="chip chip-muted">🔒 {t("Spending is private — only points are shared")}</span>
                          ) : (
                            <>
                              <span className="chip">💸 {money(m.total)}</span>
                              {m.count != null && <span className="chip">{tp(m.count, "{n} purchase", "{n} purchases")}</span>}
                              {m.top_category && <span className="chip">{t(m.top_category)}</span>}
                            </>
                          )}
                          <span className="chip">{tp(m.no_spend_days, "{n} no-spend day", "{n} no-spend days")}</span>
                          {m.pace_change != null && m.pace_change > 0.02 && (
                            <span className="chip chip-good">📉 {t("{n}% under own pace", { n: Math.round(m.pace_change * 100) })}</span>
                          )}
                        </div>
                        {!m.is_me && (
                          <div className="fam-kudos">
                            <small>{t("Send a cheer")} ({t("{n} left today", { n: me.kudos_left_today })})</small>
                            <div>
                              {data.kudos_emojis.map((e) => (
                                <button key={e} className="fam-kudo" disabled={busy || me.kudos_left_today <= 0}
                                  onClick={() => sendKudos(m.user_id, e)} aria-label={t("Cheer {name} with {emoji}", { name: m.name, emoji: e })}>{e}</button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {feed.length > 0 && (
            <div className="card" style={{ marginTop: "1rem" }}>
              <span className="eyebrow">{t("Family activity")}</span>
              <ul className="fam-feed">
                {feed.map((f, i) => (
                  <li key={i}>
                    <span className="fam-feed-ico">{f.type === "kudos" ? f.emoji : f.avatar}</span>
                    <span>
                      {f.type === "kudos"
                        ? t("{from} cheered {to}", { from: f.from, to: f.to })
                        : t("{name} joined the family", { name: f.name })}
                    </span>
                    <small>{formatDateTime(f.at)}</small>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}

      {tab === "spend" && (
        <Reveal>
          <div className="card">
            <span className="eyebrow">{period === "week" ? t("Last 7 days") : t("This month")}</span>
            <div className="fam-total">
              <CountUp value={totals.spent} format={(n) => money(n)} />
              <small>{t("family total")}</small>
            </div>
            {totals.hidden_members > 0 && (
              <p className="fam-note">🔒 {tp(totals.hidden_members, "{n} member keeps their spending private and isn't counted here.", "{n} members keep their spending private and aren't counted here.")}</p>
            )}
            {family.monthly_budget > 0 && period === "month" && totals.budget_used_pct != null && (
              <div style={{ margin: "0.8rem 0" }}>
                <div className="fam-meter"><i style={{
                  width: `${Math.min(totals.budget_used_pct * 100, 100)}%`,
                  background: totals.budget_used_pct > 1 ? "var(--coral)" : totals.budget_used_pct > 0.8 ? "var(--amber)" : "var(--teal)",
                }} /></div>
                <small className="fam-note">{t("{used}% of the family budget ({budget}) used", { used: Math.round(totals.budget_used_pct * 100), budget: money(family.monthly_budget) })}</small>
              </div>
            )}
            <div className="fam-split">
              {members.filter((m) => m.total != null && m.total > 0).map((m, i) => (
                <span key={m.user_id} title={`${m.name}: ${money(m.total)}`}
                  style={{ flex: m.total, background: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} />
              ))}
            </div>
            <div className="fam-bars">
              {members.map((m, i) => (
                <div key={m.user_id} className="fam-bar-row" style={{ animationDelay: `${i * 70}ms` }}>
                  <span className="fam-avatar" aria-hidden>{m.avatar}</span>
                  <span className="fam-bar-name">{m.name}</span>
                  <span className="fam-bar-track">
                    {m.total != null ? <i style={{ width: `${(m.total / maxSpend) * 100}%`, background: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} /> : null}
                  </span>
                  <b className="mono">{m.total != null ? money(m.total) : "🔒"}</b>
                </div>
              ))}
            </div>
            <p className="fam-note">{t("Amounts are shown in your currency. Each person keeps their own account and decides how much the family can see.")}</p>
          </div>

          {data.top_categories.length > 0 && (
            <div className="card" style={{ marginTop: "1rem" }}>
              <span className="eyebrow">{t("Where the family's money goes")}</span>
              <div className="fam-bars">
                {data.top_categories.map((c, i) => (
                  <div key={c.category} className="fam-bar-row">
                    <span className="fam-bar-name" style={{ width: 110 }}>{t(c.category)}</span>
                    <span className="fam-bar-track"><i style={{ width: `${(c.amount / data.top_categories[0].amount) * 100}%`, background: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} /></span>
                    <b className="mono">{money(c.amount)}</b>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Reveal>
      )}

      {tab === "challenges" && (
        <ChallengesTab data={data} byId={byId} act={act} busy={busy} money={money} />
      )}

      {tab === "manage" && (
        <ManageTab data={data} act={act} busy={busy} reload={() => load(period)} />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function NoFamily({ act, busy, error, isKid }) {
  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState("🏡");
  const [budget, setBudget] = useState("");
  const [code, setCode] = useState("");
  const EMOJIS = ["🏡", "👨‍👩‍👧‍👦", "🌈", "🦁", "🚀", "🌻"];
  return (
    <div className="fam">
      <ParticleHeader title={t("Family")} subtitle={t("One app for everyone — see who spends what, climb the ranking and cheer each other on.")} height={92} />
      {error && <div className="fam-error" role="alert">{error}</div>}
      <div className="fam-start">
        <form className="card" onSubmit={(e) => { e.preventDefault(); act(() => api.post("/family", { name, emoji, monthly_budget: Number(budget) || 0 }), { celebrate: true }); }}>
          <span className="eyebrow">{t("Start a family")}</span>
          <h3>{t("Create your family")}</h3>
          <label>{t("Family name")}</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required maxLength={120} placeholder={t("e.g. The Sharmas")} />
          <label>{t("Pick an emblem")}</label>
          <div className="fam-emoji-row">
            {EMOJIS.map((x) => (
              <button type="button" key={x} className={`fam-emoji ${emoji === x ? "on" : ""}`} onClick={() => setEmoji(x)} aria-pressed={emoji === x}>{x}</button>
            ))}
          </div>
          <label>{t("Monthly family budget (optional)")}</label>
          <input type="number" min="0" value={budget} onChange={(e) => setBudget(e.target.value)} />
          <button className="btn-primary" disabled={busy || !name.trim()} style={{ marginTop: "0.8rem", width: "100%" }}>{t("Create family")}</button>
        </form>
        <form className="card" onSubmit={(e) => { e.preventDefault(); act(() => api.post("/family/join", { code }), { celebrate: true }); }}>
          <span className="eyebrow">{t("Already invited?")}</span>
          <h3>{t("Join with a code")}</h3>
          <label>{t("Invite code")}</label>
          <input className="mono" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} maxLength={9} placeholder="ABC123" required />
          <button className="btn-primary" disabled={busy || code.trim().length < 4} style={{ marginTop: "0.8rem", width: "100%" }}>{t("Join family")}</button>
          <p className="fam-note">{isKid ? t("Ask a grown-up for the family code!") : t("Ask the family owner for the 6-character code shown on their Family page.")}</p>
        </form>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
function ChallengesTab({ data, byId, act, busy, money }) {
  const { me, challenges } = data;
  const [kind, setKind] = useState("no_spend_days");
  const [target, setTarget] = useState("5");
  const [days, setDays] = useState("7");
  const [category, setCategory] = useState("");
  const [title, setTitle] = useState("");
  const canCreate = me.role !== "child";

  const create = (e) => {
    e.preventDefault();
    act(() => api.post("/family/challenges", { kind, target: Number(target), days: Number(days), category: kind === "spend_cap" ? category : "", title }));
  };

  return (
    <div>
      {challenges.length === 0 && (
        <div className="card fam-empty">🎯 {t("No challenges yet — start one and race the clock together!")}</div>
      )}
      <div className="fam-chals">
        {challenges.map((c, i) => (
          <Reveal key={c.id} delay={i * 60}>
            <div className={`card fam-chal state-${c.state}`}>
              <div className="fam-chal-head">
                <b>{CHALLENGE_KINDS.find((k) => k.id === c.kind)?.icon} {challengeTitle(c)}</b>
                <span className={`pill ${c.state === "won" ? "pill-teal" : c.state === "lost" ? "pill-coral" : ""}`}>
                  {c.state === "won" ? t("🏆 Won!") : c.state === "lost" ? t("Missed") : tp(c.days_left, "{n} day left", "{n} days left")}
                </span>
              </div>
              <div className="fam-meter"><i style={{
                width: `${Math.round(c.pct * 100)}%`,
                background: c.state === "lost" ? "var(--coral)" : c.state === "won" ? "var(--teal)" : "var(--violet)",
              }} /></div>
              <small className="fam-note">
                {c.kind === "no_spend_days" && t("{value} of {target} no-spend days together", { value: Math.round(c.value), target: c.target })}
                {c.kind === "spend_cap" && t("{value} spent of the {target} cap", { value: money(c.value), target: money(c.target) })}
                {c.kind === "log_days" && t("{value} of {total} members logged on {target} different days", { value: c.value, total: c.contributions.length, target: c.target })}
              </small>
              <div className="fam-chal-people">
                {c.contributions.map((x) => {
                  const m = byId[x.user_id];
                  return m ? <span key={x.user_id} className="chip" title={m.name}>{m.avatar} {c.kind === "spend_cap" ? money(x.value) : x.value}</span> : null;
                })}
              </div>
              <small className="fam-note">{formatDate(c.start_date)} → {formatDate(c.end_date)}</small>
              {me.is_parent && (
                <button className="btn-ghost fam-small" disabled={busy} onClick={() => act(() => api.delete(`/family/challenges/${c.id}`))}>{t("Remove")}</button>
              )}
            </div>
          </Reveal>
        ))}
      </div>

      {canCreate ? (
        <form className="card" style={{ marginTop: "1rem" }} onSubmit={create}>
          <span className="eyebrow">{t("New challenge")}</span>
          <div className="fam-kinds">
            {CHALLENGE_KINDS.map((k) => (
              <button type="button" key={k.id} className={`fam-kind ${kind === k.id ? "on" : ""}`} onClick={() => { setKind(k.id); setTarget(k.id === "spend_cap" ? "2000" : "5"); }}>
                <span>{k.icon}</span><b>{t(k.label)}</b>
              </button>
            ))}
          </div>
          <div className="fam-form-grid">
            <div>
              <label>{kind === "spend_cap" ? t("Family cap (amount)") : t("Target (days)")}</label>
              <input type="number" min="1" value={target} onChange={(e) => setTarget(e.target.value)} required />
            </div>
            <div>
              <label>{t("Lasts (days)")}</label>
              <input type="number" min="1" max="60" value={days} onChange={(e) => setDays(e.target.value)} required />
            </div>
            {kind === "spend_cap" && (
              <div>
                <label>{t("Only this category (optional)")}</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)}>
                  <option value="">{t("All spending")}</option>
                  {["Food", "Groceries", "Shopping", "Transport", "Bills", "Entertainment", "Health"].map((c) => <option key={c} value={c}>{t(c)}</option>)}
                </select>
              </div>
            )}
            <div>
              <label>{t("Name (optional)")}</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
            </div>
          </div>
          <button className="btn-primary" disabled={busy} style={{ marginTop: "0.8rem" }}>{t("Start challenge")}</button>
        </form>
      ) : (
        <p className="fam-note">{t("Ask a parent to start a challenge.")}</p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function ManageTab({ data, act, busy }) {
  const { confirm } = useFeedback();
  const { family, me, members, avatars } = data;
  const [childName, setChildName] = useState("");
  const [childAge, setChildAge] = useState("10");
  const [childAvatar, setChildAvatar] = useState("🧸");
  const [fname, setFname] = useState(family.name);
  const [fbudget, setFbudget] = useState(family.monthly_budget || "");

  const switchTo = async (uid) => {
    const r = await act(() => api.post(`/family/switch/${uid}`));
    if (r?.data?.access_token) {
      localStorage.setItem("ss_parent_token", localStorage.getItem("ss_token") || "");
      localStorage.setItem("ss_parent_user", localStorage.getItem("ss_user") || "");
      localStorage.setItem("ss_token", r.data.access_token);
      localStorage.setItem("ss_user", JSON.stringify(r.data.user));
      window.location.assign("/");
    }
  };

  return (
    <div className="fam-manage">
      <div className="card">
        <span className="eyebrow">{t("My settings")}</span>
        <h3>{t("Privacy — what can the family see?")}</h3>
        <div className="fam-share">
          {SHARE_OPTIONS.map((o) => (
            <button key={o.id} className={`fam-share-opt ${me.share_level === o.id ? "on" : ""}`} disabled={busy}
              onClick={() => act(() => api.patch("/family/me", { share_level: o.id }))}>
              <b>{t(o.label)}</b><small>{t(o.hint)}</small>
            </button>
          ))}
        </div>
        <p className="fam-note">{t("Parents can always see their children's spending so they can guide them.")}</p>
        <h3 style={{ marginTop: "1rem" }}>{t("My avatar")}</h3>
        <div className="fam-emoji-row">
          {avatars.map((a) => (
            <button key={a} className={`fam-emoji ${me.avatar === a ? "on" : ""}`} onClick={() => act(() => api.patch("/family/me", { avatar: a }))} aria-pressed={me.avatar === a}>{a}</button>
          ))}
        </div>
      </div>

      <div className="card">
        <span className="eyebrow">{t("Members")}</span>
        <div className="fam-list">
          {members.map((m) => (
            <div key={m.user_id} className="fam-row">
              <div className="fam-row-main static">
                <span className="fam-avatar" aria-hidden>{m.avatar}</span>
                <span className="fam-who"><b>{m.name}{m.is_me ? ` ${t("(you)")}` : ""}</b><small>{t(ROLE_LABEL[m.role] || m.role)}{m.managed ? ` · ${t("child profile")}` : ""}</small></span>
                {me.is_parent && !m.is_me && m.role !== "owner" && (
                  <span className="fam-actions">
                    <select value={m.role} disabled={busy} aria-label={t("Role")}
                      onChange={(e) => act(() => api.patch(`/family/members/${m.user_id}/role`, { role: e.target.value }))}>
                      {["member", "child", ...(me.role === "owner" ? ["parent"] : [])].map((r) => <option key={r} value={r}>{t(ROLE_LABEL[r])}</option>)}
                    </select>
                    {m.managed && <button className="btn-ghost fam-small" onClick={() => switchTo(m.user_id)}>{t("Open profile")}</button>}
                    <button className="btn-ghost fam-small" disabled={busy}
                      onClick={async () => (await confirm({ message: t("Remove {name} from the family?", { name: m.name }), danger: true, confirmLabel: t("Remove") })) && act(() => api.delete(`/family/members/${m.user_id}`))}>{t("Remove")}</button>
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {me.is_parent && (
        <>
          <form className="card" onSubmit={(e) => { e.preventDefault(); act(() => api.post("/family/children", { name: childName, age: Number(childAge), avatar: childAvatar })).then(() => setChildName("")); }}>
            <span className="eyebrow">{t("For little ones")}</span>
            <h3>{t("Add a child profile")}</h3>
            <p className="fam-note">{t("No email or password needed. You can open their profile to log spending with them.")}</p>
            <div className="fam-form-grid">
              <div><label>{t("Name")}</label><input value={childName} onChange={(e) => setChildName(e.target.value)} required maxLength={60} /></div>
              <div><label>{t("Age")}</label><input type="number" min="3" max="17" value={childAge} onChange={(e) => setChildAge(e.target.value)} required /></div>
            </div>
            <div className="fam-emoji-row" style={{ margin: "0.6rem 0" }}>
              {avatars.map((a) => <button type="button" key={a} className={`fam-emoji ${childAvatar === a ? "on" : ""}`} onClick={() => setChildAvatar(a)}>{a}</button>)}
            </div>
            <button className="btn-primary" disabled={busy || !childName.trim()}>{t("Add child")}</button>
          </form>

          <form className="card" onSubmit={(e) => { e.preventDefault(); act(() => api.patch("/family", { name: fname, monthly_budget: Number(fbudget) || 0 })); }}>
            <span className="eyebrow">{t("Family settings")}</span>
            <div className="fam-form-grid">
              <div><label>{t("Family name")}</label><input value={fname} onChange={(e) => setFname(e.target.value)} required /></div>
              <div><label>{t("Monthly family budget (optional)")}</label><input type="number" min="0" value={fbudget} onChange={(e) => setFbudget(e.target.value)} /></div>
            </div>
            <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.8rem", flexWrap: "wrap" }}>
              <button className="btn-primary" disabled={busy}>{t("Save")}</button>
              <button type="button" className="btn-ghost" disabled={busy} onClick={() => act(() => api.post("/family/regenerate-code"))}>{t("New invite code")}</button>
            </div>
          </form>
        </>
      )}

      <div className="card">
        <button className="btn-ghost" style={{ color: "var(--coral)" }} disabled={busy}
          onClick={async () => (await confirm({ message: t("Leave this family? Your own data stays safe in your account."), danger: true, confirmLabel: t("Leave") })) && act(() => api.post("/family/leave"))}>
          {t("Leave family")}
        </button>
      </div>
    </div>
  );
}
