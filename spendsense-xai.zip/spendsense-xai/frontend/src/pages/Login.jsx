import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { useLanguage } from "../LanguageContext";
import AuthShell from "../components/AuthShell";

export default function Login() {
  const { login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [email, setEmail] = useState("demo@spendsense.app");
  const [password, setPassword] = useState("demo1234");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError(!err?.response
        ? t("Can't reach the server. Start the backend (see README) and try again.")
        : err.response.data?.detail || t("Login failed. Check your credentials."));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell>
      <div className="card auth-card">
        <span className="eyebrow">{t("login.welcome")}</span>
        <h2>{t("login.heading")}</h2>
        <p style={{ fontSize: "0.85rem" }}>{t("login.hint")}</p>
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "0.9rem", marginTop: "1rem" }}>
          <div>
            <label>{t("common.email")}</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label>{t("common.password")}</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {error && <div style={{ color: "var(--coral)", fontSize: "0.82rem" }}>{error}</div>}
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? "…" : t("common.signIn")}
          </button>
        </form>
        <p style={{ marginTop: "1rem", fontSize: "0.82rem" }}>
          {t("login.noAccount")} <Link to="/register">{t("login.createOne")}</Link>
        </p>
      </div>
    </AuthShell>
  );
}
