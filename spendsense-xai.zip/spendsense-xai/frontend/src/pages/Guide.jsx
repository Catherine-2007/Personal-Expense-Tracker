import { useEffect, useMemo, useState } from "react";
import { useAuth } from "../AuthContext";
import { Link } from "react-router-dom";
import { t } from "../i18n";
import { GUIDE, GUIDE_LOOP } from "../guideContent";
import Icon from "../components/Icon";

export default function Guide() {
  const { user } = useAuth();
  useEffect(() => { try { localStorage.setItem(`ss_guide_seen_${user?.id}`, "1"); } catch { /* ignore */ } }, [user?.id]);
  const [q, setQ] = useState("");
  const [sec, setSec] = useState("all");
  const [open, setOpen] = useState(null);

  const sections = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return GUIDE.filter((s) => sec === "all" || s.id === sec)
      .map((s) => ({
        ...s,
        items: s.items.filter((i) => !needle ||
          [t(i.name), t(i.what), t(i.how)].some((x) => x.toLowerCase().includes(needle))),
      }))
      .filter((s) => s.items.length);
  }, [q, sec]);

  return (
    <div className="guide">
      <div className="page-head">
        <div>
          <h1>{t("Feature guide")}</h1>
          <p>{t("What every feature does, in plain words, and how it works behind the scenes.")}</p>
        </div>
      </div>

      <section className="card guide-hero">
        <span className="eyebrow">{t("The idea in one line")}</span>
        <h2>{t("Most trackers only record. SpendSense-XAI learns, explains and helps you change.")}</h2>
        <ol className="loop">
          {GUIDE_LOOP.map((s, i) => (
            <li key={s.k}>
              <span className="loop-n">{i + 1}</span>
              <b>{t(s.k)}</b>
              <small>{t(s.d)}</small>
            </li>
          ))}
        </ol>
      </section>

      <div className="guide-tools">
        <div className="search-box">
          <Icon name="search" size={16} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("Search features...")} aria-label={t("Search features...")} />
        </div>
        <div className="guide-chips" role="tablist">
          <button className={`gchip${sec === "all" ? " on" : ""}`} onClick={() => setSec("all")}>{t("All")}</button>
          {GUIDE.map((s) => (
            <button key={s.id} className={`gchip${sec === s.id ? " on" : ""}`} onClick={() => setSec(s.id)}>{t(s.title)}</button>
          ))}
        </div>
      </div>

      {sections.length === 0 && <div className="card empty-state"><Icon name="search" size={28} /><p>{t("No feature matches that search.")}</p></div>}

      {sections.map((s) => (
        <section key={s.id} className="guide-sec">
          <div className="guide-sec-head">
            <span className="sec-ico"><Icon name={s.icon} size={20} /></span>
            <div>
              <h2>{t(s.title)}</h2>
              <p>{t(s.blurb)}</p>
            </div>
          </div>
          <div className="guide-grid">
            {s.items.map((i) => {
              const key = `${s.id}:${i.name}`;
              const on = open === key || q.trim() !== "";
              return (
                <article key={key} className={`card guide-item${on ? " open" : ""}`}>
                  <button className="guide-q" onClick={() => setOpen(open === key ? null : key)} aria-expanded={on}>
                    <span>{t(i.name)}</span>
                    <span className="plus" aria-hidden="true">{on ? "-" : "+"}</span>
                  </button>
                  <p className="what">{t(i.what)}</p>
                  {on && (
                    <div className="how">
                      <span className="eyebrow">{t("How it works")}</span>
                      <p>{t(i.how)}</p>
                    </div>
                  )}
                  {i.to && <Link className="try" to={i.to}>{t("Open")} →</Link>}
                </article>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
