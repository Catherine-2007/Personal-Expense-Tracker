import { useEffect, useState } from "react";
import api from "../api";
import ParticleHeader from "../components/ParticleHeader";
import { useAuth } from "../AuthContext";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { useLanguage } from "../LanguageContext";
import { iconFor } from "../categoryIcons";

import { t, tn, tx } from "../i18n";

export default function Report() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const currency = user?.currency || "INR";
  const { money } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isSenior = mode === "senior";
  const [report, setReport] = useState(null);

  useEffect(() => {
    api.get("/reports/monthly").then((r) => setReport(r.data));
  }, []);

  if (!report) return <p>{t("Loading…")}</p>;

  const spentLess = report.self_comparison.pct_change_vs_baseline < 0;
  const changeAbs = Math.abs(report.self_comparison.pct_change_vs_baseline);
  const topChange = report.what_changed[0];

  return (
    <div style={{ maxWidth: isSenior ? 720 : undefined }}>
      <ParticleHeader
        mode={mode}
        title={isKid ? t("My Money Story") : isSenior ? t("Your Monthly Summary") : t("report.title")}
        subtitle={report.period}
      />

      {isKid ? (
        <>
          <div className="card" style={{ marginBottom: "1rem", textAlign: "center" }}>
            <div style={{ fontSize: "2.4rem" }}>{spentLess ? "🌟" : "📈"}</div>
            <p style={{ fontSize: "1.05rem", fontWeight: 600, margin: "0.4rem 0" }}>
              {spentLess
                ? t("Great job! You spent {pct}% less than usual this month!", { pct: changeAbs.toFixed(0) })
                : t("You spent a bit more than usual this month — that's okay, let's try again!")}
            </p>
            <p style={{ fontSize: "0.9rem" }}>
              {tx("Total spent: **{amount}**", { amount: money(report.total_spend) })}
            </p>
          </div>

          {topChange && (
            <div className="card" style={{ marginBottom: "1rem" }}>
              <span className="eyebrow">{t("What changed the most")}</span>
              <div style={{ display: "flex", alignItems: "center", gap: "0.8rem", marginTop: "0.4rem" }}>
                <span style={{ fontSize: "2rem" }}>{iconFor(topChange.category)}</span>
                <p style={{ margin: 0, fontSize: "0.92rem" }}>
                  {topChange.direction === "increased" ? t("{category} spending increased by {amount} this month.", { category: t(topChange.category), amount: money(Math.abs(topChange.change)) }) : t("{category} spending decreased by {amount} this month.", { category: t(topChange.category), amount: money(Math.abs(topChange.change)) })}
                </p>
              </div>
            </div>
          )}

          {report.goal_status.length > 0 && (
            <div className="card">
              <span className="eyebrow">{t("Your piggy bank goals")}</span>
              {report.goal_status.map((g) => (
                <p key={g.goal} style={{ fontSize: "0.92rem", margin: "0.4rem 0" }}>
                  {g.at_risk ? "🐷 " : "🎉 "}
                  <strong>{g.goal}:</strong>{" "}
                  {g.at_risk
                    ? t("You might need to save a little more each month to reach this in time!")
                    : t("You're on track — keep it up!")}
                </p>
              ))}
            </div>
          )}
        </>
      ) : isSenior ? (
        <>
          <div className="card" style={{ marginBottom: "1.2rem" }}>
            <p style={{ fontSize: "1.15rem", lineHeight: 1.6, margin: 0 }}>
              {tn("You spent {amount} this month, which is {change} than your usual month.", {
                amount: <strong>{money(report.total_spend)}</strong>,
                change: <strong style={{ color: spentLess ? "var(--teal)" : "var(--coral)" }}>
                  {spentLess ? t("{pct}% less", { pct: changeAbs.toFixed(0) }) : t("{pct}% more", { pct: changeAbs.toFixed(0) })}
                </strong>,
              })}
            </p>
          </div>

          {topChange && (
            <div className="card" style={{ marginBottom: "1.2rem" }}>
              <span className="eyebrow">{t("Biggest change this month")}</span>
              <p style={{ fontSize: "1.05rem", lineHeight: 1.6, margin: "0.4rem 0 0" }}>
                {iconFor(topChange.category)} {topChange.direction === "increased" ? t("{category} spending increased by {amount}.", { category: t(topChange.category), amount: money(Math.abs(topChange.change)) }) : t("{category} spending decreased by {amount}.", { category: t(topChange.category), amount: money(Math.abs(topChange.change)) })}{" "}
                {topChange.reason || ""}
              </p>
            </div>
          )}

          <div className="card">
            <span className="eyebrow">{t("Your savings goals")}</span>
            {report.goal_status.length === 0 ? (
              <p style={{ fontSize: "1.05rem" }}>{t("No active goals — add one on the Goals page.")}</p>
            ) : (
              report.goal_status.map((g) => (
                <div key={g.goal} style={{ marginTop: "0.6rem" }}>
                  <p style={{ fontSize: "1.05rem", margin: 0 }}>
                    <strong>{g.goal}:</strong>{" "}
                    {g.at_risk
                      ? t("You may need to save about {amount} more per month to reach this goal on time.", { amount: money(g.monthly_gap) })
                      : t("You're on track to reach this goal.")}
                  </p>
                </div>
              ))
            )}
          </div>
        </>
      ) : (
        <>
          <div className="card" style={{ marginBottom: "1rem" }}>
            <span className="eyebrow">{t("Self-comparison (personal baseline)")}</span>
            <p style={{ fontSize: "0.9rem" }}>
              {tn("You're compared only against {own} trailing 3-month average — never against other people.", { own: <strong>{t("your own")}</strong> })}
            </p>
            <div style={{ display: "flex", gap: "2rem" }}>
              <Metric label={t("This month")} value={money(report.self_comparison.this_month_total)} />
              <Metric label={t("Your 3-mo average")} value={money(report.self_comparison.personal_baseline_avg)} />
              <Metric
                label={t("Change")}
                value={`${report.self_comparison.pct_change_vs_baseline > 0 ? "+" : ""}${report.self_comparison.pct_change_vs_baseline}%`}
                accent={report.self_comparison.pct_change_vs_baseline > 0 ? "var(--coral)" : "var(--teal)"}
              />
            </div>
          </div>

          <div className="card" style={{ marginBottom: "1rem" }}>
            <span className="eyebrow">{t("What changed")}</span>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem", marginTop: "0.6rem" }}>
              {report.what_changed.map((c) => (
                <div key={c.category} style={{ padding: "0.7rem", background: "var(--surface-raised)", borderRadius: 10 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <strong style={{ fontSize: "0.88rem" }}>{iconFor(c.category)} {t(c.category)}</strong>
                    <span className={c.direction === "increased" ? "pill pill-coral" : "pill pill-teal"}>
                      {c.direction === "increased" ? "▲" : "▼"} {money(Math.abs(c.change))}
                    </span>
                  </div>
                  {c.reason && <p style={{ margin: "0.3rem 0 0", fontSize: "0.8rem" }}>{c.reason}</p>}
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <span className="eyebrow">{t("Goal-conflict detector")}</span>
            {report.goal_status.length === 0 ? (
              <p>{t(
                "No active goals — add one on the Goals page to see if your spending pace is on track."
              )}</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem", marginTop: "0.6rem" }}>
                {report.goal_status.map((g) => (
                  <div key={g.goal} style={{ padding: "0.8rem", borderRadius: 10, background: "var(--surface-raised)", border: g.at_risk ? "1px solid var(--coral)" : "1px solid transparent" }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <strong style={{ fontSize: "0.9rem" }}>{g.goal}</strong>
                      <span className={g.at_risk ? "pill pill-coral" : "pill pill-teal"}>{g.at_risk ? t("At risk") : t("On track")}</span>
                    </div>
                    <p style={{ fontSize: "0.82rem", margin: "0.3rem 0 0" }}>
                      {t("Needs {need}/mo · currently saving ~{have}/mo", { need: money(g.required_monthly_saving), have: money(g.actual_monthly_saving) })}
                      {g.at_risk && <> · {t("gap of {gap}/mo", { gap: money(g.monthly_gap) })}</>}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function Metric({ label, value, accent }) {
  return (
    <div>
      <div style={{ fontSize: "0.74rem", color: "var(--text-muted)" }}>{label}</div>
      <div className="mono" style={{ fontSize: "1.2rem", fontWeight: 600, color: accent || "var(--text-primary)" }}>{value}</div>
    </div>
  );
}
