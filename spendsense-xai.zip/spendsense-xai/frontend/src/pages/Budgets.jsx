import { useEffect, useState } from "react";
import api from "../api";
import ParticleHeader from "../components/ParticleHeader";
import { useAuth } from "../AuthContext";
import { useFeedback } from "../FeedbackContext";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";
import { tp, t } from "../i18n";

const COLORS = { ok: "var(--teal)", warn: "var(--amber)", over: "var(--coral)" };

/** One progress row, shared with the dashboard card. */
export function BudgetBar({ item, money, label, big }) {
  const pct = Math.min(100, item.pct);
  return (
    <div style={{ marginBottom: "0.9rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "0.6rem", fontSize: big ? "1.05rem" : "0.86rem" }}>
        <b>{label}</b>
        <span style={{ color: COLORS[item.status], fontFamily: "var(--font-mono)" }}>
          {money(item.spent)} / {money(item.limit)}
        </span>
      </div>
      <div role="progressbar" aria-valuenow={Math.round(item.pct)} aria-valuemin={0} aria-valuemax={100}
        style={{ height: big ? 16 : 10, borderRadius: 8, background: "var(--surface-raised)", overflow: "hidden", marginTop: "0.3rem" }}>
        <div className="grow-bar" style={{ width: `${pct}%`, height: "100%", background: COLORS[item.status] }} />
      </div>
      <div style={{ fontSize: big ? "0.95rem" : "0.74rem", color: "var(--text-muted)", marginTop: "0.25rem" }}>
        {item.status === "over"
          ? t("Over by {amount}", { amount: money(-item.remaining) })
          : t("{amount} left", { amount: money(item.remaining) })}
        {item.status !== "over" && !item.on_pace && <span style={{ color: "var(--amber)" }}> · {t("on pace to go over")}</span>}
      </div>
    </div>
  );
}

export default function Budgets() {
  const { user } = useAuth();
  const { confirm } = useFeedback();
  const { money, toBase, toDisplay, currency } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isSenior = mode === "senior";
  const [data, setData] = useState(null);
  const [cat, setCat] = useState("ALL");
  const [amount, setAmount] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => api.get("/budgets").then((r) => setData(r.data)).catch(() => setData({ items: [], categories: [], unbudgeted: [] }));
  useEffect(() => { load(); }, []);

  async function save(e) {
    e.preventDefault();
    if (!(Number(amount) > 0)) { setErr(t("Enter an amount greater than zero.")); return; }
    setBusy(true); setErr("");
    try {
      const { data: d } = await api.put(`/budgets/${cat}`, { monthly_limit: toBase(amount) });
      setData(d); setAmount("");
    } catch (ex) {
      setErr(ex?.response?.data?.detail || t("Something went wrong — try again."));
    } finally { setBusy(false); }
  }

  async function remove(category) {
    if (!(await confirm({ message: t("Remove this budget?"), danger: true, confirmLabel: t("Remove") }))) return;
    const { data: d } = await api.delete(`/budgets/${category}`);
    setData(d);
  }

  function edit(category, limit) {
    setCat(category); setAmount(String(toDisplay(limit)));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <div style={{ maxWidth: isSenior ? 720 : undefined }}>
      <ParticleHeader
        mode={mode}
        title={isKid ? t("My Spending Limits") : t("Budgets")}
        subtitle={isKid ? t("Pick how much you want to spend each month and watch the bar!")
          : t("Set a monthly limit for everything or for a single category and see how you're pacing.")}
      />

      <div className="card" style={{ marginBottom: "1.2rem" }}>
        <span className="eyebrow">{t("Set a monthly limit")}</span>
        <form onSubmit={save} style={{ display: "flex", gap: "0.8rem", flexWrap: "wrap", alignItems: "end", marginTop: "0.6rem" }}>
          <div style={{ minWidth: 180 }}>
            <label>{t("Category")}</label>
            <select value={cat} onChange={(e) => setCat(e.target.value)}>
              <option value="ALL">{t("Everything (overall)")}</option>
              {(data?.categories || []).map((c) => <option key={c} value={c}>{t(c)}</option>)}
            </select>
          </div>
          <div style={{ minWidth: 180 }}>
            <label>{t("Monthly limit ({currency})", { currency })}</label>
            <input type="number" min="1" step="any" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="20000" />
          </div>
          <button className="btn-primary" type="submit" disabled={busy}>{t("Save limit")}</button>
          {err && <span className="goal-err">{err}</span>}
        </form>
      </div>

      {!data ? <p>{t("Loading…")}</p> : (
        <div className="card">
          <span className="eyebrow">{t("This month")}{data.days_left != null ? ` · ${tp(data.days_left, "{n} day left", "{n} days left")}` : ""}</span>
          {!data.overall && data.items.length === 0 && <p style={{ marginTop: "0.6rem" }}>{t("No budgets yet — set one above.")}</p>}
          <div style={{ marginTop: "0.8rem" }}>
            {data.overall && (
              <div className="budget-row">
                <BudgetBar item={data.overall} money={money} label={`🎯 ${t("Everything (overall)")}`} big={isSenior} />
                <div className="budget-btns">
                  <button className="btn-ghost" onClick={() => edit("ALL", data.overall.limit)}>{t("Edit")}</button>
                  <button className="btn-danger" onClick={() => remove("ALL")}>{t("Delete")}</button>
                </div>
              </div>
            )}
            {data.items.map((it) => (
              <div className="budget-row" key={it.category}>
                <BudgetBar item={it} money={money} label={`${iconFor(it.category)} ${t(it.category)}`} big={isSenior} />
                <div className="budget-btns">
                  <button className="btn-ghost" onClick={() => edit(it.category, it.limit)}>{t("Edit")}</button>
                  <button className="btn-danger" onClick={() => remove(it.category)}>{t("Delete")}</button>
                </div>
              </div>
            ))}
          </div>
          {data.unbudgeted?.length > 0 && (
            <div style={{ marginTop: "0.4rem", fontSize: "0.8rem", color: "var(--text-muted)" }}>
              {t("Spending without a limit")}: {data.unbudgeted.map((u) => `${iconFor(u.category)} ${t(u.category)} ${money(u.spent)}`).join(" · ")}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
