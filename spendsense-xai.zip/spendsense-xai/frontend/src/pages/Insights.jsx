import { useEffect, useState } from "react";
import api from "../api";
import ParticleHeader from "../components/ParticleHeader";
import ConfidenceRing from "../components/ConfidenceRing";
import { useAuth } from "../AuthContext";
import { useLanguage } from "../LanguageContext";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";

import { contextLabel, t, tp } from "../i18n";

function confidenceWord(conf) {
  if (conf >= 0.8) return t("Very likely");
  if (conf >= 0.6) return t("Likely");
  if (conf >= 0.4) return t("Possible");
  return t("Worth watching");
}

export default function Insights() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const currency = user?.currency || "INR";
  const { money } = useMoney();
  const mode = user?.platform_mode || "adult";
  const isKid = mode === "kid";
  const isSenior = mode === "senior";
  const isTeen = mode === "teen";

  const [triggers, setTriggers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [explanation, setExplanation] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await api.get("/insights/triggers", { params: { active_only: true } });
    setTriggers(data);
    setLoading(false);
    if (data.length && !selected) selectTrigger(data[0]);
  }

  useEffect(() => { load(); }, []); // eslint-disable-line

  async function refresh() {
    setRefreshing(true);
    try {
      const { data } = await api.post("/insights/triggers/refresh");
      setTriggers(data);
      if (data.length) selectTrigger(data[0]);
    } finally {
      setRefreshing(false);
    }
  }

  async function selectTrigger(tr) {
    setSelected(tr);
    const { data } = await api.get(`/insights/triggers/${tr.id}/explain`);
    setExplanation(data);
  }

  const refreshLabel = refreshing
    ? (isKid ? t("Looking for clues…") : t("Mining patterns…"))
    : (isKid ? t("🔍 Find my patterns!") : t("Refresh triggers"));

  return (
    <div>
      <ParticleHeader
        mode={mode}
        title={isKid ? t("🕵️ My Pattern Detective") : isSenior ? t("Your Spending Patterns") : t("insights.title")}
        subtitle={
          isKid
            ? t("The app looks for clues in your spending and shows you what it finds!")
            : isSenior
            ? t(
            "The app looks at your spending history and points out habits, with clear evidence for each one."
          )
            : isTeen
            ? t(
            "Every pattern below is backed by counted evidence and a confidence score — never a bare assertion. The more you log, the sharper these get."
          )
            : t(
            "Every pattern below is backed by counted evidence and a confidence score — never a bare assertion."
          )
        }
        action={
          <button className="btn-primary" onClick={refresh} disabled={refreshing}>
            {refreshLabel}
          </button>
        }
      />

      {loading ? <p>{t("Loading…")}</p> : triggers.length === 0 ? (
        <div className="card">
          <p>
            {isKid
              ? t(
              "No clues found yet! Add at least 3 similar purchases (like snacks after school), then tap 'Find my patterns!'"
            )
              : t(
              "No triggers discovered yet. Log at least 3 similar expenses in a shared context (e.g. late-night food orders), then click \"Refresh triggers\"."
            )}
          </p>
        </div>
      ) : isSenior ? (
        <SeniorTriggerList triggers={triggers} onSuggest={selectTrigger} currency={currency} />
      ) : isKid ? (
        <KidTriggerGrid triggers={triggers} currency={currency} />
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: "1.2rem" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: "0.7rem" }}>
            {triggers.map((tr) => (
              <button
                key={tr.id}
                onClick={() => selectTrigger(tr)}
                className="card"
                style={{
                  textAlign: "left",
                  display: "flex",
                  alignItems: "center",
                  gap: "0.9rem",
                  borderColor: selected?.id === tr.id ? "var(--teal)" : "var(--border-soft)",
                  background: selected?.id === tr.id ? "rgba(53,208,192,0.06)" : "var(--surface)",
                }}
              >
                <ConfidenceRing value={tr.confidence} size={50} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{t(tr.category_affected)}</div>
                  <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>
                    {contextLabel(tr.context_key)} · {tp(tr.occurrences, "{n} occurrence", "{n} occurrences")}
                  </div>
                </div>
              </button>
            ))}
          </div>

          <div className="card">
            {explanation ? (
              <>
                <span className="eyebrow">{isTeen ? t("Why this happens") : t("AI explanation")}</span>
                <h3>{explanation.headline}</h3>
                <div style={{ display: "flex", alignItems: "center", gap: "0.8rem", margin: "0.8rem 0" }}>
                  <ConfidenceRing value={explanation.confidence} size={70} />
                  <p style={{ margin: 0 }}>{explanation.seen_in}</p>
                </div>
                <div style={{ marginBottom: "1rem" }}>
                  <span className="eyebrow" style={{ color: "var(--text-muted)" }}>{t("Evidence")}</span>
                  <ul style={{ margin: "0.4rem 0 0", paddingLeft: "1.1rem", color: "var(--text-primary)", fontSize: "0.86rem" }}>
                    {explanation.evidence.map((ev, i) => <li key={i} style={{ marginBottom: "0.3rem" }}>{ev}</li>)}
                  </ul>
                </div>
                <div style={{ padding: "0.9rem", background: "var(--surface-raised)", borderRadius: 10 }}>
                  <span className="eyebrow" style={{ color: "var(--amber)" }}>{t("Why it matters")}</span>
                  <p style={{ margin: 0, fontSize: "0.86rem" }}>{explanation.why_it_matters}</p>
                </div>
                {selected && <SuggestInterventionButton triggerId={selected.id} isTeen={isTeen} />}
              </>
            ) : <p>{t("Select a trigger to see its explanation.")}</p>}
          </div>
        </div>
      )}

      {selected && !isSenior && (
        <CounterfactualSimulator category={selected.category_affected} currency={currency} mode={mode} />
      )}
    </div>
  );
}

function KidTriggerGrid({ triggers, currency }) {
  const [openId, setOpenId] = useState(triggers[0]?.id ?? null);
  const [explanations, setExplanations] = useState({});

  async function toggle(tr) {
    if (openId === tr.id) { setOpenId(null); return; }
    setOpenId(tr.id);
    if (!explanations[tr.id]) {
      const { data } = await api.get(`/insights/triggers/${tr.id}/explain`);
      setExplanations((prev) => ({ ...prev, [tr.id]: data }));
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem" }}>
      {triggers.map((tr) => {
        const open = openId === tr.id;
        const exp = explanations[tr.id];
        return (
          <div key={tr.id} className="card" style={{ borderColor: open ? "var(--coral)" : "var(--border-soft)" }}>
            <button
              onClick={() => toggle(tr)}
              style={{ display: "flex", alignItems: "center", gap: "0.9rem", width: "100%", textAlign: "left", background: "transparent" }}
            >
              <span style={{ fontSize: "2.2rem" }}>{iconFor(tr.category_affected)}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: "1.05rem" }}>{t("{category} clue found!", { category: t(tr.category_affected) })}</div>
                <div style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>
                  {t("Happens a lot during {context} times", { context: contextLabel(tr.context_key, " + ") })}
                </div>
              </div>
              <span style={{ fontSize: "1.2rem" }}>{open ? "▲" : "▼"}</span>
            </button>
            {open && exp && (
              <div style={{ marginTop: "0.8rem", paddingTop: "0.8rem", borderTop: "1px solid var(--border-soft)" }}>
                <p style={{ fontSize: "0.9rem" }}>🕵️ {exp.evidence[0]}</p>
                <p style={{ fontSize: "0.9rem", color: "var(--amber)" }}>💡 {exp.why_it_matters}</p>
                <TryTipButton triggerId={tr.id} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function TryTipButton({ triggerId }) {
  const [tip, setTip] = useState(null);
  const [loading, setLoading] = useState(false);

  async function get() {
    setLoading(true);
    try {
      const { data } = await api.post(`/interventions/suggest/${triggerId}`);
      setTip(data);
    } finally {
      setLoading(false);
    }
  }

  return tip ? (
    <div style={{ marginTop: "0.6rem", padding: "0.7rem", background: "var(--surface-raised)", borderRadius: 10 }}>
      <strong style={{ fontSize: "0.85rem" }}>{t("✨ Try this:")}</strong>
      <p style={{ margin: "0.3rem 0 0", fontSize: "0.85rem" }}>{tip.description}</p>
    </div>
  ) : (
    <button className="btn-primary" onClick={get} disabled={loading} style={{ marginTop: "0.4rem" }}>
      {loading ? "…" : t("Get a fun tip! 💡")}
    </button>
  );
}

function SeniorTriggerList({ triggers, currency }) {
  const [openId, setOpenId] = useState(null);
  const [explanations, setExplanations] = useState({});

  async function toggle(tr) {
    if (openId === tr.id) { setOpenId(null); return; }
    setOpenId(tr.id);
    if (!explanations[tr.id]) {
      const { data } = await api.get(`/insights/triggers/${tr.id}/explain`);
      setExplanations((prev) => ({ ...prev, [tr.id]: data }));
    }
  }

  return (
    <div style={{ maxWidth: 720, display: "flex", flexDirection: "column", gap: "1rem" }}>
      {triggers.map((tr) => {
        const open = openId === tr.id;
        const exp = explanations[tr.id];
        return (
          <div key={tr.id} className="card">
            <button
              onClick={() => toggle(tr)}
              style={{ display: "flex", alignItems: "center", gap: "1rem", width: "100%", textAlign: "left", background: "transparent" }}
            >
              <span style={{ fontSize: "1.8rem" }}>{iconFor(tr.category_affected)}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: "1.15rem" }}>{t(tr.category_affected)}</div>
                <div style={{ fontSize: "1rem", color: "var(--text-muted)" }}>
                  {confidenceWord(tr.confidence)} — {t("during {context} times", { context: contextLabel(tr.context_key, " + ") })}
                </div>
              </div>
              <span style={{ fontSize: "1.3rem" }}>{open ? "▲" : "▼"}</span>
            </button>
            {open && exp && (
              <div style={{ marginTop: "1rem", paddingTop: "1rem", borderTop: "1px solid var(--border-soft)" }}>
                <p style={{ fontSize: "1.05rem", lineHeight: 1.6 }}>{exp.evidence[0]}</p>
                <p style={{ fontSize: "1.05rem", lineHeight: 1.6, color: "var(--amber)" }}>{exp.why_it_matters}</p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function SuggestInterventionButton({ triggerId, isTeen }) {
  const [state, setState] = useState("idle");
  const [intervention, setIntervention] = useState(null);

  async function suggest() {
    setState("loading");
    const { data } = await api.post(`/interventions/suggest/${triggerId}`);
    setIntervention(data);
    setState("done");
  }

  return (
    <div style={{ marginTop: "1rem" }}>
      {!intervention ? (
        <button className="btn-ghost" onClick={suggest} disabled={state === "loading"}>
          {state === "loading" ? t("Thinking…") : isTeen ? t("🎯 Get a challenge for this") : t("Suggest an intervention for this")}
        </button>
      ) : (
        <div style={{ padding: "0.8rem", border: "1px solid var(--teal-dim)", borderRadius: 10 }}>
          <span className="pill pill-teal">{t(intervention.intervention_type)} · {t("variant {v}", { v: intervention.variant })}</span>
          <p style={{ marginTop: "0.5rem", marginBottom: 0, fontSize: "0.86rem" }}>{intervention.description}</p>
        </div>
      )}
    </div>
  );
}

function CounterfactualSimulator({ category, currency, mode }) {
  const { money } = useMoney();
  const [reduction, setReduction] = useState(1);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const isKid = mode === "kid";

  useEffect(() => { run(); }, [category]); // eslint-disable-line

  async function run() {
    setLoading(true);
    try {
      const { data } = await api.post("/insights/counterfactual", {
        category, times_per_week_reduction: reduction,
      });
      setResult(data);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card" style={{ marginTop: "1.2rem" }}>
      <span className="eyebrow">{isKid ? t("What if game! 🎮") : t("Counterfactual simulator")}</span>
      <h3>{isKid ? t("What if you buy less {category}?", { category: t(category) }) : t("What if you cut {category} habits?", { category: t(category) })}</h3>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem", margin: "0.8rem 0" }}>
        <input
          type="range" min="0" max="7" step="0.5" value={reduction}
          onChange={(e) => setReduction(Number(e.target.value))}
          onMouseUp={run} onTouchEnd={run}
          style={{ flex: 1 }}
        />
        <span className="mono" style={{ fontSize: "0.85rem", minWidth: 130 }}>
          {t("{n}x fewer / week", { n: reduction })}
        </span>
      </div>
      {result && !loading && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.8rem" }}>
          <MiniStat label={isKid ? t("You spend now") : t("Current monthly spend")} value={money(result.current_monthly_spend)} />
          <MiniStat label={isKid ? t("You could spend") : t("Projected monthly spend")} value={money(result.projected_monthly_spend)} accent="var(--teal)" />
          <MiniStat label={isKid ? t("You could save! 🎉") : t("Est. annual savings")} value={money(result.estimated_annual_savings)} accent="var(--amber)" />
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value, accent }) {
  return (
    <div style={{ padding: "0.8rem", background: "var(--surface-raised)", borderRadius: 10 }}>
      <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{label}</div>
      <div className="mono" style={{ fontSize: "1.1rem", fontWeight: 600, color: accent || "var(--text-primary)" }}>{value}</div>
    </div>
  );
}
