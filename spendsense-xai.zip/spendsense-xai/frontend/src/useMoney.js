import { useAuth } from "./AuthContext";
import { useCurrencyRates } from "./CurrencyRatesContext";
import { formatCurrency } from "./currency";

/**
 * Amounts from the backend are always in the user's base_currency (the
 * currency they were actually entered in, fixed at signup and never
 * silently changed). The user's `currency` field is just a *display*
 * preference. This hook converts every amount using real exchange rates
 * before formatting, so switching display currency changes the actual
 * represented value -- not just the symbol.
 */
export function useMoney() {
  const { user } = useAuth();
  const { rates, meta } = useCurrencyRates();
  const displayCurrency = user?.currency || "INR";
  const baseCurrency = user?.base_currency || "INR";

  function convert(amount) {
    if (amount == null || Number.isNaN(amount)) return 0;
    if (!rates || !rates[displayCurrency] || !rates[baseCurrency]) return amount;
    return amount * (rates[displayCurrency] / rates[baseCurrency]);
  }

  /** Inverse of convert(): a number the user typed in their display currency -> stored (base) currency. */
  function toBase(amount) {
    const n = Number(amount);
    if (!Number.isFinite(n)) return 0;
    if (!rates || !rates[displayCurrency] || !rates[baseCurrency]) return n;
    return Math.round(n * (rates[baseCurrency] / rates[displayCurrency]) * 100) / 100;
  }

  /** Stored amount -> plain number in display currency, for pre-filling edit boxes. */
  const toDisplay = (amount) => Math.round(convert(amount) * 100) / 100;

  function money(amount) {
    return formatCurrency(convert(amount), displayCurrency);
  }

  return { money, convert, toBase, toDisplay, currency: displayCurrency, baseCurrency, ratesMeta: meta };
}
