/**
 * Receipt image pre-processing — pure functions on grayscale arrays (no DOM),
 * so the exact same code runs in the browser and in Node tests.
 *
 * Pipeline (`preprocessVariants`):
 *   1. grayscale + scale to an OCR-friendly width
 *   2. flatten uneven lighting / shadows (divide by a heavy blur of itself)
 *   3. detect and correct skew (projection-profile search, self-verified)
 *   4. crop to the block of ink (drops table / background clutter)
 *   5. emit TWO variants for OCR: adaptive-threshold (clean black & white) and
 *      contrast-stretched grayscale. The server keeps the more self-consistent pass.
 */

export function toGray(rgba, w, h) {
  const g = new Uint8ClampedArray(w * h);
  for (let i = 0, j = 0; i < g.length; i++, j += 4) {
    g[i] = (rgba[j] * 299 + rgba[j + 1] * 587 + rgba[j + 2] * 114) / 1000;
  }
  return g;
}

export function resizeGray(g, w, h, nw, nh) {
  if (nw === w && nh === h) return g;
  const out = new Uint8ClampedArray(nw * nh);
  const sx = (w - 1) / Math.max(nw - 1, 1);
  const sy = (h - 1) / Math.max(nh - 1, 1);
  for (let y = 0; y < nh; y++) {
    const fy = y * sy, y0 = Math.floor(fy), y1 = Math.min(y0 + 1, h - 1), wy = fy - y0;
    for (let x = 0; x < nw; x++) {
      const fx = x * sx, x0 = Math.floor(fx), x1 = Math.min(x0 + 1, w - 1), wx = fx - x0;
      const a = g[y0 * w + x0] * (1 - wx) + g[y0 * w + x1] * wx;
      const b = g[y1 * w + x0] * (1 - wx) + g[y1 * w + x1] * wx;
      out[y * nw + x] = a * (1 - wy) + b * wy;
    }
  }
  return out;
}

function integral(g, w, h) {
  const I = new Float64Array((w + 1) * (h + 1));
  for (let y = 1; y <= h; y++) {
    let row = 0;
    for (let x = 1; x <= w; x++) {
      row += g[(y - 1) * w + (x - 1)];
      I[y * (w + 1) + x] = I[(y - 1) * (w + 1) + x] + row;
    }
  }
  return I;
}

function boxMean(I, w, h, x, y, r) {
  const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
  const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
  const W = w + 1;
  return (I[y1 * W + x1] - I[y0 * W + x1] - I[y1 * W + x0] + I[y0 * W + x0]) / ((x1 - x0) * (y1 - y0));
}

/** Divide by a heavy blur of the image: removes shadows and gradients. */
export function flattenBackground(g, w, h) {
  const I = integral(g, w, h);
  const r = Math.max(24, Math.round(Math.max(w, h) / 14));
  const out = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const bg = boxMean(I, w, h, x, y, r);
      out[y * w + x] = Math.min(255, (g[y * w + x] / Math.max(bg, 1)) * 238);
    }
  }
  return out;
}

/** Bradley adaptive threshold -> 0 (ink) / 255 (paper). */
export function adaptiveThreshold(g, w, h, t = 0.12) {
  const I = integral(g, w, h);
  const r = Math.max(10, Math.round(w / 28));
  const out = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      out[y * w + x] = g[y * w + x] < boxMean(I, w, h, x, y, r) * (1 - t) ? 0 : 255;
    }
  }
  return out;
}

export function contrastStretch(g, lowPct = 0.01, highPct = 0.995) {
  const hist = new Uint32Array(256);
  for (let i = 0; i < g.length; i++) hist[g[i] | 0]++;
  let acc = 0, lo = 0, hi = 255;
  for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc >= g.length * lowPct) { lo = i; break; } }
  acc = 0;
  for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc >= g.length * highPct) { hi = i; break; } }
  const range = Math.max(hi - lo, 1);
  const out = new Uint8ClampedArray(g.length);
  for (let i = 0; i < g.length; i++) out[i] = ((g[i] - lo) * 255) / range;
  return out;
}

/** Rotate by `deg` around the centre (bilinear), same canvas size. */
export function rotateGray(g, w, h, deg, fill = 238) {
  const rad = (deg * Math.PI) / 180, cos = Math.cos(rad), sin = Math.sin(rad);
  const cx = (w - 1) / 2, cy = (h - 1) / 2;
  const out = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dx = x - cx, dy = y - cy;
      const sx = cos * dx + sin * dy + cx;
      const sy = -sin * dx + cos * dy + cy;
      if (sx < 0 || sy < 0 || sx > w - 1 || sy > h - 1) { out[y * w + x] = fill; continue; }
      const x0 = sx | 0, y0 = sy | 0, x1 = Math.min(x0 + 1, w - 1), y1 = Math.min(y0 + 1, h - 1);
      const wx = sx - x0, wy = sy - y0;
      const a = g[y0 * w + x0] * (1 - wx) + g[y0 * w + x1] * wx;
      const b = g[y1 * w + x0] * (1 - wx) + g[y1 * w + x1] * wx;
      out[y * w + x] = a * (1 - wy) + b * wy;
    }
  }
  return out;
}

/**
 * Ink mask (1 = ink) that ignores things that are NOT text: smooth shadows
 * (local contrast only), the outer margin of the photo, and long straight
 * bars (paper edges, table borders).
 */
export function textMask(g, w, h, t = 0.28) {
  const bw = adaptiveThreshold(g, w, h, t);
  const m = new Uint8Array(w * h);
  const mx = Math.round(w * 0.04), my = Math.round(h * 0.04);
  for (let y = my; y < h - my; y++) for (let x = mx; x < w - mx; x++) m[y * w + x] = bw[y * w + x] === 0 ? 1 : 0;
  const maxRunX = Math.round(w * 0.12), maxRunY = Math.round(h * 0.12);
  for (let y = 0; y < h; y++) {
    let x = 0;
    while (x < w) {
      if (!m[y * w + x]) { x++; continue; }
      let e = x; while (e < w && m[y * w + e]) e++;
      if (e - x > maxRunX) for (let k = x; k < e; k++) m[y * w + k] = 0;
      x = e;
    }
  }
  for (let x = 0; x < w; x++) {
    let y = 0;
    while (y < h) {
      if (!m[y * w + x]) { y++; continue; }
      let e = y; while (e < h && m[e * w + x]) e++;
      if (e - y > maxRunY) for (let k = y; k < e; k++) m[k * w + x] = 0;
      y = e;
    }
  }
  return m;
}

/** Tilt of the text lines in degrees, via projection-profile search. */
export function estimateSkew(g, w, h) {
  const scale = Math.min(1, 640 / Math.max(w, h));
  const sw = Math.max(1, Math.round(w * scale)), sh = Math.max(1, Math.round(h * scale));
  const s = textMask(resizeGray(g, w, h, sw, sh), sw, sh);
  const xs = [], ys = [];
  for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) if (s[y * sw + x]) { xs.push(x); ys.push(y); }
  if (xs.length < 200) return 0;
  const step = Math.max(1, Math.floor(xs.length / 40000));
  const score = (deg) => {
    const rad = (deg * Math.PI) / 180, c = Math.cos(rad), si = Math.sin(rad);
    const bins = new Float64Array(sh * 2 + 8);
    for (let i = 0; i < xs.length; i += step) bins[Math.round(ys[i] * c - xs[i] * si + sh)]++;
    let sc = 0;
    for (let i = 0; i < bins.length; i++) sc += bins[i] * bins[i];
    return sc;
  };
  let best = 0, bestScore = -1;
  for (let a = -12; a <= 12; a += 1) { const v = score(a); if (v > bestScore) { bestScore = v; best = a; } }
  let fineBest = best;
  for (let a = best - 1; a <= best + 1; a += 0.2) { const v = score(a); if (v > bestScore) { bestScore = v; fineBest = a; } }
  return fineBest;
}

/** Bounding box of the ink region (with padding); null if it doesn't look sane. */
export function inkBounds(g, w, h) {
  const m = textMask(g, w, h);
  const rows = new Uint32Array(h), cols = new Uint32Array(w);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (m[y * w + x]) { rows[y]++; cols[x]++; }
  const rowMin = Math.max(6, w * 0.012), colMin = Math.max(6, h * 0.012);
  let y0 = 0, y1 = h - 1, x0 = 0, x1 = w - 1;
  while (y0 < h && rows[y0] < rowMin) y0++;
  while (y1 > y0 && rows[y1] < rowMin) y1--;
  while (x0 < w && cols[x0] < colMin) x0++;
  while (x1 > x0 && cols[x1] < colMin) x1--;
  const padX = Math.round(w * 0.03), padY = Math.round(h * 0.02);
  x0 = Math.max(0, x0 - padX); x1 = Math.min(w - 1, x1 + padX);
  y0 = Math.max(0, y0 - padY); y1 = Math.min(h - 1, y1 + padY);
  const cw = x1 - x0 + 1, ch = y1 - y0 + 1;
  if (cw < 200 || ch < 200 || (cw * ch) / (w * h) < 0.25) return null;
  return { x: x0, y: y0, w: cw, h: ch };
}

export function cropGray(g, w, h, box) {
  const out = new Uint8ClampedArray(box.w * box.h);
  for (let y = 0; y < box.h; y++) {
    out.set(g.subarray((box.y + y) * w + box.x, (box.y + y) * w + box.x + box.w), y * box.w);
  }
  return out;
}

/** Full pipeline. `rgba` = RGBA pixels. Returns {variants:[{name,gray,w,h}], info}. */
export function preprocessVariants(rgba, w, h) {
  let g = toGray(rgba, w, h);

  // 1. OCR likes ~1500px wide: enlarge small photos, shrink huge ones
  const targetW = w < 1100 ? 1500 : Math.min(w, 2000);
  if (targetW !== w) {
    const nh = Math.round((h * targetW) / w);
    g = resizeGray(g, w, h, targetW, nh);
    w = targetW; h = nh;
  }

  // 2. kill shadows / uneven light
  let flat = flattenBackground(g, w, h);

  // 3. deskew: try the correcting direction, verify by re-measuring, flip if worse
  const skew = estimateSkew(flat, w, h);
  if (Math.abs(skew) >= 0.4) {
    let fixed = rotateGray(flat, w, h, -skew);
    const residual = Math.abs(estimateSkew(fixed, w, h));
    if (residual > Math.abs(skew) * 0.6) {
      const alt = rotateGray(flat, w, h, skew);
      if (Math.abs(estimateSkew(alt, w, h)) < residual) fixed = alt;
      else if (residual > Math.abs(skew)) fixed = flat;      // neither helps: leave it
    }
    flat = fixed;
  }

  // 4. crop to the printed area
  let cw = w, ch = h;
  const box = inkBounds(flat, w, h);
  if (box) { flat = cropGray(flat, w, h, box); cw = box.w; ch = box.h; }

  return {
    variants: [
      { name: "adaptive", gray: adaptiveThreshold(flat, cw, ch, 0.12), w: cw, h: ch },
      { name: "contrast", gray: contrastStretch(flat), w: cw, h: ch },
    ],
    info: { skew: Math.round(skew * 10) / 10, cropped: !!box },
  };
}
