import { useEffect } from "react";

/**
 * Two app-wide, zero-per-component effects:
 *  - cursor spotlight: every .card gets --mx/--my so a soft light follows the mouse
 *  - button ripple: .btn-primary / .btn-ghost emit an expanding ring on click
 * Both are skipped for users who prefer reduced motion.
 */
export function useGlobalFx() {
  useEffect(() => {
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const move = (e) => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const card = e.target.closest?.(".card");
        if (!card) return;
        const r = card.getBoundingClientRect();
        card.style.setProperty("--mx", `${e.clientX - r.left}px`);
        card.style.setProperty("--my", `${e.clientY - r.top}px`);
      });
    };
    const click = (e) => {
      const btn = e.target.closest?.(".btn-primary, .btn-ghost");
      if (!btn) return;
      const r = btn.getBoundingClientRect();
      const size = Math.max(r.width, r.height);
      const dot = document.createElement("span");
      dot.className = "ripple-dot";
      dot.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
      if (getComputedStyle(btn).position === "static") btn.style.position = "relative";
      btn.style.overflow = "hidden";
      btn.appendChild(dot);
      setTimeout(() => dot.remove(), 650);
    };
    document.addEventListener("mousemove", move, { passive: true });
    document.addEventListener("click", click);
    return () => { document.removeEventListener("mousemove", move); document.removeEventListener("click", click); };
  }, []);
}
