import { useEffect, useState } from "react";

/** Returns a counter that bumps whenever an expense is added anywhere. */
export function useExpenseAdded() {
  const [n, setN] = useState(0);
  useEffect(() => {
    const h = () => setN((x) => x + 1);
    window.addEventListener("ss:expense-added", h);
    return () => window.removeEventListener("ss:expense-added", h);
  }, []);
  return n;
}
