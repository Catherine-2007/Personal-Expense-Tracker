import { useEffect, useState } from "react";
import api from "../api";
import { useMoney } from "../useMoney";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import { iconFor } from "../categoryIcons";
import CountUp from "./CountUp";

import { t, tp } from "../i18n";

/** Detects recurring charges from your own history, with the evidence. */
export default function SubscriptionRadar({ refreshKey = 0 }) {
  const bump = useExpenseAdded();
  const { money } = useMoney();
  const [d, setD] = useState(null);
  const [open, setOpen] = useState(null);

  useEffect(() => {
    api.get("/insights/recurring").then((r) => setD(r.data)).catch(() => setD({ items: [], total_monthly: 0, total_annual: 0 }));
  }, [refreshKey, bump]);

  if (!d) return <div className="card skeleton" style={{ height: 190 }} />;

  return (
    <div className="card">
      <div style={{ display: "flex", alignItems: "center", gap: "0.9rem", marginBottom: "0.8rem" }}>
        <div className="radar" aria-hidden><span className="radar-sweep" /><span className="radar-dot" /><span className="radar-dot d2" /><span className="radar-dot d3" /></div>
        <div style={{ flex: 1 }}>
          <span className="eyebrow" style={{ marginBottom: 0 }}>{t("Subscription radar")}</span>
          <div style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>
            {d.items.length ? <>
              {tp(d.items.length, "{n} recurring charge", "{n} recurring charges")} ≈ <b style={{ color: "var(--text-primary)" }}><CountUp value={d.total_monthly} format={(n) => money(n)} /></b>{t("/month")}
              · <b style={{ color: "var(--amber)" }}><CountUp value={d.total_annual} format={(n) => money(n)} /></b>{t("/year")}
            </> : t(
              "Nothing recurring spotted yet — it needs 3+ regular charges from the same merchant."
            )}
          </div>
        </div>
      </div>
      <div className="sub-list">
        {d.items.map((s, i) => {
          const soon = s.days_until_next >= 0 && s.days_until_next <= 7;
          const span = { weekly: 7, fortnightly: 14, monthly: 30, quarterly: 91, yearly: 365 }[s.cadence] || 30;
          const pct = Math.max(0, Math.min(100, ((span - Math.max(s.days_until_next, 0)) / span) * 100));
          return (
            <div key={s.merchant} className="sub-item" style={{ animationDelay: `${i * 70}ms` }}>
              <button className="sub-row" onClick={() => setOpen(open === s.merchant ? null : s.merchant)}>
                <span className="sub-icon">{iconFor(s.category)}</span>
                <span className="sub-main">
                  <b>{s.merchant}</b>
                  <small>{t(s.cadence)} · {money(s.typical_amount)}{s.price_creep_pct ? <span className="pill pill-coral" style={{ marginLeft: 6 }}>▲ {s.price_creep_pct}%</span> : null}</small>
                  <span className="sub-bar"><span style={{ width: `${pct}%`, background: soon ? "var(--amber)" : "var(--teal)" }} /></span>
                </span>
                <span className="sub-next">
                  <b className={soon ? "soon" : ""}>{s.overdue ? t("overdue") : s.days_until_next === 0 ? t("today") : t("in {n}d", { n: s.days_until_next })}</b>
                  <small>{t("{amount}/yr", { amount: money(s.annual_cost) })}</small>
                </span>
              </button>
              {open === s.merchant && (
                <ul className="sub-evidence">
                  {s.evidence.map((e, k) => <li key={k}>{e}</li>)}
                  <li>{t("Confidence {n}%", { n: Math.round(s.confidence * 100) })}</li>
                </ul>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
