import ParticleField from "./ParticleField";
import Icon from "./Icon";
import { t, N_ } from "../i18n";

const POINTS = [
  ["scan", N_("Scan a bill and the entry fills itself")],
  ["insights", N_("Every insight shows the proof behind it")],
  ["family", N_("One app for the whole family")],
  ["globe", N_("12 languages, 9 currencies")],
  ["shield", N_("Private by design - bills are read on your device")],
];

export default function AuthShell({ children }) {
  return (
    <div className="auth-split">
      <ParticleField density={50} />
      <aside className="auth-brand">
        <div className="brand">
          <svg width="34" height="34" viewBox="0 0 26 26" aria-hidden="true">
            <circle cx="13" cy="13" r="11" fill="none" stroke="var(--teal)" strokeWidth="2.5" />
            <circle cx="13" cy="13" r="3.5" fill="var(--teal)" />
          </svg>
          <div className="brand-name big">SpendSense<span>{t("-XAI")}</span></div>
        </div>
        <h1>{t("Know where your money goes - and why.")}</h1>
        <p className="lead">{t("A personal expense tracker that explains itself and helps you build better habits.")}</p>
        <ul className="points">
          {POINTS.map(([ic, text]) => (
            <li key={text}><span className="pt-ico"><Icon name={ic} size={18} /></span>{t(text)}</li>
          ))}
        </ul>
      </aside>
      <main className="auth-panel">{children}</main>
    </div>
  );
}
