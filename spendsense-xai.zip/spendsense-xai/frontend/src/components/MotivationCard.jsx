import { useEffect, useState, useRef } from "react";
import api from "../api";
import ConfettiBurst from "./ConfettiBurst";
import LevelProgress from "./LevelProgress";

import { t } from "../i18n";

export default function MotivationCard({ userId, variant = "compact", mode = "adult" }) {
  const [data, setData] = useState(null);
  const [burst, setBurst] = useState(false);
  const prevEarnedCount = useRef(null);
  const prevLevel = useRef(null);

  useEffect(() => {
    api.get("/motivation").then((r) => {
      const earnedCount = r.data.badges.filter((b) => b.earned).length;
      const storageKey = `ss_badges_seen_${userId}`;
      const levelKey = `ss_level_seen_${userId}`;
      const lastSeen = Number(localStorage.getItem(storageKey) || 0);
      const lastLevel = Number(localStorage.getItem(levelKey) || 1);

      setData(r.data);
      if (earnedCount > lastSeen || r.data.level > lastLevel) {
        setBurst(true);
      }
      localStorage.setItem(storageKey, String(earnedCount));
      localStorage.setItem(levelKey, String(r.data.level));
      prevEarnedCount.current = earnedCount;
      prevLevel.current = r.data.level;
    });
  }, [userId]);

  if (!data) return null;

  const earned = data.badges.filter((b) => b.earned);
  const locked = data.badges.filter((b) => !b.earned);

  if (variant === "big") {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem" }}>
        <LevelProgress
          level={data.level} levelTitle={data.level_title}
          xpIntoLevel={data.xp_into_level} xpForNextLevel={data.xp_for_next_level}
          isMaxLevel={data.is_max_level} mode={mode}
        />
        <div className="card" style={{ position: "relative", overflow: "hidden", textAlign: "center" }}>
          {burst && <ConfettiBurst onDone={() => setBurst(false)} />}
          <div style={{
            width: 84, height: 84, borderRadius: "50%", margin: "0 auto 0.7rem",
            background: "linear-gradient(135deg, var(--amber), var(--coral))",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            color: "#2a1400", fontWeight: 700,
          }}>
            <div style={{ fontSize: "1.8rem", lineHeight: 1 }}>🔥{data.streak_days}</div>
            <div style={{ fontSize: "0.6rem" }}>{t("day streak")}</div>
          </div>
          <p style={{ fontSize: "1rem", fontWeight: 600, color: "var(--text-primary)", margin: "0 0 1rem" }}>{data.message}</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.6rem", justifyContent: "center" }}>
            {earned.map((b) => (
              <div key={b.id} title={b.description} style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: "0.2rem",
                padding: "0.6rem", background: "var(--surface-raised)", borderRadius: 16, width: 84,
              }}>
                <div style={{ fontSize: "1.8rem" }}>{b.icon}</div>
                <div style={{ fontSize: "0.68rem", fontWeight: 600, textAlign: "center" }}>{b.label}</div>
              </div>
            ))}
            {locked.map((b) => (
              <div key={b.id} title={b.description} style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: "0.2rem",
                padding: "0.6rem", background: "var(--surface-raised)", borderRadius: 16, width: 84, opacity: 0.35,
              }}>
                <div style={{ fontSize: "1.8rem" }}>🔒</div>
                <div style={{ fontSize: "0.68rem", fontWeight: 600, textAlign: "center" }}>{b.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem" }}>
      <LevelProgress
        level={data.level} levelTitle={data.level_title}
        xpIntoLevel={data.xp_into_level} xpForNextLevel={data.xp_for_next_level}
        isMaxLevel={data.is_max_level} mode={mode}
      />
      <div className="card" style={{ position: "relative", overflow: "hidden" }}>
        {burst && <ConfettiBurst onDone={() => setBurst(false)} />}
        <span className="eyebrow" style={{ color: "var(--amber)" }}>{t("Keep it up")}</span>
        <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "0.9rem" }}>
          <div style={{
            width: 54, height: 54, borderRadius: "50%",
            background: "linear-gradient(135deg, var(--amber), var(--coral))",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "1.4rem", fontWeight: 700, color: "#2a1400", flexShrink: 0,
          }}>
            {data.streak_days}
          </div>
          <p style={{ margin: 0, fontSize: "0.9rem", color: "var(--text-primary)" }}>{data.message}</p>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
          {earned.map((b) => (
            <span key={b.id} title={b.description} className="pill pill-amber" style={{ fontSize: "0.76rem" }}>
              {b.icon} {b.label}
            </span>
          ))}
          {locked.map((b) => (
            <span key={b.id} title={b.description} className="pill pill-muted" style={{ fontSize: "0.76rem", opacity: 0.6 }}>
              {b.icon} {b.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
