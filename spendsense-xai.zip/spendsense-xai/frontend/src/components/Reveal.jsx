import { useInView } from "../hooks/useMotion";

/** Fades/slides children in when scrolled into view. `delay` in ms. */
export default function Reveal({ children, delay = 0, style, className = "" }) {
  const [ref, seen] = useInView();
  return (
    <div
      ref={ref}
      className={`reveal ${seen ? "reveal-in" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms`, ...style }}
    >
      {children}
    </div>
  );
}
