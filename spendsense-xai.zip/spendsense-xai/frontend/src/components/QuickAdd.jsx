import { useRef, useState } from "react";
import api from "../api";
import { useMoney } from "../useMoney";
import { useLanguage } from "../LanguageContext";
import { iconFor } from "../categoryIcons";

import { formatDate, t } from "../i18n";
import Icon from "./Icon";

const SPEECH_LANG = { en: "en-IN", hi: "hi-IN", ta: "ta-IN", te: "te-IN", bn: "bn-IN", mr: "mr-IN", gu: "gu-IN", kn: "kn-IN", ml: "ml-IN", pa: "pa-IN", es: "es-ES", fr: "fr-FR" };

/**
 * Magic quick-add: type or say "450 swiggy dinner upi yesterday" and get a
 * parsed draft you can save in one tap. Nothing is saved until you confirm.
 */
export default function QuickAdd({ onSaved, onEdit, mode = "adult" }) {
  const { money } = useMoney();
  const { lang } = useLanguage();
  const [text, setText] = useState("");
  const [draft, setDraft] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [listening, setListening] = useState(false);
  const [unusual, setUnusual] = useState(null);
  const recRef = useRef(null);
  const SR = typeof window !== "undefined" ? window.SpeechRecognition || window.webkitSpeechRecognition : null;
  const isKid = mode === "kid";

  async function parse(value = text) {
    if (!value.trim()) return;
    setBusy(true); setError("");
    try {
      const { data } = await api.post("/expenses/quick-parse", { text: value });
      if (!data.ok) { setError(data.reason); setDraft(null); }
      else {
        setDraft(data);
        api.get("/insights/anomaly-check", { params: { amount: data.amount, category: data.category } })
          .then((r) => setUnusual(r.data.unusual ? r.data : null)).catch(() => setUnusual(null));
      }
    } catch { setError(t("Couldn't reach the server.")); }
    finally { setBusy(false); }
  }

  function toggleMic() {
    if (listening) { recRef.current?.stop(); return; }
    const rec = new SR();
    rec.lang = SPEECH_LANG[lang] || "en-IN";
    rec.interimResults = true;
    rec.onresult = (e) => {
      const item = [...e.results].map((r) => r[0].transcript).join(" ");
      setText(item);
      if (e.results[e.results.length - 1].isFinal) parse(item);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recRef.current = rec;
    setListening(true);
    rec.start();
  }

  async function save() {
    setBusy(true);
    try {
      const { data } = await api.post("/expenses", {
        amount: draft.amount, merchant: draft.merchant, category: draft.category,
        payment_method: draft.payment_method || "Other", note: draft.note,
        timestamp: draft.timestamp || undefined, source: "quick",
      });
      onSaved?.(data);
      setText(""); setDraft(null);
    } catch { setError(t("Couldn't save — try again.")); }
    finally { setBusy(false); }
  }

  return (
    <div className="quick-add">
      <div className="quick-row">
        <span className="quick-spark" aria-hidden><Icon name="spark" size={18} /></span>
        <input
          value={text} onChange={(e) => { setText(e.target.value); setDraft(null); setUnusual(null); setError(""); }}
          onKeyDown={(e) => e.key === "Enter" && parse()}
          placeholder={isKid ? t("Try: 50 candy shop") : t("Magic add — try “450 swiggy dinner upi yesterday”")}
          aria-label={t("Quick add an expense in plain words")}
        />
        {SR && (
          <button type="button" className={`quick-mic ${listening ? "live" : ""}`} onClick={toggleMic} aria-label={listening ? t("Stop listening") : t("Speak an expense")}>
            <Icon name="mic" size={17} />
          </button>
        )}
        <button type="button" className="btn-primary" onClick={() => parse()} disabled={busy || !text.trim()}>
          {busy ? "…" : t("Understand")}
        </button>
      </div>
      {error && <div className="quick-error">{error}</div>}
      {draft && (
        <div className="quick-draft">
          <div className="quick-chips">
            <span className="chip chip-big">{money(draft.amount)}</span>
            {draft.merchant && <span className="chip">{draft.merchant}</span>}
            <span className="chip">{iconFor(draft.category)} {t(draft.category)}</span>
            {draft.payment_method && <span className="chip">{t(draft.payment_method)}</span>}
            {draft.timestamp && <span className="chip">{formatDate(draft.timestamp)}</span>}
            {draft.note && <span className="chip chip-muted">{t("“{note}”", { note: draft.note })}</span>}
          </div>
          {unusual && <div className="quick-dupe"><Icon name="search" size={13} /> {unusual.message}</div>}
          {draft.possible_duplicates?.length > 0 && <div className="quick-dupe">{t("⚠️ Similar expense already logged recently.")}</div>}
          <div className="quick-actions">
            <button className="btn-ghost" onClick={() => { onEdit?.(draft); setDraft(null); setText(""); }}>{t("Edit")}</button>
            <button className="btn-primary" disabled={busy} onClick={save}>{isKid ? t("Add it! 🎉") : t("Save")}</button>
          </div>
        </div>
      )}
    </div>
  );
}
