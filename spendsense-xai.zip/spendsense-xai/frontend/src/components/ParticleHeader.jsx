import ParticleField from "./ParticleField";

const MODE_DENSITY = { kid: 50, teen: 34, senior: 14, adult: 22 };

/**
 * Drop-in replacement for the plain PageHeader used across pages — adds a
 * dedicated, mostly-empty particle strip behind the title so the effect is
 * always clearly visible (rather than competing with dense card content),
 * and scales density/motion by the user's platform mode.
 */
export default function ParticleHeader({ title, subtitle, action, mode = "adult", height = 92 }) {
  const density = MODE_DENSITY[mode] ?? MODE_DENSITY.adult;

  return (
    <div style={{ position: "relative", marginBottom: "1.4rem", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
      <div style={{ position: "relative", minHeight: height }}>
        <ParticleField density={density} />
        <div style={{
          position: "relative", zIndex: 1, minHeight: "inherit", paddingTop: "0.8rem",
          display: "flex", flexWrap: "wrap", gap: "0.6rem", justifyContent: "space-between", alignItems: "flex-end", padding: "0.8rem 0.2rem 0",
        }}>
          <div>
            <h1 style={{ fontSize: "1.5rem", margin: 0 }}>{title}</h1>
            {subtitle && <p style={{ maxWidth: 560, margin: "0.2rem 0 0" }}>{subtitle}</p>}
          </div>
          {action}
        </div>
      </div>
    </div>
  );
}
