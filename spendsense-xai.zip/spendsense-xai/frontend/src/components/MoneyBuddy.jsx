import { t } from "../i18n";
/**
 * Money Buddy — a friendly mascot companion for the Playground (kid)
 * dashboard. Its expression and message are driven entirely by the real
 * habit score and streak, not randomness, so it's an emotional read of
 * actual data rather than pure decoration.
 */
export default function MoneyBuddy({ habitScore, streak, message }) {
  const mood = habitScore >= 70 ? "happy" : habitScore >= 45 ? "okay" : "encouraging";

  const faces = {
    happy: { mouth: "M 40 62 Q 55 78 70 62", cheeks: true, eyes: "^^" },
    okay: { mouth: "M 40 65 L 70 65", cheeks: false, eyes: "oo" },
    encouraging: { mouth: "M 40 68 Q 55 58 70 68", cheeks: false, eyes: "oo" },
  };
  const face = faces[mood];

  return (
    <div className="card" style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
      <svg width="90" height="90" viewBox="0 0 110 110" style={{ flexShrink: 0 }}>
        <circle cx="55" cy="55" r="48" fill="var(--amber)" />
        <circle cx="55" cy="55" r="48" fill="none" stroke="var(--coral)" strokeWidth="3" />
        {face.cheeks && (
          <>
            <circle cx="28" cy="60" r="7" fill="var(--coral)" opacity="0.4" />
            <circle cx="82" cy="60" r="7" fill="var(--coral)" opacity="0.4" />
          </>
        )}
        {face.eyes === "^^" ? (
          <>
            <path d="M 28 42 Q 34 36 40 42" stroke="#2a1400" strokeWidth="3" fill="none" strokeLinecap="round" />
            <path d="M 70 42 Q 76 36 82 42" stroke="#2a1400" strokeWidth="3" fill="none" strokeLinecap="round" />
          </>
        ) : (
          <>
            <circle cx="35" cy="44" r="4.5" fill="#2a1400" />
            <circle cx="75" cy="44" r="4.5" fill="#2a1400" />
          </>
        )}
        <path d={face.mouth} stroke="#2a1400" strokeWidth="3.5" fill="none" strokeLinecap="round" />
        {/* coin symbol on belly for theming */}
        <circle cx="55" cy="80" r="9" fill="#fff3d6" stroke="#2a1400" strokeWidth="1.5" />
        <text x="55" y="84" textAnchor="middle" fontSize="10" fontWeight="700" fill="#2a1400">$</text>
      </svg>
      <div>
        <div style={{ fontWeight: 700, fontSize: "0.95rem", marginBottom: "0.2rem" }}>
          {mood === "happy" ? t("Buddy is super happy! 🎉") : mood === "okay" ? t("Buddy is doing okay!") : t("Buddy believes in you!")}
        </div>
        <p style={{ margin: 0, fontSize: "0.85rem" }}>{message}</p>
      </div>
    </div>
  );
}
