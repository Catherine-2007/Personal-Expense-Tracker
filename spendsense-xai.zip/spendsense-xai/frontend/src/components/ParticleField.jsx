import { useEffect, useRef } from "react";

/**
 * A dependency-free animated particle field rendered on a <canvas>.
 * Reads its color from the current theme's --teal CSS variable, so it
 * automatically matches whichever theme is active. Respects
 * prefers-reduced-motion by rendering a single static frame instead of
 * animating.
 *
 * Sizing uses a ResizeObserver on the parent element rather than a single
 * getBoundingClientRect() call at mount time — the one-shot approach is
 * prone to measuring a 0x0 box if the browser hasn't finished layout yet
 * (very common right after mount), which silently produces an empty,
 * "invisible" canvas that never recovers since nothing re-triggers it.
 */
export default function ParticleField({ density = 60, className = "" }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = canvas.parentElement;
    if (!parent) return;
    const ctx = canvas.getContext("2d");
    let raf;
    let particles = [];
    let width = 0, height = 0;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function getAccentColor() {
      const styles = getComputedStyle(document.documentElement);
      return styles.getPropertyValue("--teal").trim() || "#35d0c0";
    }

    function seedParticles() {
      const area = width * height;
      const count = Math.max(6, Math.min(density, Math.floor(area / 18000)));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: (Math.random() * 1.8 + 0.9) * devicePixelRatio,
        vx: (Math.random() - 0.5) * 0.3 * devicePixelRatio,
        vy: (Math.random() - 0.5) * 0.3 * devicePixelRatio,
        alpha: Math.random() * 0.45 + 0.35,
      }));
    }

    function applySize(w, h) {
      if (w <= 0 || h <= 0) return; // ignore bogus pre-layout measurements
      width = canvas.width = Math.round(w * devicePixelRatio);
      height = canvas.height = Math.round(h * devicePixelRatio);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      seedParticles();
    }

    function draw() {
      if (width <= 0 || height <= 0) return;
      const color = getAccentColor();
      ctx.clearRect(0, 0, width, height);

      // connective lines between nearby particles (subtle "neural" motif)
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const a = particles[i], b = particles[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const maxDist = 130 * devicePixelRatio;
          if (dist < maxDist) {
            ctx.strokeStyle = color;
            ctx.globalAlpha = (1 - dist / maxDist) * 0.18;
            ctx.lineWidth = 0.7 * devicePixelRatio;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      for (const p of particles) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();

        if (!reduceMotion) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > width) p.vx *= -1;
          if (p.y < 0 || p.y > height) p.vy *= -1;
        }
      }
      ctx.globalAlpha = 1;
    }

    function loop() {
      draw();
      if (!reduceMotion) raf = requestAnimationFrame(loop);
    }

    // ResizeObserver fires once immediately upon observing (with the
    // element's current size) AND on every subsequent size change, so this
    // single subscription correctly handles first paint, layout settling,
    // window resizes, and sidebar/content reflows.
    const resizeObserver = new ResizeObserver((entries) => {
      const entry = entries[0];
      const { width: w, height: h } = entry.contentRect;
      const hadNoSize = width === 0 || height === 0;
      applySize(w, h);
      if (hadNoSize && !reduceMotion && !raf) {
        loop();
      } else if (reduceMotion) {
        draw();
      }
    });
    resizeObserver.observe(parent);

    if (!reduceMotion) loop();

    const observer = new MutationObserver(() => { if (reduceMotion) draw(); });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });

    return () => {
      cancelAnimationFrame(raf);
      resizeObserver.disconnect();
      observer.disconnect();
    };
  }, [density]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={className}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}
    />
  );
}
