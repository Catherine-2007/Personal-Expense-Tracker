import { useEffect, useState } from "react";
import api from "../api";
import { useMoney } from "../useMoney";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import CountUp from "./CountUp";

import { formatDate, t, tn, tx } from "../i18n";

/* ---------------------------------------------------------------- round-up jar */

export function RoundUpCard() {
  const { money } = useMoney();
  const bump = useExpenseAdded();
  const [step, setStep] = useState(10);
  const [d, setD] = useState(null);
  useEffect(() => { api.get("/insights/roundup", { params: { step } }).then((r) => setD(r.data)).catch(() => setD({ available: false })); }, [step, bump]);

  if (!d) return <div className="card skeleton" style={{ height: 230 }} />;
  if (!d.available) return <div className="card"><span className="eyebrow">{t("Spare-change jar")}</span><p style={{ margin: 0 }}>{d.reason}</p></div>;

  const fill = Math.min(1, d.total_spare / Math.max(d.projected_year, 1) * 3.2);
  const maxW = Math.max(...d.weekly.map((w) => w.amount), 1);
  return (
    <div className="card jar-card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: ".4rem" }}>
        <span className="eyebrow" style={{ marginBottom: 0 }}>{t("Spare-change jar")}</span>
        <div className="seg" role="group" aria-label={t("Round up to")}>
          {[5, 10, 50, 100].map((s) => (
            <button key={s} className={step === s ? "on" : ""} onClick={() => setStep(s)}>↑{s}</button>
          ))}
        </div>
      </div>
      <div className="jar-body">
        <div className="jar" aria-hidden>
          <div className="jar-lid" />
          <div className="jar-glass">
            <div className="jar-fill" style={{ height: `${Math.max(8, fill * 100)}%` }}><span className="jar-wave" /></div>
            {[0, 1, 2, 3].map((i) => <span key={i} className="coin" style={{ left: `${18 + i * 20}%`, animationDelay: `${i * 0.9}s` }}>🪙</span>)}
          </div>
        </div>
        <div>
          <div className="jar-big"><CountUp value={d.total_spare} format={(n) => money(n)} /></div>
          <div className="jar-sub">{t("would be saved from your last {days} days by rounding each purchase up to the next {step}", { days: d.days, step })}</div>
          <div className="jar-year">{tn("≈ {amount} a year, without noticing", { amount: <b><CountUp value={d.projected_year} format={(n) => money(n)} /></b> })}</div>
        </div>
      </div>
      <div className="jar-spark" aria-hidden>
        {d.weekly.map((w, i) => <span key={w.week} title={`${w.week}: ${money(w.amount)}`} style={{ height: `${Math.max(8, (w.amount / maxW) * 100)}%`, animationDelay: `${i * 50}ms` }} />)}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- forecast */

export function ForecastCard() {
  const { money } = useMoney();
  const bump = useExpenseAdded();
  const [d, setD] = useState(null);
  const [hover, setHover] = useState(null);
  useEffect(() => { api.get("/insights/forecast").then((r) => setD(r.data)).catch(() => setD({ available: false })); }, [bump]);

  if (!d) return <div className="card skeleton" style={{ height: 250 }} />;
  if (!d.available) return <div className="card"><span className="eyebrow">{t("14-day forecast")}</span><p style={{ margin: 0 }}>{d.reason}</p></div>;

  const W = 560, H = 160, pad = 10;
  const max = Math.max(...d.days.map((x) => x.cumulative), 1);
  const x = (i) => pad + (i / (d.days.length - 1)) * (W - pad * 2);
  const y = (v) => H - pad - (v / max) * (H - pad * 2);
  const line = d.days.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.cumulative).toFixed(1)}`).join(" ");
  const area = `${line} L${x(d.days.length - 1)},${H - pad} L${x(0)},${H - pad} Z`;
  const color = { safe: "var(--teal)", tight: "var(--amber)", over: "var(--coral)", unknown: "var(--violet)" }[d.verdict];
  const label = { safe: t("On track"), tight: t("Tight"), over: t("Over budget"), unknown: t("Forecast") }[d.verdict];
  const h = hover != null ? d.days[hover] : null;

  return (
    <div className="card forecast-card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: ".6rem", flexWrap: "wrap" }}>
        <div>
          <span className="eyebrow">{t("Next 14 days — forecast")}</span>
          <div className="forecast-total" style={{ color }}><CountUp value={d.total_expected} format={(n) => money(n)} /></div>
          <div className="forecast-note">{d.note}</div>
        </div>
        <span className="pill" style={{ background: "transparent", border: `1px solid ${color}`, color }}>{label}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="forecast-svg" onMouseLeave={() => setHover(null)}>
        <defs>
          <linearGradient id="fc-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity=".35" /><stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#fc-grad)" className="forecast-area" />
        <path d={line} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" pathLength="1" className="forecast-line" />
        {d.days.map((p, i) => p.bills > 0 && (
          <g key={p.date}><circle cx={x(i)} cy={y(p.cumulative)} r="6" fill="var(--surface)" stroke="var(--amber)" strokeWidth="2.5" className="forecast-bill" /><text x={x(i)} y={y(p.cumulative) - 11} textAnchor="middle" fontSize="11" fill="var(--amber)">🧾</text></g>
        ))}
        {d.days.map((p, i) => (
          <rect key={i} x={x(i) - (W / d.days.length) / 2} y="0" width={W / d.days.length} height={H} fill="transparent" onMouseEnter={() => setHover(i)} />
        ))}
        {h && <g><line x1={x(hover)} x2={x(hover)} y1="0" y2={H} stroke="var(--border)" strokeDasharray="4 4" /><circle cx={x(hover)} cy={y(h.cumulative)} r="5" fill={color} /></g>}
      </svg>
      <div className="forecast-foot">
        {h
          ? <>{formatDate(h.date, { weekday: "short", day: "numeric", month: "short" })} · {tx("expect **{amount}**", { amount: money(h.expected) })}{h.bills ? " " + t("(incl. bills {x})", { x: money(h.bills) }) : ""} · {tx("running total **{amount}**", { amount: money(h.cumulative) })}</>
          : <>{t("Built from your own weekday habits")}{d.bills_in_window ? " " + t("plus {x} of recurring bills (🧾)", { x: money(d.bills_in_window) }) : ""}. {t("Hover the line.")}</>}
      </div>
    </div>
  );
}
