import { useEffect, useState } from "react";
import api from "../api";
import { useMoney } from "../useMoney";
import { useExpenseAdded } from "../hooks/useExpenseAdded";

import { N_, formatDate, t, tp } from "../i18n";

const DAY_IDX = [0, 2, 4, 6]; // Mon, Wed, Fri, Sun labels
const dayLabel = (i) => (DAY_IDX.includes(i) ? formatDate(new Date(2024, 0, 1 + i), { weekday: "short" }) : "");

/** GitHub-style calendar of daily spend; cells pop in column by column. */
export default function SpendHeatmap({ weeks = 20, refreshKey = 0, title = N_("Spending heatmap") }) {
  const bump = useExpenseAdded();
  const { money } = useMoney();
  const [d, setD] = useState(null);
  const [hover, setHover] = useState(null);

  useEffect(() => {
    api.get("/insights/heatmap", { params: { weeks } }).then((r) => setD(r.data)).catch(() => setD(null));
  }, [weeks, refreshKey, bump]);

  if (!d) return <div className="card skeleton" style={{ height: 190 }} />;

  const cols = [];
  d.days.forEach((day) => {
    const wk = Math.floor((new Date(day.date) - new Date(d.start)) / (7 * 86400000));
    (cols[wk] ||= Array(7).fill(null))[day.weekday] = day;
  });

  const fmt = (x) => formatDate(x.date, { weekday: "short", day: "numeric", month: "short" });

  return (
    <div className="card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: "0.4rem" }}>
        <span className="eyebrow">{t(title)}</span>
        <span className="heat-hover">
          {hover ? <>{fmt(hover)} · <b>{hover.total ? money(hover.total) : t("no spending")}</b>{hover.count ? " · " + tp(hover.count, "{n} purchase", "{n} purchases") : ""}</> : t("Hover a day")}
        </span>
      </div>
      <div className="heat-wrap">
        <div className="heat-labels">{[0,1,2,3,4,5,6].map((i) => <span key={i}>{dayLabel(i)}</span>)}</div>
        <div className="heat-grid">
          {cols.map((col, ci) => (
            <div key={ci} className="heat-col">
              {col.map((day, ri) => day ? (
                <div
                  key={ri}
                  className={`heat-cell lvl-${day.level}`}
                  style={{ animationDelay: `${ci * 28 + ri * 8}ms` }}
                  onMouseEnter={() => setHover(day)} onMouseLeave={() => setHover(null)}
                  onFocus={() => setHover(day)} tabIndex={-1}
                  aria-label={`${fmt(day)}: ${day.total ? money(day.total) : t("no spending")}`}
                />
              ) : <div key={ri} className="heat-cell empty" />)}
            </div>
          ))}
        </div>
      </div>
      <div className="heat-foot">
        <span>{tp(d.no_spend_days, "{n} no-spend day", "{n} no-spend days")}{d.priciest_weekday ? " · " + t("{weekday}s cost you the most", { weekday: formatDate(new Date(2024, 0, 1 + ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"].indexOf(d.priciest_weekday)), { weekday: "long" }) }) : ""}</span>
        <span className="heat-legend">{t("Less")} {[0, 1, 2, 3, 4].map((l) => <i key={l} className={`heat-cell lvl-${l}`} />)} {t("More")}</span>
      </div>
    </div>
  );
}
