import { t } from "../i18n";
import CountUp from "./CountUp";
import { useTilt } from "../hooks/useMotion";

export function PageHeader({ title, subtitle, action }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "1.4rem" }}>
      <div>
        <h1 style={{ fontSize: "1.5rem" }}>{title}</h1>
        {subtitle && <p style={{ maxWidth: 560, margin: 0 }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

/**
 * `value` is what to show. Pass `numeric` (+ optional `format`) to make the
 * number count up from zero; the card also tilts toward the cursor.
 */
export function StatCard({ label, value, numeric, format, delta, highlight }) {
  const tilt = useTilt(6);
  return (
    <div className="card tilt" {...tilt} style={{ padding: "1rem 1.2rem" }}>
      <div style={{ fontSize: "0.74rem", color: "var(--text-muted)", marginBottom: "0.3rem" }}>{label}</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: "1.3rem", fontWeight: 600, color: highlight ? "var(--teal)" : "var(--text-primary)" }}>
        {typeof numeric === "number" ? <CountUp value={numeric} format={format} /> : value}
      </div>
      {typeof delta === "number" && (
        <div style={{ fontSize: "0.74rem", color: delta > 0 ? "var(--coral)" : "var(--teal)", marginTop: "0.2rem" }}>
          {delta > 0 ? "▲" : "▼"} {t("{pct}% vs baseline", { pct: Math.abs(delta) })}
        </div>
      )}
    </div>
  );
}

export const tooltipStyle = {
  background: "var(--surface-raised)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: "0.8rem",
  color: "var(--text-primary)",
};

export const CATEGORY_COLORS = ["#35d0c0", "#f5a623", "#9b8cff", "#ff6b6b", "#4d8bff", "#e0c341", "#6fdc8c"];
