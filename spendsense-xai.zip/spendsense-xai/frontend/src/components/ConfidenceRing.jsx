import { useEffect, useState } from "react";

export default function ConfidenceRing({ value, size = 64, label, color = "var(--teal)" }) {
  const target = Math.max(0, Math.min(1, value));
  const [pct, setPct] = useState(0);
  useEffect(() => { const id = requestAnimationFrame(() => setPct(target)); return () => cancelAnimationFrame(id); }, [target]);
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - pct);

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "0.7rem" }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none" stroke="var(--border)" strokeWidth="6"
        />
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none" stroke={color} strokeWidth="6"
          strokeDasharray={c} strokeDashoffset={offset}
          strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)" }}
        />
        <text
          x="50%" y="52%" textAnchor="middle" dominantBaseline="middle"
          fontFamily="JetBrains Mono, monospace" fontSize={size * 0.24}
          fill="var(--text-primary)" fontWeight="600"
        >
          {Math.round(target * 100)}%
        </text>
      </svg>
      {label && (
        <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", maxWidth: 140 }}>
          {label}
        </div>
      )}
    </div>
  );
}
