import { useState } from "react";
import { N_ } from "../i18n";
import { useLanguage } from "../LanguageContext";

const STEPS_BY_MODE = {
  adult: [
    { icon: "◆", title: N_("Your Dashboard"), body: N_("Total spend, your habit score, and your top spending triggers at a glance.") },
    { icon: "＋", title: N_("Log expenses"), body: N_("Add what you spend on the Expenses page. The category is auto-detected.") },
    { icon: "◈", title: N_("Discover triggers"), body: N_("Refresh triggers on the Insights page — the app mines context/category patterns with statistical confidence and evidence.") },
    { icon: "⟳", title: N_("Get a nudge"), body: N_("Request an intervention from a trigger. It's A/B-tested and its effectiveness is measured against your real spend.") },
    { icon: "▤", title: N_("Check your report"), body: N_("The Monthly Report compares this month to your own history and flags goal risk.") },
  ],
  teen: [
    { icon: "◆", title: N_("Welcome to your Dashboard!"), body: N_("This shows you everything at a glance — how much you've spent and how you're doing.") },
    { icon: "＋", title: N_("Add what you spend"), body: N_("Tap Expenses, type in what you bought, and the app figures out the category for you.") },
    { icon: "◈", title: N_("Find your patterns"), body: N_("The app looks for habits, like spending more at certain times. Tap Insights to see what it finds, with proof for each one.") },
    { icon: "⟳", title: N_("Try a helpful tip"), body: N_("The app can suggest a small change to try. It'll tell you if it actually helped.") },
    { icon: "▤", title: N_("See your progress"), body: N_("Your Monthly Report shows how you're doing compared to your own past months — never compared to anyone else.") },
  ],
  kid: [
    { icon: "🏠", title: N_("Welcome!"), body: N_("This is your money home base. It shows what you've spent and how you're doing.") },
    { icon: "➕", title: N_("Add what you spend"), body: N_("Tap Expenses and tell the app what you bought. It figures out the category by itself — like magic!") },
    { icon: "🔍", title: N_("Spot your habits"), body: N_("Tap Triggers to see patterns the app found in your spending, with the reasons why.") },
    { icon: "💡", title: N_("Try a tip"), body: N_("The app can suggest a fun little change to try, and it'll cheer you on if it works!") },
    { icon: "🏆", title: N_("Earn badges"), body: N_("Keep logging your spending to build a streak and unlock badges on your Dashboard!") },
  ],
};

export default function OnboardingTour({ onClose, mode = "adult" }) {
  const { t } = useLanguage();
  const [step, setStep] = useState(0);
  const steps = STEPS_BY_MODE[mode] || STEPS_BY_MODE.adult;
  const isLast = step === steps.length - 1;
  const s = steps[step];

  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: "fixed", inset: 0, zIndex: 100,
        background: "rgba(5, 8, 16, 0.6)", backdropFilter: "blur(3px)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: "1.5rem",
      }}
    >
      <div className="card" style={{ width: 420, textAlign: "center" }}>
        <div style={{ fontSize: "2.2rem", marginBottom: "0.6rem" }}>{s.icon}</div>
        {step === 0 && <span className="eyebrow">{t("onboarding.title")}</span>}
        <h2 style={{ fontSize: "1.2rem" }}>{t(s.title)}</h2>
        <p>{t(s.body)}</p>

        <div style={{ display: "flex", justifyContent: "center", gap: "0.35rem", margin: "1rem 0" }}>
          {steps.map((_, i) => (
            <span
              key={i}
              style={{
                width: 7, height: 7, borderRadius: 4,
                background: i === step ? "var(--teal)" : "var(--border)",
              }}
            />
          ))}
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", gap: "0.6rem" }}>
          <button className="btn-ghost" onClick={onClose}>{t("common.skip")}</button>
          <div style={{ display: "flex", gap: "0.5rem" }}>
            {step > 0 && (
              <button className="btn-ghost" onClick={() => setStep((s2) => s2 - 1)}>{t("common.back")}</button>
            )}
            <button
              className="btn-primary"
              onClick={() => (isLast ? onClose() : setStep((s2) => s2 + 1))}
            >
              {isLast ? t("common.finish") : t("common.next")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
