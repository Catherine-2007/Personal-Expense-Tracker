import { Component } from "react";
import { t } from "../i18n";

/** Shows a friendly recovery screen instead of a blank page if something unexpected breaks. */
export default class ErrorBoundary extends Component {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(err) { console.error("UI error:", err); }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="fatal">
        <div className="card">
          <h2>{t("Something went wrong")}</h2>
          <p>{t("Your data is safe. Reload the page to continue.")}</p>
          <button className="btn-primary" onClick={() => window.location.assign("/")}>{t("Reload")}</button>
        </div>
      </div>
    );
  }
}
