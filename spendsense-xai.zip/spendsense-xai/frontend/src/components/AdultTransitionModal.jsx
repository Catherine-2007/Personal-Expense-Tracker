import { useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";

import { t } from "../i18n";

export default function AdultTransitionModal({ onClose }) {
  const { user, updateProfile } = useAuth();
  const [stage, setStage] = useState("ask"); // ask -> guide
  const [guide, setGuide] = useState([]);
  const [loading, setLoading] = useState(false);

  async function handleSwitch() {
    setLoading(true);
    try {
      const { data } = await api.post("/auth/transition-to-adult");
      // sync the local user object (theme/platform_mode) without a second round trip
      await updateProfile({});
      setGuide(data.guide);
      setStage("guide");
    } finally {
      setLoading(false);
    }
  }

  async function handleNotNow() {
    setLoading(true);
    try {
      await api.post("/auth/dismiss-adult-prompt");
    } finally {
      setLoading(false);
      onClose();
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: "fixed", inset: 0, zIndex: 110,
        background: "rgba(5, 8, 16, 0.65)", backdropFilter: "blur(3px)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: "1.5rem",
      }}
    >
      <div className="card" style={{ width: 440, textAlign: "center" }}>
        {stage === "ask" ? (
          <>
            <div style={{ fontSize: "2.4rem", marginBottom: "0.5rem" }}>🎉</div>
            <span className="eyebrow">{t("Happy birthday, {name}!", { name: user?.name?.split(" ")[0] })}</span>
            <h2 style={{ fontSize: "1.15rem" }}>{t("You just turned 18")}</h2>
            <p>{t(
              "You've been using the simplified experience. Now that you're 18, you can switch to the full, unrestricted SpendSense-XAI — every theme, every currency, and full statistical detail on every trigger and intervention. Your data stays exactly as it is."
            )}</p>
            <div style={{ display: "flex", justifyContent: "center", gap: "0.6rem", marginTop: "1.2rem" }}>
              <button className="btn-ghost" onClick={handleNotNow} disabled={loading}>{t("Not now")}</button>
              <button className="btn-primary" onClick={handleSwitch} disabled={loading}>
                {loading ? t("Switching…") : t("Switch me to Adult mode")}
              </button>
            </div>
          </>
        ) : (
          <>
            <div style={{ fontSize: "2.2rem", marginBottom: "0.5rem" }}>✨</div>
            <span className="eyebrow" style={{ color: "var(--teal)" }}>{t("You're all set")}</span>
            <h2 style={{ fontSize: "1.15rem" }}>{t("Here's what's new")}</h2>
            <ul style={{ textAlign: "left", fontSize: "0.86rem", margin: "0.8rem 0", paddingLeft: "1.2rem" }}>
              {guide.map((g, i) => <li key={i} style={{ marginBottom: "0.4rem" }}>{g}</li>)}
            </ul>
            <button className="btn-primary" onClick={onClose} style={{ marginTop: "0.6rem" }}>{t("Continue")}</button>
          </>
        )}
      </div>
    </div>
  );
}
