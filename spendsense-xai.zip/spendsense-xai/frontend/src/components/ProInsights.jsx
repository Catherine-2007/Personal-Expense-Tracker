import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";

import { t } from "../i18n";

/**
 * Extra power-user stats for the adult tier, computed purely from numbers
 * already in the monthly report plus the current date — no separate API
 * call, no invented figures.
 */
export default function ProInsights({ report, currency }) {
  const { money } = useMoney();
  const now = new Date();
  const daysElapsed = now.getDate();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();

  const dailyAvg = daysElapsed > 0 ? report.total_spend / daysElapsed : 0;
  const projectedMonthEnd = dailyAvg * daysInMonth;
  const paceVsBaseline = report.self_comparison.personal_baseline_avg > 0
    ? ((projectedMonthEnd - report.self_comparison.personal_baseline_avg) / report.self_comparison.personal_baseline_avg) * 100
    : 0;

  return (
    <div className="card">
      <span className="eyebrow" style={{ color: "var(--violet)" }}>{t("Pro insights")}</span>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.8rem", marginTop: "0.5rem" }}>
        <div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{t("Daily average")}</div>
          <div className="mono" style={{ fontSize: "1.05rem", fontWeight: 600 }}>{money(dailyAvg)}</div>
        </div>
        <div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{t("Projected month-end")}</div>
          <div className="mono" style={{ fontSize: "1.05rem", fontWeight: 600 }}>{money(projectedMonthEnd)}</div>
        </div>
        <div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{t("Pace vs. baseline")}</div>
          <div className="mono" style={{ fontSize: "1.05rem", fontWeight: 600, color: paceVsBaseline > 0 ? "var(--coral)" : "var(--teal)" }}>
            {paceVsBaseline > 0 ? "+" : ""}{paceVsBaseline.toFixed(0)}%
          </div>
        </div>
      </div>
      <p style={{ fontSize: "0.76rem", marginTop: "0.6rem", marginBottom: 0 }}>
        {t("Based on {a} of {b} days elapsed this month, extrapolated at your current daily rate.", { a: daysElapsed, b: daysInMonth })}
      </p>
    </div>
  );
}
