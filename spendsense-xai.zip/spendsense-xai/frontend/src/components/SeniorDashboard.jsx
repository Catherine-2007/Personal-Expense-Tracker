import MotivationCard from "./MotivationCard";
import ParticleField from "./ParticleField";
import SafeToSpend from "./SafeToSpend";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";

import { contextLabel, t, tn } from "../i18n";

export default function SeniorDashboard({ report, triggers, currency, userId, title, goals }) {
  const { money } = useMoney();
  const entries = Object.entries(report.by_category).sort((a, b) => b[1] - a[1]);
  const topCategory = entries[0];
  const activeGoal = goals?.[0];
  const spentLess = report.self_comparison.pct_change_vs_baseline < 0;
  const changeAbs = Math.abs(report.self_comparison.pct_change_vs_baseline);

  return (
    <div style={{ maxWidth: 720 }}>
      <div style={{ position: "relative", marginBottom: "1.6rem", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
        <div style={{ position: "relative", minHeight: 90 }}>
          <ParticleField density={14} />
          <div style={{ position: "relative", zIndex: 1, minHeight: "inherit", paddingTop: "0.8rem", display: "flex", alignItems: "center", padding: "0 0.3rem" }}>
            <div>
              <h1 style={{ fontSize: "1.7rem", margin: 0 }}>{title}</h1>
              <p style={{ margin: 0, fontSize: "1rem" }}>{report.period}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="card" style={{ marginBottom: "1.2rem" }}>
        <p style={{ fontSize: "1.15rem", color: "var(--text-primary)", margin: 0, lineHeight: 1.6 }}>
          {tn("You spent {amount} this month, which is {change} than your usual month. Your financial habit score is {score}.", {
            amount: <strong>{money(report.total_spend)}</strong>,
            change: <strong style={{ color: spentLess ? "var(--teal)" : "var(--coral)" }}>
              {spentLess ? t("{pct}% less", { pct: changeAbs.toFixed(0) }) : t("{pct}% more", { pct: changeAbs.toFixed(0) })}
            </strong>,
            score: <strong>{t("{n} out of 100", { n: report.financial_habit_score })}</strong>,
          })}
        </p>
      </div>

      {topCategory && (
        <div className="card" style={{ marginBottom: "1.2rem" }}>
          <span className="eyebrow">{t("Biggest expense category")}</span>
          <div style={{ display: "flex", alignItems: "center", gap: "0.9rem", marginTop: "0.4rem" }}>
            <span style={{ fontSize: "2.2rem" }}>{iconFor(topCategory[0])}</span>
            <div>
              <div style={{ fontSize: "1.2rem", fontWeight: 600 }}>{t(topCategory[0])}</div>
              <div style={{ fontSize: "1.05rem", color: "var(--text-muted)" }}>
                {money(topCategory[1])} {t("this month")}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeGoal && (
        <div className="card" style={{ marginBottom: "1.2rem" }}>
          <span className="eyebrow">{t("Savings goal: {title}", { title: activeGoal.title })}</span>
          <p style={{ fontSize: "1.05rem", margin: "0.4rem 0 0.7rem" }}>
            {t("{saved} saved of {target} goal", { saved: money(activeGoal.saved_amount), target: money(activeGoal.target_amount) })}
          </p>
          <div style={{ height: 16, borderRadius: 8, background: "var(--surface-raised)", overflow: "hidden" }}>
            <div style={{
              width: `${Math.min(100, (activeGoal.saved_amount / activeGoal.target_amount) * 100)}%`,
              height: "100%", background: "var(--teal)",
            }} />
          </div>
        </div>
      )}

      {triggers.length > 0 && (
        <div className="card" style={{ marginBottom: "1.2rem" }}>
          <span className="eyebrow">{t("A pattern the app noticed")}</span>
          <p style={{ fontSize: "1.05rem", margin: "0.4rem 0 0" }}>
            {iconFor(triggers[0].category_affected)} {tn("You tend to spend more on {category} during {context} times. This shows up in {pct}% of similar situations in your history.", {
              category: <strong>{t(triggers[0].category_affected)}</strong>,
              context: contextLabel(triggers[0].context_key, " + "),
              pct: Math.round(triggers[0].confidence * 100),
            })}
          </p>
        </div>
      )}

      <div style={{ marginBottom: "1rem" }}><SafeToSpend mode="senior" /></div>

      <MotivationCard userId={userId} variant="compact" mode="senior" />
    </div>
  );
}
