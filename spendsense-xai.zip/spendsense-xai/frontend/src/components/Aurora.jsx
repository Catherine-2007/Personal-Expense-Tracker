/** Slow-drifting blurred colour blobs behind the whole app (pure CSS, theme-aware). */
export default function Aurora() {
  return (
    <div className="aurora" aria-hidden>
      <span className="aurora-blob a1" />
      <span className="aurora-blob a2" />
      <span className="aurora-blob a3" />
    </div>
  );
}
