import { useEffect, useState } from "react";
import api from "../api";
import { useMoney } from "../useMoney";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import { iconFor } from "../categoryIcons";

import { t } from "../i18n";

/** Purchases far above your own norm for that category -- only shown if any exist. */
export default function UnusualSpends() {
  const { money } = useMoney();
  const bump = useExpenseAdded();
  const [items, setItems] = useState([]);

  useEffect(() => {
    api.get("/insights/anomalies").then((r) => setItems(r.data.items || [])).catch(() => setItems([]));
  }, [bump]);

  if (!items.length) return null;
  return (
    <div className="card" style={{ borderColor: "var(--amber)", marginBottom: "1rem" }}>
      <span className="eyebrow">{t("Worth a second look")}</span>
      {items.map((e, i) => (
        <div key={e.id} className="unusual-row" style={{ animationDelay: `${i * 70}ms` }}>
          <span style={{ fontSize: "1.3rem" }}>{iconFor(e.category)}</span>
          <div style={{ flex: 1 }}>
            <b>{e.merchant || t(e.category)}</b> · {money(e.amount)}
            <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>{e.message}</div>
          </div>
          <span className="pill pill-coral">{e.ratio}×</span>
        </div>
      ))}
    </div>
  );
}
