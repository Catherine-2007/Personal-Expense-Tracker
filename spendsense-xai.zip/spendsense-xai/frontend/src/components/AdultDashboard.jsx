import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import ConfidenceRing from "./ConfidenceRing";
import MotivationCard from "./MotivationCard";
import ProInsights from "./ProInsights";
import ParticleField from "./ParticleField";
import SafeToSpend from "./SafeToSpend";
import SpendHeatmap from "./SpendHeatmap";
import SubscriptionRadar from "./SubscriptionRadar";
import Reveal from "./Reveal";
import { RoundUpCard, ForecastCard } from "./InsightLab";
import PersonaCard from "./PersonaCard";
import UnusualSpends from "./UnusualSpends";
import { PageHeader, StatCard, tooltipStyle, CATEGORY_COLORS } from "./DashboardUI";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";

import { contextLabel, t } from "../i18n";

export default function AdultDashboard({ report, triggers, currency, userId, title }) {
  const { money } = useMoney();
  const pieData = Object.entries(report.by_category).map(([name, value]) => ({ name, label: t(name), value }));

  return (
    <div>
      <div style={{ position: "relative", marginBottom: "1.4rem", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
        <div style={{ position: "relative", minHeight: 92 }}>
          <ParticleField density={26} />
          <div style={{ position: "relative", zIndex: 1, minHeight: 92, display: "flex", alignItems: "flex-end", padding: "0.8rem 0.2rem 0" }}>
            <PageHeader
              title={title}
              subtitle={`${report.period} · ${t("everything below is computed from your own history, not benchmarks against other people")}`}
            />
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1rem", marginBottom: "1rem" }}>
        <StatCard label={t("Total spend")} numeric={report.total_spend} format={(n) => money(n)} value={money(report.total_spend)}
          delta={report.self_comparison.pct_change_vs_baseline} />
        <StatCard label={t("Vs your 3-mo baseline")} numeric={report.self_comparison.personal_baseline_avg} format={(n) => money(n)} value={money(report.self_comparison.personal_baseline_avg)} />
        <StatCard label={t("Financial habit score")} numeric={report.financial_habit_score} format={(n) => `${Math.round(n)}/100`} value={`${report.financial_habit_score}/100`} highlight />
        <StatCard label={t("Active triggers")} numeric={triggers.length} format={(n) => Math.round(n)} value={triggers.length} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: "1rem", marginBottom: "1rem" }}>
        <SafeToSpend mode="adult" />
        <SubscriptionRadar />
      </div>

      <UnusualSpends />

      <Reveal style={{ marginBottom: "1rem" }}>
        <SpendHeatmap weeks={22} />
      </Reveal>

      <Reveal style={{ marginBottom: "1rem" }}>
        <PersonaCard />
      </Reveal>

      <Reveal style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
        <ForecastCard />
        <RoundUpCard />
      </Reveal>

      <div style={{ marginBottom: "1rem" }}>
        <ProInsights report={report} currency={currency} />
      </div>

      <div style={{ marginBottom: "1rem" }}>
        <MotivationCard userId={userId} variant="compact" mode="adult" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
        <div className="card">
          <span className="eyebrow">{t("Spending by category")}</span>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="label" innerRadius={55} outerRadius={85} paddingAngle={2}>
                {pieData.map((_, i) => <Cell key={i} fill={CATEGORY_COLORS[i % CATEGORY_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => money(v)} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.6rem", marginTop: "0.6rem" }}>
            {pieData.map((d, i) => (
              <div key={d.name} style={{ display: "flex", alignItems: "center", gap: "0.35rem", fontSize: "0.76rem", color: "var(--text-muted)" }}>
                <span style={{ width: 8, height: 8, borderRadius: 4, background: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} />
                {t(d.name)} · {report.by_category_pct[d.name]}%
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <span className="eyebrow">{t("Monthly story (AI)")}</span>
          <p style={{ color: "var(--text-primary)", fontSize: "0.92rem" }}>{report.monthly_story}</p>
          <div style={{ marginTop: "1rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            {report.what_changed.slice(0, 4).map((c) => (
              <div key={c.category} style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", borderBottom: "1px solid var(--border-soft)", paddingBottom: "0.4rem" }}>
                <span>{t(c.category)}</span>
                <span className={c.direction === "increased" ? "pill pill-coral" : "pill pill-teal"}>
                  {c.direction === "increased" ? "▲" : "▼"} {money(Math.abs(c.change))}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <span className="eyebrow">{t("Top spending triggers")}</span>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "0.8rem", marginTop: "0.6rem" }}>
          {triggers.length === 0 && (
            <p>{t(
              "No triggers discovered yet — add a few expenses and refresh triggers from the Insights page."
            )}</p>
          )}
          {triggers.slice(0, 3).map((item) => (
            <div key={item.id} style={{ display: "flex", alignItems: "center", gap: "0.8rem", padding: "0.8rem", background: "var(--surface-raised)", borderRadius: 12 }}>
              <ConfidenceRing value={item.confidence} size={54} />
              <div style={{ fontSize: "0.82rem" }}>
                <div style={{ fontWeight: 600 }}>{t(item.category_affected)}</div>
                <div style={{ color: "var(--text-muted)" }}>{contextLabel(item.context_key)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
