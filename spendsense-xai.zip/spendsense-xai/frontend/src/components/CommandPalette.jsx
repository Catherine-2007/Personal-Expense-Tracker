import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { useLanguage } from "../LanguageContext";
import Icon from "./Icon";

/** Ctrl/⌘ + K quick launcher: jump to any page or start common actions without hunting through menus. */
export default function CommandPalette({ open, onClose, onScan }) {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const inputRef = useRef(null);

  const items = useMemo(() => {
    const go = (to) => () => navigate(to);
    return [
      { group: t("Quick actions"), label: user?.platform_mode === "kid" ? t("Snap a receipt") : t("Scan a bill"), icon: "scan", run: onScan },
      { group: t("Quick actions"), label: t("Add an expense"), icon: "plus", run: go("/expenses") },
      { group: t("Quick actions"), label: t("Add money"), icon: "goals", run: go("/goals") },
      { group: t("Pages"), label: t("Dashboard"), icon: "dashboard", run: go("/") },
      { group: t("Pages"), label: t("Expenses"), icon: "expenses", run: go("/expenses") },
      { group: t("Pages"), label: t("Goals"), icon: "goals", run: go("/goals") },
      { group: t("Pages"), label: t("Budgets"), icon: "budgets", run: go("/budgets") },
      { group: t("Pages"), label: t("Family"), icon: "family", run: go("/family") },
      { group: t("Pages"), label: t("Triggers & XAI"), icon: "insights", run: go("/insights") },
      { group: t("Pages"), label: t("Interventions"), icon: "interventions", run: go("/interventions") },
      { group: t("Pages"), label: t("Monthly Report"), icon: "report", run: go("/report") },
      { group: t("Pages"), label: t("Feature guide"), icon: "guide", run: go("/guide") },
      { group: t("Pages"), label: t("Settings"), icon: "settings", run: go("/settings") },
    ];
  }, [t, user, navigate, onScan]);

  const shown = items.filter((i) => i.label.toLowerCase().includes(q.trim().toLowerCase()));

  useEffect(() => { if (open) { setQ(""); setIdx(0); setTimeout(() => inputRef.current?.focus(), 30); } }, [open]);
  useEffect(() => { setIdx(0); }, [q]);

  if (!open) return null;
  const choose = (it) => { onClose(); it?.run(); };
  const onKey = (e) => {
    if (e.key === "Escape") onClose();
    else if (e.key === "ArrowDown") { e.preventDefault(); setIdx((i) => Math.min(i + 1, shown.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setIdx((i) => Math.max(i - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); choose(shown[idx]); }
  };

  let lastGroup = null;
  return (
    <div className="modal-backdrop cmdk-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="cmdk card" role="dialog" aria-modal="true" aria-label={t("Search or jump to…")} onKeyDown={onKey}>
        <div className="cmdk-input">
          <Icon name="search" size={18} />
          <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("Search or jump to…")} aria-label={t("Search or jump to…")} />
          <kbd>Esc</kbd>
        </div>
        <div className="cmdk-list" role="listbox">
          {shown.length === 0 && <div className="cmdk-empty">{t("No matches")}</div>}
          {shown.map((it, i) => {
            const head = it.group !== lastGroup ? <div className="cmdk-group">{it.group}</div> : null;
            lastGroup = it.group;
            return (
              <div key={it.group + it.label}>
                {head}
                <button role="option" aria-selected={i === idx} className={`cmdk-item${i === idx ? " on" : ""}`}
                  onMouseEnter={() => setIdx(i)} onClick={() => choose(it)}>
                  <Icon name={it.icon} size={17} /> <span>{it.label}</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
