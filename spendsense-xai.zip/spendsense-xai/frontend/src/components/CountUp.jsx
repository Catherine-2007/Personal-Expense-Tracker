import { useCountUp } from "../hooks/useMotion";

/** <CountUp value={1234.5} format={(n) => money(n)} /> */
export default function CountUp({ value, format = (n) => Math.round(n).toLocaleString(), duration }) {
  const v = useCountUp(value, duration);
  return <>{format(v)}</>;
}
