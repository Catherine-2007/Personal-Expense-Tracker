import { useCallback, useEffect, useRef, useState } from "react";
import api from "../api";
import { useAuth } from "../AuthContext";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";
import { preprocessVariants } from "../scanner/imageProc";
import ConfettiBurst from "./ConfettiBurst";

import { N_, plain, t, tn, tp } from "../i18n";
import Icon from "./Icon";

const CATEGORIES = [N_("Food"), N_("Groceries"), N_("Shopping"), N_("Transport"), N_("Bills"), N_("Entertainment"), N_("Health"), N_("Others")];
const PAYMENTS = [N_("UPI"), N_("Card"), N_("Cash"), N_("Wallet"), N_("Bank")];
const BASE = (import.meta.env.BASE_URL || "/").replace(/\/$/, "");

/* ---------- image helpers ------------------------------------------------ */

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(t("Couldn't open that image.")));
    img.src = src;
  });
}

const MAX_SIDE = 2600;

/** Draw the photo to a canvas (capped in size) and run the shared pipeline:
 *  de-shadow -> deskew -> crop -> two OCR-ready variants. */
function prepare(img) {
  const k = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
  const canvas = document.createElement("canvas");
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(img, 0, 0, w, h);
  const { data } = ctx.getImageData(0, 0, w, h);
  const { variants, info } = preprocessVariants(data, w, h);
  return {
    info,
    canvases: variants.map((v) => {
      const c = document.createElement("canvas");
      c.width = v.w; c.height = v.h;
      const cctx = c.getContext("2d");
      const out = cctx.createImageData(v.w, v.h);
      for (let i = 0, j = 0; i < v.gray.length; i++, j += 4) {
        out.data[j] = out.data[j + 1] = out.data[j + 2] = v.gray[i];
        out.data[j + 3] = 255;
      }
      cctx.putImageData(out, 0, 0);
      return c;
    }),
  };
}

/** OCR every variant with one worker. Everything is served from /public/tesseract
 *  so scanning works offline and the image never leaves the device. */
async function runOcr(canvases, onProgress) {
  const { createWorker } = await import("tesseract.js");
  let pass = 0;
  const worker = await createWorker("eng", 1, {
    workerPath: `${BASE}/tesseract/worker.min.js`,
    corePath: `${BASE}/tesseract/core`,
    langPath: `${BASE}/tesseract/lang`,
    logger: (m) => {
      if (m.status === "recognizing text") onProgress(Math.round(((pass + m.progress) / canvases.length) * 100), pass);
    },
  });
  try {
    await worker.setParameters({ preserve_interword_spaces: "1", tessedit_pageseg_mode: "6" });
    const texts = [];
    for (pass = 0; pass < canvases.length; pass++) {
      const { data } = await worker.recognize(canvases[pass]);
      texts.push(data.text || "");
    }
    return texts;
  } finally {
    worker.terminate();
  }
}

const toLocalInput = (iso) => {
  const d = iso ? new Date(iso) : new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

/* ---------- component ---------------------------------------------------- */

export default function ReceiptScanner({ onClose, onSaved, mode = "adult" }) {
  const { user } = useAuth();
  const { money } = useMoney();
  const isKid = mode === "kid";

  const [stage, setStage] = useState("capture");       // capture | reading | review | saved
  const [tab, setTab] = useState("camera");            // camera | upload | paste
  const [preview, setPreview] = useState(null);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState(t("Preparing image…"));
  const [error, setError] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [pasted, setPasted] = useState("");
  const [draft, setDraft] = useState(null);
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [camState, setCamState] = useState("idle");    // idle | starting | live | denied | unsupported

  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const fileRef = useRef(null);
  const camFileRef = useRef(null);

  /* camera lifecycle */
  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((item) => item.stop());
    streamRef.current = null;
  }, []);

  const startCamera = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia) { setCamState("unsupported"); return; }
    setCamState("starting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setCamState("live");
    } catch {
      setCamState("denied");
    }
  }, []);

  useEffect(() => {
    if (stage === "capture" && tab === "camera") startCamera();
    return stopCamera;
  }, [stage, tab, startCamera, stopCamera]);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  /* paste an image straight from the clipboard */
  useEffect(() => {
    const onPaste = (e) => {
      const file = [...(e.clipboardData?.files || [])].find((f) => f.type.startsWith("image/"));
      if (file && stage === "capture") { e.preventDefault(); handleFile(file); }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }); // eslint-disable-line

  /* pipeline */
  async function parseText(texts) {
    setPhase(t("Cross-checking the numbers…"));
    const list = Array.isArray(texts) ? texts : [texts];
    const { data } = await api.post("/expenses/parse-receipt", {
      text: list[0], alt_texts: list.slice(1).filter((item) => item && item.trim()),
    });
    setDraft(data);
    setForm({
      amount: data.amount ?? "",
      merchant: data.merchant || "",
      category: data.category || "Others",
      payment_method: data.payment_method || "UPI",
      note: data.note || "",
      timestamp: toLocalInput(data.timestamp),
    });
    if (!data.ok) setError(data.reason || "");
    setStage("review");
  }

  async function processImage(img, previewUrl) {
    setPreview(previewUrl);
    setStage("reading");
    setProgress(0);
    setError("");
    stopCamera();
    try {
      setPhase(t("Straightening & cleaning the photo…"));
      await new Promise((r) => setTimeout(r, 30));          // let the UI paint before the heavy work
      const { canvases } = prepare(img);
      const texts = await runOcr(canvases, (p, pass) => {
        setProgress(p);
        setPhase(pass === 0 ? t("Reading text on the bill…") : t("Double-checking with a second pass…"));
      });
      if (!texts.some((item) => item.trim())) throw new Error(t("I couldn't find any text. Try a flatter, brighter photo."));
      await parseText(texts);
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || t("Scanning failed."));
      setStage("capture");
      setTab("paste");
    }
  }

  async function handleFile(file) {
    if (!file || !file.type.startsWith("image/")) { setError(t("Please choose an image file (JPG, PNG, WEBP…).")); return; }
    try {
      const url = URL.createObjectURL(file);
      const img = await loadImage(url);
      await processImage(img, url);
    } catch (e) { setError(e.message); }
  }

  async function snap() {
    const v = videoRef.current;
    if (!v || !v.videoWidth) return;
    const c = document.createElement("canvas");
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext("2d").drawImage(v, 0, 0);
    const url = c.toDataURL("image/jpeg", 0.9);
    const img = await loadImage(url);
    await processImage(img, url);
  }

  async function usePastedText() {
    setError("");
    setStage("reading"); setProgress(100); setPhase(t("Understanding the bill…")); setPreview(null);
    try { await parseText(pasted); }
    catch (e) { setError(e?.response?.data?.detail || t("Couldn't parse that text.")); setStage("capture"); }
  }

  async function save() {
    if (!form.amount || Number(form.amount) <= 0) { setError(t("Enter the total amount first.")); return; }
    setSaving(true); setError("");
    try {
      const { data } = await api.post("/expenses", {
        amount: Number(form.amount),
        merchant: form.merchant,
        category: form.category,
        payment_method: form.payment_method,
        note: form.note,
        timestamp: form.timestamp ? new Date(form.timestamp).toISOString().replace("Z", "") : undefined,
        source: "scan",
      });
      setStage("saved");
      onSaved?.(data);
      setTimeout(onClose, 1500);
    } catch (e) {
      setError(e?.response?.data?.detail?.[0]?.msg || e?.response?.data?.detail || t("Couldn't save the expense."));
    } finally { setSaving(false); }
  }

  const [unusual, setUnusual] = useState(null);
  useEffect(() => {
    if (stage !== "review" || !form || !(Number(form.amount) > 0)) { setUnusual(null); return; }
    const id = setTimeout(() => {
      api.get("/insights/anomaly-check", { params: { amount: Number(form.amount), category: form.category } })
        .then((r) => setUnusual(r.data.unusual ? r.data : null)).catch(() => setUnusual(null));
    }, 350);
    return () => clearTimeout(id);
  }, [stage, form?.amount, form?.category]); // eslint-disable-line

  const conf = draft?.confidence || {};
  const low = (k) => draft && (conf[k] ?? 0) < 0.7;
  const dupes = draft?.possible_duplicates || [];
  const currencyMismatch = draft?.currency_hint && draft.currency_hint !== (user?.base_currency || "INR");

  return (
    <div className="scan-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="scan-modal" role="dialog" aria-modal="true" aria-label={t("Scan a bill")}>
        <div className="scan-head">
          <div>
            <span className="eyebrow">{isKid ? t("Magic bill reader") : t("Bill scanner")}</span>
            <h2 style={{ margin: 0, fontSize: "1.2rem" }}>
              {stage === "review" ? t("Check & save") : stage === "saved" ? t("Saved!") : isKid ? t("Snap your receipt 📸") : t("Scan or upload a bill")}
            </h2>
          </div>
          <button className="btn-ghost" onClick={onClose} aria-label={t("Close")}>✕</button>
        </div>

        {/* step dots */}
        <div className="scan-steps" aria-hidden>
          {["capture", "reading", "review"].map((s, i) => (
            <span key={s} className={`scan-dot ${["capture", "reading", "review", "saved"].indexOf(stage) >= i ? "on" : ""}`} />
          ))}
        </div>

        {error && <div className="scan-error" role="alert">{error}</div>}

        {/* ---------------- capture ---------------- */}
        {stage === "capture" && (
          <>
            <div className="scan-tabs">
              {[["camera", t("📷 Camera"), "camera"], ["upload", t("🖼️ Photo"), "image"], ["paste", t("📝 Paste text"), "text"]].map(([id, label, ic]) => (
                <button key={id} className={`scan-tab ${tab === id ? "active" : ""}`} onClick={() => { setError(""); setTab(id); }}><Icon name={ic} size={15} /> {plain(label)}</button>
              ))}
            </div>

            {tab === "camera" && (
              <div className="scan-stage">
                <video ref={videoRef} playsInline muted className="scan-video" style={{ opacity: camState === "live" ? 1 : 0 }} />
                {camState === "live" && (
                  <>
                    <div className="scan-frame"><i /><i /><i /><i /></div>
                    <div className="scan-laser" />
                  </>
                )}
                {camState !== "live" && (
                  <div className="scan-camfallback">
                    {camState === "starting" && <p>{t("Starting camera…")}</p>}
                    {camState === "denied" && <p>{t(
                      "Camera permission was blocked. Allow it in your browser, or use a photo instead."
                    )}</p>}
                    {camState === "unsupported" && <p>{t(
                      "Live camera isn't available here (it needs https or localhost). Use a photo instead."
                    )}</p>}
                    <button className="btn-ghost" onClick={() => camFileRef.current?.click()}>{t("Open phone camera / pick photo")}</button>
                  </div>
                )}
                {camState === "live" && (
                  <button className="scan-shutter" onClick={snap} aria-label={t("Capture bill")}><span /></button>
                )}
                <input ref={camFileRef} type="file" accept="image/*" capture="environment" hidden
                  onChange={(e) => handleFile(e.target.files?.[0])} />
              </div>
            )}

            {tab === "upload" && (
              <div
                className={`scan-drop ${dragOver ? "over" : ""}`}
                onClick={() => fileRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files?.[0]); }}
                role="button" tabIndex={0}
                onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && fileRef.current?.click()}
              >
                <div className="scan-drop-icon">🧾</div>
                <strong>{t("Drop a bill photo here")}</strong>
                <span>{t("or click to choose · you can also paste (Ctrl/⌘+V)")}</span>
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
              </div>
            )}

            {tab === "paste" && (
              <div>
                <label>{t("Paste the text from your bill (or e-receipt / SMS)")}</label>
                <textarea
                  className="scan-text" rows={7} value={pasted} onChange={(e) => setPasted(e.target.value)}
                  placeholder={t("Swiggy\nOrder total ₹450.00\nPaid via UPI\n03/10/2026")}
                />
                <button className="btn-primary" style={{ marginTop: "0.7rem" }} disabled={!pasted.trim()} onClick={usePastedText}>{t("Read this text")}</button>
              </div>
            )}

            <p className="scan-privacy">{t(
              "🔒 The image is read on your device — only the extracted text is sent to the app, and nothing is saved until you confirm."
            )}</p>
          </>
        )}

        {/* ---------------- reading ---------------- */}
        {stage === "reading" && (
          <div className="scan-stage reading">
            {preview ? <img src={preview} alt={t("Your bill")} className="scan-preview" /> : <div className="scan-preview" />}
            <div className="scan-laser strong" />
            <div className="scan-reading-bar">
              <div className="scan-progress"><div style={{ width: `${progress}%` }} /></div>
              <div className="scan-phase"><span className="scan-spinner" />{phase} {progress > 0 && progress < 100 ? `${progress}%` : ""}</div>
            </div>
          </div>
        )}

        {/* ---------------- review ---------------- */}
        {stage === "review" && form && (
          <div className="scan-review">
            <div className="scan-review-top">
              {preview && <img src={preview} alt={t("Scanned bill")} className="scan-thumb" />}
              <div className="scan-total">
                <span className="scan-total-label">{t("Total found")}</span>
                <span className="scan-total-value">{form.amount ? money(Number(form.amount)) : "—"}</span>
                <span className="scan-total-sub">{iconFor(form.category)} {t(form.category)}</span>
              </div>
            </div>

            {unusual && (
              <div className="scan-warn">
                🔎 {unusual.message} {t("Double-check the amount before saving.")}
              </div>
            )}
            {dupes.length > 0 && (
              <div className="scan-warn">
                ⚠️ {tn("Looks like you may have already logged this: {what} for {amount}. Save only if it's a separate purchase.", { what: <strong>{dupes[0].merchant || t("an expense")}</strong>, amount: money(dupes[0].amount) })}
              </div>
            )}
            {currencyMismatch && (
              <div className="scan-warn">
                💱 {t("The bill looks like {hint}, but your account records amounts in {base}. Convert the total first if they differ.", { hint: draft.currency_hint, base: user?.base_currency || "INR" })}
              </div>
            )}

            <div className="scan-grid">
              <Field label={t("Amount")} warn={low("amount")}>
                <input type="number" step="0.01" min="0" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                {low("amount") && draft.amount_alternatives?.length > 0 && (
                  <div className="scan-alts">
                    <span>{t("Maybe:")}</span>
                    {draft.amount_alternatives.slice(0, 3).map((a) => (
                      <button key={a} type="button" className="chip" onClick={() => setForm({ ...form, amount: String(a) })}>{money(a)}</button>
                    ))}
                  </div>
                )}
              </Field>
              <Field label={t("Merchant")} warn={low("merchant")}>
                <input value={form.merchant} onChange={(e) => setForm({ ...form, merchant: e.target.value })} />
              </Field>
              <Field label={t("Category")}>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{t(c)}</option>)}
                </select>
              </Field>
              <Field label={t("Payment")} warn={low("payment_method")}>
                <select value={form.payment_method} onChange={(e) => setForm({ ...form, payment_method: e.target.value })}>
                  {PAYMENTS.map((c) => <option key={c} value={c}>{t(c)}</option>)}
                </select>
              </Field>
              <Field label={t("Date & time")} warn={low("date")}>
                <input type="datetime-local" value={form.timestamp} onChange={(e) => setForm({ ...form, timestamp: e.target.value })} />
              </Field>
              <Field label={t("Note")}>
                <input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
              </Field>
            </div>

            {draft.items?.length > 0 && (
              <details className="scan-items">
                <summary>{tp(draft.items.length, "{n} line item detected", "{n} line items detected")}{draft.tax != null ? " · " + t("tax {amount}", { amount: money(draft.tax) }) : ""}</summary>
                <ul>
                  {draft.items.map((it, i) => (
                    <li key={i} style={{ animationDelay: `${i * 40}ms` }}><span>{it.name}</span><span className="mono">{money(it.amount)}</span></li>
                  ))}
                </ul>
              </details>
            )}

            {(draft.checks?.items_match || draft.checks?.subtotal_tax_match) && (
              <div className="scan-verified">{t("✓ The line items add up to this total")}</div>
            )}
            {draft.merchant_source === "history" && <div className="scan-verified">{t("✓ Matched to a merchant you've used before")}</div>}

            <div className="scan-legend"><span className="scan-flag" /> {t("amber fields were hard to read — please double-check them.")}</div>

            <div className="scan-actions">
              <button className="btn-ghost" onClick={() => { setStage("capture"); setTab("camera"); setError(""); }}>{t("↺ Rescan")}</button>
              <button className="btn-primary" disabled={saving} onClick={save}>{saving ? t("Saving…") : isKid ? t("Add it! 🎉") : t("Save expense")}</button>
            </div>
          </div>
        )}

        {/* ---------------- saved ---------------- */}
        {stage === "saved" && (
          <div className="scan-saved">
            <ConfettiBurst onDone={() => {}} />
            <svg viewBox="0 0 52 52" width="84" height="84">
              <circle className="scan-check-circle" cx="26" cy="26" r="23" fill="none" strokeWidth="3" />
              <path className="scan-check-mark" fill="none" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" d="M15 27 l8 8 l15 -17" />
            </svg>
            <p style={{ color: "var(--text-primary)", fontWeight: 600 }}>{t("Expense added from your bill")}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, warn, children }) {
  return (
    <div className={warn ? "scan-field warn" : "scan-field"}>
      <label>{label}{warn && <span className="scan-check-tag">{t("check")}</span>}</label>
      {children}
    </div>
  );
}
