export default function PiggyBank({ pct, label }) {
  const clamped = Math.max(0, Math.min(100, pct));
  const fillHeight = 60 * (clamped / 100); // out of a ~60px belly

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "0.5rem" }}>
      <svg width="140" height="120" viewBox="0 0 140 120">
        <defs>
          <clipPath id="pigBelly">
            <ellipse cx="70" cy="68" rx="52" ry="34" />
          </clipPath>
        </defs>
        {/* body */}
        <ellipse cx="70" cy="68" rx="52" ry="34" fill="var(--surface-raised)" stroke="var(--coral)" strokeWidth="3" />
        {/* fill level, rises from bottom based on pct */}
        <rect
          x="18" y={102 - fillHeight} width="104" height={fillHeight}
          fill="var(--amber)" clipPath="url(#pigBelly)"
          style={{ transition: "y 0.6s ease, height 0.6s ease" }}
        />
        {/* legs */}
        <rect x="35" y="95" width="10" height="16" rx="4" fill="var(--coral)" />
        <rect x="95" y="95" width="10" height="16" rx="4" fill="var(--coral)" />
        {/* ear */}
        <polygon points="35,40 45,20 55,42" fill="var(--coral)" />
        {/* snout */}
        <ellipse cx="112" cy="70" rx="14" ry="10" fill="var(--coral)" />
        <circle cx="107" cy="70" r="2.2" fill="#3a1400" />
        <circle cx="117" cy="70" r="2.2" fill="#3a1400" />
        {/* eye */}
        <circle cx="90" cy="55" r="3" fill="#3a1400" />
        {/* coin slot */}
        <rect x="58" y="30" width="24" height="5" rx="2.5" fill="#3a1400" opacity="0.5" />
        {/* tail */}
        <path d="M18 55 q-10 -6 -4 -16" stroke="var(--coral)" strokeWidth="4" fill="none" strokeLinecap="round" />
      </svg>
      <div style={{ fontFamily: "var(--font-mono)", fontWeight: 700, fontSize: "1.1rem", color: "var(--amber)" }}>
        {Math.round(clamped)}%
      </div>
      {label && <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", textAlign: "center" }}>{label}</div>}
    </div>
  );
}
