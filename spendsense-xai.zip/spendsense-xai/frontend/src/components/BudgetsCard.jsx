import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import { useMoney } from "../useMoney";
import { useAuth } from "../AuthContext";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import { BudgetBar } from "../pages/Budgets";
import { iconFor } from "../categoryIcons";
import { t } from "../i18n";

/** Dashboard summary: overall budget plus the categories closest to (or over) their limit. */
export default function BudgetsCard() {
  const { user } = useAuth();
  const { money } = useMoney();
  const bump = useExpenseAdded();
  const [d, setD] = useState(null);
  useEffect(() => { api.get("/budgets").then((r) => setD(r.data)).catch(() => setD(null)); }, [bump]);
  if (!d) return null;
  const senior = user?.platform_mode === "senior";
  const list = [d.overall, ...d.items.slice(0, d.overall ? 3 : 4)].filter(Boolean);
  return (
    <div className="card" style={{ marginTop: "1.2rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span className="eyebrow">{t("Budgets")}</span>
        <Link to="/budgets" style={{ fontSize: senior ? "1rem" : "0.78rem", color: "var(--teal)" }}>{list.length ? t("Manage") : t("Set a budget")} →</Link>
      </div>
      {list.length === 0
        ? <p style={{ margin: "0.5rem 0 0", fontSize: senior ? "1.05rem" : "0.86rem" }}>{t("Set a monthly limit and the app will warn you before you go over.")}</p>
        : <div style={{ marginTop: "0.7rem" }}>
            {list.map((it) => (
              <BudgetBar key={it.category} item={it} money={money} big={senior}
                label={it.category === "ALL" ? `🎯 ${t("Everything (overall)")}` : `${iconFor(it.category)} ${t(it.category)}`} />
            ))}
          </div>}
    </div>
  );
}
