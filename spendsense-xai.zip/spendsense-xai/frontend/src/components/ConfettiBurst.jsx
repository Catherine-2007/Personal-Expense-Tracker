import { useEffect, useRef } from "react";

/**
 * A short-lived canvas confetti burst, used to celebrate a newly-earned
 * badge or streak milestone. Renders for ~1.6s then calls onDone.
 * Uses the current theme's accent colors so it always matches.
 */
export default function ConfettiBurst({ onDone }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const styles = getComputedStyle(document.documentElement);
    const colors = [
      styles.getPropertyValue("--teal").trim(),
      styles.getPropertyValue("--amber").trim(),
      styles.getPropertyValue("--coral").trim(),
      styles.getPropertyValue("--violet").trim(),
    ];

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function resize() {
      canvas.width = window.innerWidth * devicePixelRatio;
      canvas.height = window.innerHeight * devicePixelRatio;
      canvas.style.width = "100%";
      canvas.style.height = "100%";
    }
    resize();

    if (reduceMotion) {
      const t = setTimeout(() => onDone?.(), 300);
      return () => clearTimeout(t);
    }

    const cx = canvas.width / 2;
    const cy = canvas.height / 3;
    const particles = Array.from({ length: 80 }, () => {
      const angle = Math.random() * Math.PI * 2;
      const speed = (Math.random() * 6 + 3) * devicePixelRatio;
      return {
        x: cx, y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 4 * devicePixelRatio,
        size: (Math.random() * 5 + 3) * devicePixelRatio,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.3,
        life: 1,
      };
    });

    let raf;
    const gravity = 0.18 * devicePixelRatio;
    const start = performance.now();

    function frame(now) {
      const elapsed = now - start;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const p of particles) {
        p.vy += gravity;
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.vr;
        p.life = Math.max(0, 1 - elapsed / 1500);

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        ctx.restore();
      }
      if (elapsed < 1600) {
        raf = requestAnimationFrame(frame);
      } else {
        onDone?.();
      }
    }
    raf = requestAnimationFrame(frame);

    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{ position: "fixed", inset: 0, zIndex: 200, pointerEvents: "none" }}
    />
  );
}
