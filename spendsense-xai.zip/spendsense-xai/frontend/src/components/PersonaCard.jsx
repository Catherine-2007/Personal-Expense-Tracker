import { useEffect, useState } from "react";
import api from "../api";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import CountUp from "./CountUp";

import { t } from "../i18n";

/** "Your spending persona": a friendly type with the numbers that earned it. */
export default function PersonaCard() {
  const bump = useExpenseAdded();
  const [d, setD] = useState(null);

  useEffect(() => {
    api.get("/insights/persona").then((r) => setD(r.data)).catch(() => setD({ available: false, reason: t(t(t("Couldn't load."))) }));
  }, [bump]);

  if (!d) return <div className="card skeleton" style={{ height: 230 }} />;
  if (!d.available) {
    return (
      <div className="card">
        <span className="eyebrow">{t("Your spending persona")}</span>
        <p style={{ margin: 0 }}>{d.reason}</p>
        {d.need && (
          <div className="persona-bar"><span style={{ width: `${Math.min(100, (d.have / d.need) * 100)}%` }} /></div>
        )}
      </div>
    );
  }

  return (
    <div className="card glow-card persona">
      <span className="eyebrow">{t("Your spending persona")}</span>
      <div className="persona-head">
        <div className="persona-emoji" aria-hidden>{d.emoji}</div>
        <div>
          <div className="persona-name shimmer-text">{d.name}</div>
          <div className="persona-tag">{d.tagline}</div>
        </div>
      </div>
      <div className="persona-traits">
        {d.traits.map((item, i) => (
          <div key={item.label} className="persona-trait" style={{ animationDelay: `${i * 70}ms` }} title={item.detail}>
            <div className="persona-trait-top"><span>{item.label}</span><b><CountUp value={item.value} format={(n) => `${Math.round(n)}%`} /></b></div>
            <div className="persona-bar"><span className="grow-bar" style={{ width: `${Math.min(100, item.value)}%` }} /></div>
          </div>
        ))}
      </div>
      <div className="persona-tip">💡 {d.tip}</div>
      <div className="persona-foot">{t("Based on {n} purchases in the last {days} days", { n: d.based_on, days: d.window_days })}</div>
    </div>
  );
}
