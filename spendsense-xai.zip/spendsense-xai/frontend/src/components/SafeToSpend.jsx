import { useEffect, useState } from "react";
import api from "../api";
import { useMoney } from "../useMoney";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import CountUp from "./CountUp";

import { t, tp, N_, formatDate } from "../i18n";

const COPY = {
  great: { color: "var(--teal)", emoji: "😎", adult: N_("You're comfortably on track today."), senior: N_("You are doing well today. Spend as usual.") },
  tight: { color: "var(--amber)", emoji: "🤏", adult: N_("Getting close to today's limit — pick purchases carefully."), senior: N_("You are close to today's limit. Spend with care.") },
  over: { color: "var(--coral)", emoji: "🛑", adult: N_("This month's budget is used up after your goal savings."), senior: N_("This month's money is used up. Please avoid extra spending.") },
};

/** "Safe to spend today" -- daily allowance after goals & month-to-date spend. */
export default function SafeToSpend({ mode = "adult", refreshKey = 0 }) {
  const bump = useExpenseAdded();
  const { money } = useMoney();
  const [d, setD] = useState(null);
  const [week, setWeek] = useState([]);

  useEffect(() => {
    api.get("/insights/safe-to-spend").then((r) => setD(r.data)).catch(() => setD({ available: false }));
  }, [refreshKey, bump]);

  useEffect(() => {
    api.get("/insights/heatmap", { params: { weeks: 4 } }).then((r) => setWeek(r.data.days.slice(-7))).catch(() => setWeek([]));
  }, [refreshKey, bump]);

  if (!d) return <div className="card skeleton" style={{ height: 170 }} />;
  if (!d.available) {
    return (
      <div className="card sts-card">
        <span className="eyebrow">{t("Safe to spend today")}</span>
        <p style={{ margin: 0 }}>{d.reason || t("Not enough data yet.")}</p>
      </div>
    );
  }

  const meta = COPY[d.status] || COPY.great;
  const senior = mode === "senior";
  const pctToday = d.daily_allowance > 0 ? Math.min(1, d.spent_today / d.daily_allowance) : 1;
  const size = 132, r = 56, c = 2 * Math.PI * r;

  return (
    <div className="card sts-card" style={{ borderColor: meta.color }}>
      <span className="eyebrow">{senior ? t("What you can spend today") : t("Safe to spend today")}</span>
      <div className="sts-body">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="sts-ring" aria-hidden>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--border)" strokeWidth="10" />
          <circle
            cx={size / 2} cy={size / 2} r={r} fill="none" stroke={meta.color} strokeWidth="10" strokeLinecap="round"
            strokeDasharray={c} strokeDashoffset={c * (1 - pctToday)} transform={`rotate(-90 ${size / 2} ${size / 2})`}
            style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1), stroke .4s" }}
          />
          <text x="50%" y="50%" textAnchor="middle" dominantBaseline="central" fontSize="30" className="sts-emoji">{meta.emoji}</text>
        </svg>
        <div>
          <div className="sts-big" style={{ color: meta.color }}>
            <CountUp value={Math.max(d.remaining_today, 0)} format={(n) => money(n)} />
          </div>
          <div className="sts-sub">{t("left of today's {amount} allowance", { amount: money(d.daily_allowance) })}</div>
          <p style={{ margin: "0.5rem 0 0", fontSize: "0.82rem", color: "var(--text-primary)" }}>{t(senior ? meta.senior : meta.adult)}</p>
        </div>
      </div>
      {week.length > 0 && d.daily_allowance > 0 && (() => {
        const top = Math.max(d.daily_allowance * 1.25, ...week.map((x) => x.total), 1);
        return (
          <div className="sts-week" aria-label={t("Last 7 days of spending versus your daily allowance")}>
            <div className="sts-week-line" style={{ bottom: `${(d.daily_allowance / top) * 100}%` }}><span>{t("daily allowance")}</span></div>
            {week.map((x, i) => (
              <div key={x.date} className="sts-week-col" title={`${x.date}: ${money(x.total)}`}>
                <span className="sts-week-bar" style={{ height: `${Math.max(3, (x.total / top) * 100)}%`, animationDelay: `${i * 70}ms`, background: x.total > d.daily_allowance ? "var(--coral)" : "var(--teal)" }} />
                <small>{formatDate(x.date, { weekday: "narrow" })}</small>
              </div>
            ))}
          </div>
        );
      })()}
      <div className="sts-foot">
        <span><b>{d.days_left}</b> {t("days left")}</span>
        <span><b>{money(d.month_remaining)}</b> {t("spendable this month")}</span>
        {d.goals_reserve > 0 && <span><b>{money(d.goals_reserve)}</b> {t("set aside for goals")}</span>}
      </div>
    </div>
  );
}
