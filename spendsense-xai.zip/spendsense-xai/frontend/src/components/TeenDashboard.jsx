import { useEffect, useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import api from "../api";
import ConfidenceRing from "./ConfidenceRing";
import MotivationCard from "./MotivationCard";
import ParticleField from "./ParticleField";
import SafeToSpend from "./SafeToSpend";
import SpendHeatmap from "./SpendHeatmap";
import Reveal from "./Reveal";
import { RoundUpCard } from "./InsightLab";
import PersonaCard from "./PersonaCard";
import { PageHeader, StatCard, tooltipStyle, CATEGORY_COLORS } from "./DashboardUI";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";

import { contextLabel, t } from "../i18n";

function InfoTip({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span style={{ position: "relative", display: "inline-block" }}>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={t("What does this mean?")}
        style={{
          width: 16, height: 16, borderRadius: "50%", background: "var(--border)",
          color: "var(--text-primary)", fontSize: "0.62rem", lineHeight: "16px",
          padding: 0, marginLeft: "0.3rem",
        }}
      >
        ?
      </button>
      {open && (
        <div style={{
          position: "absolute", bottom: "130%", left: "50%", transform: "translateX(-50%)",
          width: 190, background: "var(--surface-raised)", border: "1px solid var(--border-soft)",
          borderRadius: 8, padding: "0.5rem 0.6rem", fontSize: "0.72rem", color: "var(--text-primary)",
          zIndex: 10,
        }}>
          {text}
        </div>
      )}
    </span>
  );
}

function QuestChain({ triggers, currency, userId }) {
  const { money } = useMoney();
  const quests = triggers.slice(0, 2);
  const [results, setResults] = useState({});
  const [completed, setCompleted] = useState(() => {
    const stored = localStorage.getItem(`ss_quests_${userId}_${new Date().toISOString().slice(0, 7)}`);
    return stored ? JSON.parse(stored) : {};
  });

  useEffect(() => {
    quests.forEach((tr) => {
      api.post("/insights/counterfactual", {
        category: tr.category_affected, times_per_week_reduction: 1,
      }).then((r) => setResults((prev) => ({ ...prev, [tr.id]: r.data })));
    });
  }, [triggers]); // eslint-disable-line

  function toggleComplete(id) {
    const next = { ...completed, [id]: !completed[id] };
    setCompleted(next);
    localStorage.setItem(`ss_quests_${userId}_${new Date().toISOString().slice(0, 7)}`, JSON.stringify(next));
  }

  if (quests.length === 0) return null;

  return (
    <div className="card" style={{ background: "linear-gradient(135deg, rgba(155,140,255,0.12), rgba(53,208,192,0.08))", border: "1px solid var(--violet)" }}>
      <span className="eyebrow" style={{ color: "var(--violet)" }}>{t("This month's quests")}</span>
      <div style={{ display: "flex", flexDirection: "column", gap: "0.7rem", marginTop: "0.5rem" }}>
        {quests.map((tr, i) => {
          const result = results[tr.id];
          const done = completed[tr.id];
          return (
            <div key={tr.id} style={{
              display: "flex", alignItems: "center", gap: "0.7rem", padding: "0.6rem",
              background: "var(--surface-raised)", borderRadius: 10, opacity: done ? 0.65 : 1,
            }}>
              <button
                onClick={() => toggleComplete(tr.id)}
                style={{
                  width: 26, height: 26, borderRadius: "50%", flexShrink: 0,
                  background: done ? "var(--teal)" : "var(--surface)",
                  border: "2px solid var(--teal)", color: done ? "#06231f" : "transparent",
                  fontSize: "0.8rem", fontWeight: 700,
                }}
              >
                ✓
              </button>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "0.9rem", fontWeight: 600, textDecoration: done ? "line-through" : "none" }}>
                  {iconFor(tr.category_affected)} {t("Quest {n}: Cut {category} by 1x this week", { n: i + 1, category: t(tr.category_affected) })}
                </div>
                {result && (
                  <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>
                    {t("Worth ~{amount} saved · +50 XP", { amount: money(result.estimated_monthly_savings) })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function TeenDashboard({ report, triggers, currency, userId, title }) {
  const { money } = useMoney();
  const pieData = Object.entries(report.by_category).map(([name, value]) => ({ name, label: t(name), value }));

  return (
    <div>
      <div style={{ position: "relative", marginBottom: "1.4rem", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
        <div style={{ position: "relative", minHeight: 92 }}>
          <ParticleField density={40} />
          <div style={{ position: "relative", zIndex: 1, minHeight: "inherit", paddingTop: "0.8rem", display: "flex", alignItems: "flex-end", padding: "0 0.2rem" }}>
            <PageHeader title={title} subtitle={`${report.period} · ${t("your own numbers, never compared to anyone else")}`} />
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1rem", marginBottom: "1rem" }}>
        <StatCard label={t("Total spend this month")} numeric={report.total_spend} format={(n) => money(n)} value={money(report.total_spend)}
          delta={report.self_comparison.pct_change_vs_baseline} />
        <StatCard label={<>{t("Habit score")} <InfoTip text={t(
          "A 0-100 score based on how your spending and goals are trending. Higher is better."
        )} /></>} value={`${report.financial_habit_score}/100`} highlight />
        <StatCard label={<>{t("Patterns found")} <InfoTip text={t("Habits the app noticed by looking at when and how you spend.")} /></>} value={triggers.length} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "1rem", marginBottom: "1rem" }}>
        <SafeToSpend mode="teen" />
        <Reveal><SpendHeatmap weeks={14} title={t("Your spending calendar")} /></Reveal>
      </div>

      <Reveal style={{ marginBottom: "1rem" }}><PersonaCard /></Reveal>

      <Reveal style={{ marginBottom: "1rem" }}><RoundUpCard /></Reveal>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
        <QuestChain triggers={triggers} currency={currency} userId={userId} />
        <MotivationCard userId={userId} variant="compact" mode="teen" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
        <div className="card">
          <span className="eyebrow">{t("Where your money went")}</span>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="label" innerRadius={50} outerRadius={78} paddingAngle={2}>
                {pieData.map((_, i) => <Cell key={i} fill={CATEGORY_COLORS[i % CATEGORY_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => money(v)} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.6rem", marginTop: "0.6rem" }}>
            {pieData.map((d) => (
              <div key={d.name} style={{ display: "flex", alignItems: "center", gap: "0.3rem", fontSize: "0.78rem", color: "var(--text-muted)" }}>
                <span>{iconFor(d.name)}</span>
                {t(d.name)} · {report.by_category_pct[d.name]}%
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <span className="eyebrow">{t("Your patterns, explained")}</span>
          {triggers.length === 0 ? (
            <p>{t("Log a few expenses and check Insights to find your first pattern.")}</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem" }}>
              {triggers.slice(0, 3).map((item) => (
                <div key={item.id} style={{ display: "flex", alignItems: "center", gap: "0.7rem", padding: "0.6rem", background: "var(--surface-raised)", borderRadius: 10 }}>
                  <ConfidenceRing value={item.confidence} size={44} />
                  <div style={{ fontSize: "0.8rem" }}>
                    <div style={{ fontWeight: 600 }}>{iconFor(item.category_affected)} {t(item.category_affected)}</div>
                    <div style={{ color: "var(--text-muted)" }}>{contextLabel(item.context_key)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
