import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { useTheme } from "../ThemeContext";
import { useLanguage } from "../LanguageContext";

import { t, N_ } from "../i18n";
import Icon from "./Icon";

// Kid mode gets friendlier nav labels (translated like everything else).
const KID_LABELS = {
  "/": N_("My Money"),
  "/expenses": N_("Add Spending"),
  "/insights": N_("My Patterns"),
  "/interventions": N_("Fun Tips"),
  "/goals": N_("My Piggy Bank"),
  "/budgets": N_("My Spending Limits"),
  "/report": N_("My Story"),
  "/family": N_("My Family"),
  "/settings": N_("Settings"),
};

function useNavGroups(item, mode) {
  const kid = (to, label) => (mode === "kid" && KID_LABELS[to] ? t(KID_LABELS[to]) : label);
  return [
    { title: t("Overview"), items: [
      { to: "/", label: kid("/", item("nav.dashboard")), icon: "dashboard" },
      { to: "/expenses", label: kid("/expenses", item("nav.expenses")), icon: "expenses" },
    ]},
    { title: t("Plan & save"), items: [
      { to: "/goals", label: kid("/goals", item("nav.goals")), icon: "goals" },
      { to: "/budgets", label: kid("/budgets", t("Budgets")), icon: "budgets" },
      { to: "/family", label: kid("/family", item("Family")), icon: "family" },
    ]},
    { title: t("Understand"), items: [
      { to: "/insights", label: kid("/insights", item("nav.insights")), icon: "insights" },
      { to: "/interventions", label: kid("/interventions", item("nav.interventions")), icon: "interventions" },
      { to: "/report", label: kid("/report", item("nav.report")), icon: "report" },
    ]},
    { title: t("Help"), items: [
      { to: "/guide", label: t("Feature guide"), icon: "guide" },
      { to: "/settings", label: kid("/settings", item("nav.settings")), icon: "settings" },
    ]},
  ];
}

export default function Sidebar({ onScan, open, onClose }) {
  const { user, logout } = useAuth();
  const { theme, setTheme, themes } = useTheme();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [themeOpen, setThemeOpen] = useState(false);
  const GROUPS = useNavGroups(t, user?.platform_mode);
  const initials = (user?.name || "?").split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();

  return (
    <>
      <div className={`sidebar-scrim${open ? " show" : ""}`} onClick={onClose} aria-hidden="true" />
      <aside className={`sidebar${open ? " open" : ""}`} aria-label={t("Main navigation")}>
        <div className="brand">
          <svg width="28" height="28" viewBox="0 0 26 26" aria-hidden="true">
            <circle cx="13" cy="13" r="11" fill="none" stroke="var(--teal)" strokeWidth="2.5" />
            <circle cx="13" cy="13" r="3.5" fill="var(--teal)" />
          </svg>
          <div className="brand-name">SpendSense<span>{t("-XAI")}</span></div>
          <button className="icon-btn sidebar-close" onClick={onClose} aria-label={t("Close menu")}><Icon name="close" /></button>
        </div>

        <button className="btn-primary scan-nav-btn scan-cta" onClick={() => { onClose?.(); onScan(); }}>
          <Icon name="scan" size={18} /> {user?.platform_mode === "kid" ? t("Snap a receipt") : t("Scan a bill")}
        </button>

        <button className="cmdk-trigger" onClick={() => { onClose?.(); window.dispatchEvent(new Event("ss:open-palette")); }} aria-label={t("Search or jump to…")}>
          <Icon name="search" size={15} /> <span>{t("Search")}</span> <kbd>Ctrl K</kbd>
        </button>

        <nav className="nav-scroll">
          {GROUPS.map((g) => (
            <div key={g.title} className="nav-group">
              <div className="nav-group-title">{g.title}</div>
              {g.items.map((n) => (
                <NavLink key={n.to} to={n.to} end={n.to === "/"} onClick={onClose}
                  className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
                  <Icon name={n.icon} className="nav-icon" />
                  <span>{n.label}</span>
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="theme-pick">
          <button className="theme-btn" onClick={() => setThemeOpen((o) => !o)} aria-expanded={themeOpen}>
            <Icon name="palette" size={16} />
            <span className="swatch" style={{ background: themes.find((x) => x.id === theme)?.swatch }} />
            <span className="grow">{themes.find((x) => x.id === theme)?.label && t(themes.find((x) => x.id === theme).label)}</span>
            <span className="caret">{themeOpen ? "▴" : "▾"}</span>
          </button>
          {themeOpen && (
            <div className="theme-menu">
              {themes.map((th) => (
                <button key={th.id} onClick={() => { setTheme(th.id); setThemeOpen(false); }} className={th.id === theme ? "on" : ""}>
                  <span className="swatch" style={{ background: th.swatch }} />
                  <span>
                    <div>{t(th.label)}</div>
                    <div className="sub">{t(th.blurb)}</div>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="user-box">
          <div className="avatar" aria-hidden="true">{initials}</div>
          <div className="who">
            <div className="name">{user?.name} <PlatformBadge mode={user?.platform_mode} /></div>
            <div className="mail">{user?.email}</div>
          </div>
          <button className="icon-btn" title={t("common.signOut")} aria-label={t("common.signOut")}
            onClick={() => { logout(); navigate("/login"); }}><Icon name="logout" /></button>
        </div>
      </aside>
    </>
  );
}

const MODE_META = {
  kid: { label: N_("Kid Mode"), icon: "🧒", color: "var(--coral)" },
  teen: { label: N_("Teen Mode"), icon: "🧑", color: "var(--violet)" },
  adult: { label: N_("Adult Mode"), icon: "✓", color: "var(--teal)" },
};

function PlatformBadge({ mode }) {
  const meta = MODE_META[mode] || MODE_META.adult;
  return (
    <span
      title={t("This account is using the {mode} experience — change it any time in Settings.", { mode: t(meta.label) })}
      style={{
        fontSize: "0.64rem", fontWeight: 700, color: meta.color,
        background: "rgba(140,151,184,0.12)", padding: "0.1rem 0.4rem", borderRadius: 6,
      }}
    >
      {meta.icon} {t(meta.label)}
    </span>
  );
}
