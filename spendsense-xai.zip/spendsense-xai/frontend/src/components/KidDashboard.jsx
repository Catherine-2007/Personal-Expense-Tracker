import { useEffect, useState } from "react";
import api from "../api";
import MotivationCard from "./MotivationCard";
import MoneyBuddy from "./MoneyBuddy";
import ParticleField from "./ParticleField";
import PiggyBank from "./PiggyBank";
import { formatCurrency } from "../currency";
import { useMoney } from "../useMoney";
import { iconFor } from "../categoryIcons";

import { t } from "../i18n";

function scoreToStars(score) {
  return Math.max(1, Math.min(5, Math.round(score / 20)));
}

export default function KidDashboard({ report, triggers, currency, userId, title, goals }) {
  const { money } = useMoney();
  const entries = Object.entries(report.by_category);
  const maxAmount = Math.max(...entries.map(([, v]) => v), 1);
  const stars = scoreToStars(report.financial_habit_score);

  const activeGoal = goals?.[0];
  const goalPct = activeGoal ? Math.min(100, (activeGoal.saved_amount / activeGoal.target_amount) * 100) : null;

  const spentLess = report.self_comparison.pct_change_vs_baseline < 0;

  const [motivation, setMotivation] = useState(null);
  useEffect(() => {
    api.get("/motivation").then((r) => setMotivation(r.data));
  }, [userId]);

  return (
    <div>
      <div style={{ position: "relative", marginBottom: "1.4rem", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
        <div style={{ position: "relative", minHeight: 110 }}>
          <ParticleField density={55} />
          <div style={{ position: "relative", zIndex: 1, minHeight: "inherit", paddingTop: "0.8rem", display: "flex", alignItems: "center", padding: "0 0.4rem" }}>
            <div>
              <h1 style={{ fontSize: "1.7rem", margin: 0 }}>{title}</h1>
              <p style={{ margin: 0, fontSize: "0.9rem" }}>{report.period} {t("— here's how your money is doing! 🌟")}</p>
            </div>
          </div>
        </div>
      </div>

      {motivation && (
        <div style={{ marginBottom: "1rem" }}>
          <MoneyBuddy
            habitScore={report.financial_habit_score}
            streak={motivation.streak_days}
            message={motivation.message}
          />
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
        <div className="card" style={{ textAlign: "center" }}>
          <span className="eyebrow">{t("Your money star score")}</span>
          <div style={{ fontSize: "2.2rem", letterSpacing: "0.1em", margin: "0.4rem 0" }}>
            {"⭐".repeat(stars)}{"☆".repeat(5 - stars)}
          </div>
          <p style={{ fontSize: "0.85rem" }}>
            {spentLess
              ? t("You spent a little less than usual this month. Awesome job!")
              : t(
              "You spent a bit more than usual this month — no worries, tomorrow's a fresh start!"
            )}
          </p>
        </div>

        {activeGoal ? (
          <div className="card" style={{ textAlign: "center" }}>
            <span className="eyebrow">{t("Saving for: {title}", { title: activeGoal.title })}</span>
            <PiggyBank pct={goalPct} label={t("{saved} of {target}", { saved: money(activeGoal.saved_amount), target: money(activeGoal.target_amount) })} />
          </div>
        ) : (
          <div className="card" style={{ textAlign: "center", display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <span className="eyebrow">{t("Piggy bank")}</span>
            <p style={{ fontSize: "0.85rem" }}>{t(
              "You don't have a savings goal yet! Ask a grown-up to help you set one on the Goals page. 🐷"
            )}</p>
          </div>
        )}
      </div>

      <div style={{ marginBottom: "1rem" }}>
        <MotivationCard userId={userId} variant="big" mode="kid" />
      </div>

      <div className="card">
        <span className="eyebrow">{t("Where did your money go?")}</span>
        <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem", marginTop: "0.6rem" }}>
          {entries.length === 0 && <p>{t("No spending yet — add something on the Expenses page!")}</p>}
          {entries.map(([name, value]) => (
            <div key={name} style={{ display: "flex", alignItems: "center", gap: "0.7rem" }}>
              <span style={{ fontSize: "1.4rem", width: 32 }}>{iconFor(name)}</span>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", marginBottom: "0.2rem" }}>
                  <strong>{t(name)}</strong>
                  <span>{money(value)}</span>
                </div>
                <div style={{ height: 10, borderRadius: 6, background: "var(--surface-raised)", overflow: "hidden" }}>
                  <div style={{
                    width: `${(value / maxAmount) * 100}%`, height: "100%",
                    background: "linear-gradient(90deg, var(--teal), var(--amber))",
                  }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
