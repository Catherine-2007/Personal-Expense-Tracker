import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import { useAuth } from "../AuthContext";
import { useExpenseAdded } from "../hooks/useExpenseAdded";
import { t } from "../i18n";
import Icon from "./Icon";

const safe = (fn, d) => { try { return fn(); } catch { return d; } };

/** First-run checklist: shows real progress (from the database) until everything is done or dismissed. */
export default function GetStarted({ goals }) {
  const { user } = useAuth();
  const bump = useExpenseAdded();
  const key = `ss_gs_dismissed_${user?.id}`;
  const [hidden, setHidden] = useState(() => safe(() => localStorage.getItem(key) === "1", false));
  const [s, setS] = useState(null);

  useEffect(() => {
    Promise.all([api.get("/expenses"), api.get("/budgets")])
      .then(([e, b]) => setS({
        expenses: e.data.length,
        scanned: e.data.some((x) => x.source === "scan"),
        budgets: (b.data.items?.length || 0) + (b.data.overall ? 1 : 0),
      }))
      .catch(() => setS(null));
  }, [bump]);

  if (hidden || !s) return null;
  const guideSeen = safe(() => localStorage.getItem(`ss_guide_seen_${user?.id}`) === "1", false);
  const steps = [
    { done: s.expenses > 0, label: t("Log your first expense"), to: "/expenses", icon: "expenses" },
    { done: s.scanned, label: t("Scan a bill with your camera"), event: "ss:open-scanner", icon: "scan" },
    { done: (goals?.length || 0) > 0, label: t("Create a savings goal"), to: "/goals", icon: "goals" },
    { done: s.budgets > 0, label: t("Set a monthly budget"), to: "/budgets", icon: "budgets" },
    { done: guideSeen, label: t("Take the feature tour"), to: "/guide", icon: "guide" },
  ];
  const n = steps.filter((x) => x.done).length;
  if (n === steps.length) return null;

  return (
    <section className="card get-started" aria-label={t("Getting started")}>
      <div className="gs-head">
        <div>
          <span className="eyebrow">{t("Getting started")}</span>
          <h3>{t("{n} of {total} steps done", { n, total: steps.length })}</h3>
        </div>
        <button className="icon-btn" aria-label={t("Hide")} title={t("Hide")}
          onClick={() => { safe(() => localStorage.setItem(key, "1")); setHidden(true); }}><Icon name="close" /></button>
      </div>
      <div className="gs-bar" role="progressbar" aria-valuenow={n} aria-valuemin={0} aria-valuemax={steps.length}><i style={{ width: `${(n / steps.length) * 100}%` }} /></div>
      <ul className="gs-list">
        {steps.map((x) => {
          const inner = (
            <>
              <span className={`gs-check${x.done ? " done" : ""}`}>{x.done ? <Icon name="check" size={14} /> : null}</span>
              <Icon name={x.icon} size={16} />
              <span className="gs-label">{x.label}</span>
              {!x.done && <span className="gs-go">→</span>}
            </>
          );
          return (
            <li key={x.label} className={x.done ? "is-done" : ""}>
              {x.done ? <div className="gs-row">{inner}</div>
                : x.to ? <Link className="gs-row" to={x.to}>{inner}</Link>
                : <button className="gs-row" onClick={() => window.dispatchEvent(new Event(x.event))}>{inner}</button>}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
