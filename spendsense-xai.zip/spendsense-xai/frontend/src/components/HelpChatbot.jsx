import { useEffect, useRef, useState } from "react";
import api from "../api";
import { useLanguage } from "../LanguageContext";

import { t } from "../i18n";

export default function HelpChatbot() {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from: "bot", text: t("Hi! I'm your built-in guide — ask me how to use any part of SpendSense-XAI.") },
  ]);
  const [input, setInput] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    api.get("/help/topics").then((r) => setSuggestions(r.data.suggestions)).catch(() => {});
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  async function send(text) {
    const message = (text ?? input).trim();
    if (!message || sending) return;
    setMessages((prev) => [...prev, { from: "user", text: message }]);
    setInput("");
    setSending(true);
    try {
      const { data } = await api.post("/help/ask", { message });
      setMessages((prev) => [...prev, { from: "bot", text: data.reply }]);
      setSuggestions(data.suggestions || []);
    } catch {
      setMessages((prev) => [...prev, { from: "bot", text: t("Sorry, I couldn't reach the help service just now.") }]);
    } finally {
      setSending(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={t("help.title")}
        style={{
          position: "fixed", bottom: 24, right: 24, zIndex: 50,
          width: 56, height: 56, borderRadius: "50%",
          background: "linear-gradient(135deg, var(--teal), var(--violet))",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 8px 24px rgba(0,0,0,0.35)", fontSize: "1.5rem",
        }}
      >
        {open ? "✕" : "💬"}
      </button>

      {open && (
        <div
          role="dialog"
          aria-label={t("help.title")}
          style={{
            position: "fixed", bottom: 92, right: 24, zIndex: 50,
            width: 340, maxHeight: 460, display: "flex", flexDirection: "column",
            background: "var(--surface)", border: "1px solid var(--border-soft)",
            borderRadius: "var(--radius-lg)", boxShadow: "0 20px 60px rgba(0,0,0,0.4)",
            overflow: "hidden",
          }}
        >
          <div style={{ padding: "0.9rem 1rem", borderBottom: "1px solid var(--border-soft)" }}>
            <strong style={{ fontFamily: "var(--font-display)" }}>{t("help.title")}</strong>
            <div style={{ fontSize: "0.72rem", color: "var(--text-faint)" }}>{t("Built-in guide · no data leaves your app")}</div>
          </div>

          <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "0.8rem 1rem", display: "flex", flexDirection: "column", gap: "0.6rem" }}>
            {messages.map((m, i) => (
              <div
                key={i}
                style={{
                  alignSelf: m.from === "user" ? "flex-end" : "flex-start",
                  background: m.from === "user" ? "var(--teal)" : "var(--surface-raised)",
                  color: m.from === "user" ? "#06231f" : "var(--text-primary)",
                  padding: "0.55rem 0.8rem",
                  borderRadius: 12,
                  fontSize: "0.84rem",
                  maxWidth: "85%",
                  lineHeight: 1.4,
                }}
              >
                {m.text}
              </div>
            ))}
            {sending && <div style={{ fontSize: "0.78rem", color: "var(--text-faint)" }}>{t("Thinking…")}</div>}
          </div>

          {suggestions.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem", padding: "0 1rem 0.6rem" }}>
              {suggestions.map((s) => (
                <button
                  key={s}
                  className="btn-ghost"
                  style={{ fontSize: "0.72rem", padding: "0.35rem 0.6rem" }}
                  onClick={() => send(s)}
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          <form
            onSubmit={(e) => { e.preventDefault(); send(); }}
            style={{ display: "flex", gap: "0.5rem", padding: "0.7rem", borderTop: "1px solid var(--border-soft)" }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t("help.placeholder")}
              style={{ flex: 1 }}
            />
            <button className="btn-primary" type="submit" disabled={sending}>➤</button>
          </form>
        </div>
      )}
    </>
  );
}
