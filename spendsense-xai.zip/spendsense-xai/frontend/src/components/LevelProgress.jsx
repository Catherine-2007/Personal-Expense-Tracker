import { t } from "../i18n";
export default function LevelProgress({ level, levelTitle, xpIntoLevel, xpForNextLevel, isMaxLevel, mode = "adult" }) {
  const pct = isMaxLevel ? 100 : Math.min(100, (xpIntoLevel / xpForNextLevel) * 100);
  const isKid = mode === "kid";
  const isSenior = mode === "senior";

  return (
    <div className="card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.5rem" }}>
        <span className="eyebrow" style={{ color: "var(--violet)" }}>
          {isKid ? t("🌟 Your Level") : isSenior ? t("Progress Level") : t("Level")}
        </span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: "0.8rem" }}>
        <div style={{
          width: isKid ? 56 : 44, height: isKid ? 56 : 44, borderRadius: "50%", flexShrink: 0,
          background: "linear-gradient(135deg, var(--violet), var(--teal))",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 700, fontSize: isKid ? "1.4rem" : "1.1rem", color: "#0b0f1a",
        }}>
          {level}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: isSenior ? "1.15rem" : "0.95rem", marginBottom: "0.3rem" }}>
            {levelTitle}
          </div>
          <div style={{ height: isSenior ? 14 : 8, borderRadius: 6, background: "var(--surface-raised)", overflow: "hidden" }}>
            <div style={{
              width: `${pct}%`, height: "100%",
              background: "linear-gradient(90deg, var(--violet), var(--teal))",
              transition: "width 0.5s ease",
            }} />
          </div>
          {!isMaxLevel && (
            <div style={{ fontSize: isSenior ? "0.88rem" : "0.7rem", color: "var(--text-faint)", marginTop: "0.25rem" }}>
              {t("{a} / {b} XP to next level", { a: xpIntoLevel, b: xpForNextLevel })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
