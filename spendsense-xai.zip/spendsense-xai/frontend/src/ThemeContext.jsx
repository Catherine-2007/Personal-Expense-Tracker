import { N_ } from "./i18n";
import { createContext, useContext, useEffect, useState, useCallback } from "react";

export const THEMES = [
  { id: "night", label: N_("Night Ledger"), blurb: N_("Dark & focused"), swatch: "#35d0c0" },
  { id: "day", label: N_("Daylight"), blurb: N_("Clean & bright"), swatch: "#0f9c8c" },
  { id: "ocean", label: N_("Deep Ocean"), blurb: N_("Cool blues"), swatch: "#4fd3ff" },
  { id: "kid", label: N_("Playground"), blurb: N_("Big, bright & fun"), swatch: "#ff9f1c" },
  { id: "senior", label: N_("Comfort"), blurb: N_("Larger text, high contrast"), swatch: "#0a6e5c" },
];

/** `stack` must match the html[data-font=...] rules in theme.css (null = theme's own font). */
export const FONT_STYLES = [
  { id: "default", label: N_("Theme default"), blurb: N_("Whatever suits the theme"), stack: null },
  { id: "clean", label: N_("Clean Sans"), blurb: N_("Modern & neutral"), stack: '"Inter", sans-serif' },
  { id: "rounded", label: N_("Friendly Rounded"), blurb: N_("Soft & approachable"), stack: '"Nunito", sans-serif' },
  { id: "serif", label: N_("Elegant Serif"), blurb: N_("Warm & editorial"), stack: '"Lora", Georgia, serif' },
  { id: "classic", label: N_("Classic Serif"), blurb: N_("Traditional print feel"), stack: '"Merriweather", Georgia, serif' },
  { id: "readable", label: N_("Easy Reading"), blurb: N_("Built for low vision"), stack: '"Atkinson Hyperlegible", sans-serif' },
  { id: "dyslexia", label: N_("Dyslexia-friendly"), blurb: N_("Wider, calmer letter shapes"), stack: '"Lexend", sans-serif' },
  { id: "mono", label: N_("Typewriter"), blurb: N_("Monospaced ledger look"), stack: '"JetBrains Mono", monospace' },
];

export const FONT_SIZE_PRESETS = [
  { label: N_("S"), value: 0.88 },
  { label: N_("M"), value: 1 },
  { label: N_("L"), value: 1.15 },
  { label: N_("XL"), value: 1.3 },
  { label: N_("XXL"), value: 1.5 },
];

const clampScale = (n) => Math.min(1.75, Math.max(0.75, Number(n) || 1));
const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(() => localStorage.getItem("ss_theme") || "night");
  const [fontScale, setFontScaleState] = useState(() => clampScale(localStorage.getItem("ss_font_scale") || 1));
  const [fontStyle, setFontStyleState] = useState(() => localStorage.getItem("ss_font_style") || "default");
  const [fx, setFxState] = useState(() => localStorage.getItem("ss_fx") || "full");
  const [lineSpacing, setLineSpacingState] = useState(() => localStorage.getItem("ss_line_spacing") || "normal");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("ss_theme", theme);
  }, [theme]);

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--font-scale", String(fontScale));
    root.setAttribute("data-font", fontStyle);
    root.setAttribute("data-spacing", lineSpacing);
    localStorage.setItem("ss_font_scale", String(fontScale));
    localStorage.setItem("ss_font_style", fontStyle);
    localStorage.setItem("ss_line_spacing", lineSpacing);
  }, [fontScale, fontStyle, lineSpacing]);

  useEffect(() => {
    document.documentElement.setAttribute("data-fx", fx);
    localStorage.setItem("ss_fx", fx);
  }, [fx]);
  const setFx = useCallback((v) => setFxState(v), []);

  const setTheme = useCallback((id) => setThemeState(id), []);
  const setFontScale = useCallback((n) => setFontScaleState(clampScale(n)), []);
  const setFontStyle = useCallback((id) => setFontStyleState(id), []);
  const setLineSpacing = useCallback((id) => setLineSpacingState(id), []);

  return (
    <ThemeContext.Provider value={{
      theme, setTheme, themes: THEMES,
      fx, setFx, fontScale, setFontScale, fontStyle, setFontStyle, lineSpacing, setLineSpacing,
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
