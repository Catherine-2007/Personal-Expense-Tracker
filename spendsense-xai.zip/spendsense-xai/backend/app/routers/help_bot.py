from fastapi import APIRouter, Depends
from .. import models, schemas
from ..deps import get_current_user
from ..services import help_bot

router = APIRouter(prefix="/help", tags=["help"])


@router.post("/ask", response_model=schemas.HelpAskResponse)
def ask(
    payload: schemas.HelpAskRequest,
    current_user: models.User = Depends(get_current_user),
):
    # The bot speaks in the signed-in user's platform mode (kid-friendly
    # wording for kid mode), taken from their account rather than trusted
    # client input.
    reply, suggestions = help_bot.ask(payload.message, current_user.platform_mode or "adult")
    return schemas.HelpAskResponse(reply=reply, suggestions=suggestions)


@router.get("/topics")
def topics(current_user: models.User = Depends(get_current_user)):
    """A few starter questions the frontend can show as quick-tap chips,
    tailored to the user's platform mode."""
    return {"suggestions": help_bot.suggestions(current_user.platform_mode == "kid")}
