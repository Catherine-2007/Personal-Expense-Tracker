from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..deps import get_current_user
from ..services import motivation

router = APIRouter(prefix="/motivation", tags=["motivation"])


@router.get("", response_model=schemas.MotivationOut)
def get_motivation(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return motivation.get_motivation(db, current_user)
