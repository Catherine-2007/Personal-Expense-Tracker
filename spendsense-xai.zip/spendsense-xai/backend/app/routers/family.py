import datetime as dt
import secrets
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .. import models
from ..database import get_db
from ..deps import get_current_user
from ..i18n import tr
from ..security import create_access_token, hash_password
from ..services import age_tier, family as fam

router = APIRouter(prefix="/family", tags=["family"])


# ---------- payloads ----------
class FamilyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    emoji: str = "🏡"
    monthly_budget: float = Field(default=0.0, ge=0)


class JoinIn(BaseModel):
    code: str


class FamilyUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    emoji: Optional[str] = None
    monthly_budget: Optional[float] = Field(default=None, ge=0)


class MeUpdate(BaseModel):
    share_level: Optional[str] = None
    avatar: Optional[str] = None


class RoleUpdate(BaseModel):
    role: str


class ChildCreate(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    age: int = Field(ge=3, le=17)
    avatar: str = "🧸"


class ChallengeCreate(BaseModel):
    kind: str
    target: float = Field(gt=0)
    title: str = Field(default="", max_length=200)
    category: str = ""
    days: int = Field(default=7, ge=1, le=60)


class KudosIn(BaseModel):
    to_user_id: int
    emoji: str = "👏"


# ---------- helpers ----------
def _need_family(db: Session, user: models.User) -> models.FamilyMember:
    m = fam.get_membership(db, user)
    if not m:
        raise HTTPException(status_code=404, detail=tr("You are not in a family yet"))
    return m


def _need_parent(db: Session, user: models.User) -> models.FamilyMember:
    m = _need_family(db, user)
    if not fam.is_parent(m):
        raise HTTPException(status_code=403, detail=tr("Only a parent or the family owner can do that"))
    return m


# ---------- create / join / leave ----------
@router.get("")
def my_family(period: str = "month", db: Session = Depends(get_db),
              current_user: models.User = Depends(get_current_user)):
    return fam.build_dashboard(db, current_user, "week" if period == "week" else "month")


@router.post("", status_code=201)
def create_family(payload: FamilyCreate, db: Session = Depends(get_db),
                  current_user: models.User = Depends(get_current_user)):
    if fam.get_membership(db, current_user):
        raise HTTPException(status_code=400, detail=tr("You are already in a family"))
    f = models.Family(
        name=payload.name.strip(), emoji=payload.emoji or "🏡", monthly_budget=payload.monthly_budget,
        currency=current_user.base_currency or "INR", invite_code=fam.new_invite_code(db),
        created_by=current_user.id,
    )
    db.add(f)
    db.flush()
    db.add(models.FamilyMember(family_id=f.id, user_id=current_user.id, role="owner"))
    db.commit()
    return fam.build_dashboard(db, current_user)


@router.post("/join")
def join_family(payload: JoinIn, db: Session = Depends(get_db),
                current_user: models.User = Depends(get_current_user)):
    if fam.get_membership(db, current_user):
        raise HTTPException(status_code=400, detail=tr("You are already in a family"))
    code = payload.code.strip().upper().replace("-", "").replace(" ", "")
    f = db.query(models.Family).filter(models.Family.invite_code == code).first()
    if not f:
        raise HTTPException(status_code=404, detail=tr("That invite code doesn't match any family"))
    if len(f.members) >= 12:
        raise HTTPException(status_code=400, detail=tr("This family is full (12 members)"))
    age = age_tier.compute_age(current_user)
    role = "child" if (age is not None and age < 13) else "member"
    db.add(models.FamilyMember(family_id=f.id, user_id=current_user.id, role=role))
    db.commit()
    return fam.build_dashboard(db, current_user)


@router.post("/leave")
def leave_family(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    m = _need_family(db, current_user)
    f = m.family
    others = [x for x in f.members if x.user_id != current_user.id]
    if m.role == "owner" and others:
        # hand over ownership to a parent, else the longest-standing adult member
        heir = next((x for x in others if x.role == "parent"), None) or \
            next((x for x in others if x.role == "member"), None) or others[0]
        heir.role = "owner"
    db.delete(m)
    if not others:
        db.delete(f)
    db.commit()
    return {"left": True}


@router.patch("")
def update_family(payload: FamilyUpdate, db: Session = Depends(get_db),
                  current_user: models.User = Depends(get_current_user)):
    m = _need_parent(db, current_user)
    f = m.family
    if payload.name is not None:
        f.name = payload.name.strip()
    if payload.emoji:
        f.emoji = payload.emoji
    if payload.monthly_budget is not None:
        # stored in the family currency; convert from the editor's base currency if different
        f.monthly_budget = payload.monthly_budget
        f.currency = current_user.base_currency or f.currency
    db.commit()
    return fam.build_dashboard(db, current_user)


@router.post("/regenerate-code")
def regenerate_code(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    m = _need_parent(db, current_user)
    m.family.invite_code = fam.new_invite_code(db)
    db.commit()
    return {"invite_code": m.family.invite_code}


# ---------- me ----------
@router.patch("/me")
def update_me(payload: MeUpdate, db: Session = Depends(get_db),
              current_user: models.User = Depends(get_current_user)):
    m = _need_family(db, current_user)
    if payload.share_level is not None:
        if payload.share_level not in fam.SHARE_LEVELS:
            raise HTTPException(status_code=422, detail=tr("Unknown sharing level"))
        m.share_level = payload.share_level
    if payload.avatar is not None:
        if payload.avatar not in fam.AVATARS:
            raise HTTPException(status_code=422, detail=tr("Pick one of the avatars"))
        m.avatar = payload.avatar
    db.commit()
    return fam.build_dashboard(db, current_user)


# ---------- members ----------
def _member_of_my_family(db: Session, mine: models.FamilyMember, user_id: int) -> models.FamilyMember:
    target = db.query(models.FamilyMember).filter(
        models.FamilyMember.family_id == mine.family_id, models.FamilyMember.user_id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail=tr("Member not found"))
    return target


@router.patch("/members/{user_id}/role")
def set_role(user_id: int, payload: RoleUpdate, db: Session = Depends(get_db),
             current_user: models.User = Depends(get_current_user)):
    mine = _need_parent(db, current_user)
    target = _member_of_my_family(db, mine, user_id)
    if payload.role not in ("parent", "member", "child"):
        raise HTTPException(status_code=422, detail=tr("Unknown role"))
    if target.role == "owner":
        raise HTTPException(status_code=400, detail=tr("The family owner's role can't be changed"))
    if payload.role == "child":
        age = age_tier.compute_age(target.user)
        if target.user.managed_by is None and (age is None or age >= 18):
            raise HTTPException(status_code=400, detail=tr("Only members under 18 can be set as a child"))
    if payload.role == "parent" and mine.role != "owner":
        raise HTTPException(status_code=403, detail=tr("Only the family owner can make someone a parent"))
    target.role = payload.role
    db.commit()
    return fam.build_dashboard(db, current_user)


@router.delete("/members/{user_id}")
def remove_member(user_id: int, db: Session = Depends(get_db),
                  current_user: models.User = Depends(get_current_user)):
    mine = _need_parent(db, current_user)
    target = _member_of_my_family(db, mine, user_id)
    if target.role == "owner" or target.user_id == current_user.id:
        raise HTTPException(status_code=400, detail=tr("You can't remove yourself or the owner"))
    db.delete(target)
    db.commit()
    return fam.build_dashboard(db, current_user)


# ---------- child profiles (kids who don't need their own login) ----------
@router.post("/children", status_code=201)
def add_child(payload: ChildCreate, db: Session = Depends(get_db),
              current_user: models.User = Depends(get_current_user)):
    mine = _need_parent(db, current_user)
    if len(mine.family.members) >= 12:
        raise HTTPException(status_code=400, detail=tr("This family is full (12 members)"))
    if payload.avatar not in fam.AVATARS:
        raise HTTPException(status_code=422, detail=tr("Pick one of the avatars"))
    email = f"child-{secrets.token_hex(5)}@kids.spendsense.app"
    child = models.User(
        name=payload.name.strip(), email=email, password_hash=hash_password(secrets.token_urlsafe(24)),
        age=payload.age, platform_mode="kid" if payload.age < 13 else "teen",
        currency=current_user.currency, base_currency=current_user.base_currency,
        language=current_user.language, theme="kid" if payload.age < 13 else (current_user.theme or "night"),
        guardian_confirmed=True, managed_by=current_user.id,
    )
    db.add(child)
    db.flush()
    db.add(models.FamilyMember(family_id=mine.family_id, user_id=child.id, role="child", avatar=payload.avatar))
    db.commit()
    return fam.build_dashboard(db, current_user)


@router.post("/switch/{user_id}")
def switch_profile(user_id: int, db: Session = Depends(get_db),
                   current_user: models.User = Depends(get_current_user)):
    """A parent steps into a child profile they manage (no password needed)."""
    mine = _need_parent(db, current_user)
    target = _member_of_my_family(db, mine, user_id)
    if target.user.managed_by is None:
        raise HTTPException(status_code=403, detail=tr("Only child profiles can be opened from here"))
    from ..routers.auth import build_user_out
    return {"access_token": create_access_token(target.user.email), "token_type": "bearer",
            "user": build_user_out(target.user)}


# ---------- challenges ----------
@router.post("/challenges", status_code=201)
def create_challenge(payload: ChallengeCreate, db: Session = Depends(get_db),
                     current_user: models.User = Depends(get_current_user)):
    mine = _need_family(db, current_user)
    if payload.kind not in fam.CHALLENGE_KINDS:
        raise HTTPException(status_code=422, detail=tr("Unknown challenge type"))
    if mine.role == "child":
        raise HTTPException(status_code=403, detail=tr("Ask a parent to start a challenge"))
    today = dt.datetime.utcnow().date()
    db.add(models.FamilyChallenge(
        family_id=mine.family_id, kind=payload.kind, title=payload.title.strip(), target=payload.target,
        category=payload.category.strip(), start_date=today, end_date=today + dt.timedelta(days=payload.days - 1),
        created_by=current_user.id))
    db.commit()
    return fam.build_dashboard(db, current_user)


@router.delete("/challenges/{challenge_id}")
def delete_challenge(challenge_id: int, db: Session = Depends(get_db),
                     current_user: models.User = Depends(get_current_user)):
    mine = _need_parent(db, current_user)
    ch = db.query(models.FamilyChallenge).filter(
        models.FamilyChallenge.id == challenge_id, models.FamilyChallenge.family_id == mine.family_id).first()
    if not ch:
        raise HTTPException(status_code=404, detail=tr("Challenge not found"))
    db.delete(ch)
    db.commit()
    return fam.build_dashboard(db, current_user)


# ---------- kudos ----------
@router.post("/kudos")
def send_kudos(payload: KudosIn, db: Session = Depends(get_db),
               current_user: models.User = Depends(get_current_user)):
    mine = _need_family(db, current_user)
    if payload.to_user_id == current_user.id:
        raise HTTPException(status_code=400, detail=tr("You can't cheer yourself — pick someone else!"))
    _member_of_my_family(db, mine, payload.to_user_id)
    emoji = payload.emoji if payload.emoji in fam.KUDOS_EMOJIS else fam.KUDOS_EMOJIS[0]
    start = dt.datetime.combine(dt.datetime.utcnow().date(), dt.time.min)
    sent = db.query(models.FamilyKudos).filter(
        models.FamilyKudos.from_user == current_user.id, models.FamilyKudos.created_at >= start).count()
    if sent >= fam.MAX_KUDOS_PER_DAY:
        raise HTTPException(status_code=429, detail=tr("You've used all your cheers for today — come back tomorrow!"))
    db.add(models.FamilyKudos(family_id=mine.family_id, from_user=current_user.id,
                              to_user=payload.to_user_id, emoji=emoji))
    db.commit()
    return fam.build_dashboard(db, current_user)
